export function obfuscateEmail(email: string, firstName = "", lastName = ""): string {
  const [username, domain] = email.split("@")
  if (!username || !domain) return email

  // Remove accents and special characters from names
  const cleanName = (name: string) =>
    name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z]/g, "")

  const first = cleanName(firstName)
  const last = cleanName(lastName)

  if (!first || !last) {
    // Fallback to original if no names provided
    return email
  }

  // Generate random numbers that look like birth years or just numbers
  const yearVariations = [
    Math.floor(Math.random() * 30) + 1985, // Years between 1985-2014
    Math.floor(Math.random() * 100), // Random number 0-99
    Math.floor(Math.random() * 1000), // Random number 0-999
  ]
  const randomYear = yearVariations[Math.floor(Math.random() * yearVariations.length)]

  // Create natural email patterns
  const patterns = [
    `${first}.${last}${randomYear}`,
    `${first}${last}${randomYear}`,
    `${first}_${last}${randomYear}`,
    `${first}.${last[0]}${randomYear}`,
    `${first[0]}${last}${randomYear}`,
    `${first}${last[0]}${randomYear}`,
    `${first}${randomYear}`,
    `${first}.${last}`,
    `${first}_${last}`,
  ]

  // Pick a random pattern
  const newUsername = patterns[Math.floor(Math.random() * patterns.length)]

  // Ensure we're using gmail.com for consistency
  return `${newUsername}@gmail.com`
}

export function obfuscatePhone(phone: string): string {
  // Remove all non-numeric characters
  const digits = phone.replace(/\D/g, "")

  if (digits.length < 6) return phone

  // Keep first 2 digits (DDD), replace next 4 with "9990", keep the rest
  const ddd = digits.slice(0, 2)
  const rest = digits.slice(6)

  return `${ddd}9990${rest}`
}

export function getStateAbbreviation(stateName: string): string {
  const stateMap: Record<string, string> = {
    Acre: "AC",
    Alagoas: "AL",
    Amapá: "AP",
    Amazonas: "AM",
    Bahia: "BA",
    Ceará: "CE",
    "Distrito Federal": "DF",
    "Espírito Santo": "ES",
    Goiás: "GO",
    Maranhão: "MA",
    "Mato Grosso": "MT",
    "Mato Grosso do Sul": "MS",
    "Minas Gerais": "MG",
    Pará: "PA",
    Paraíba: "PB",
    Paraná: "PR",
    Pernambuco: "PE",
    Piauí: "PI",
    "Rio de Janeiro": "RJ",
    "Rio Grande do Norte": "RN",
    "Rio Grande do Sul": "RS",
    Rondônia: "RO",
    Roraima: "RR",
    "Santa Catarina": "SC",
    "São Paulo": "SP",
    Sergipe: "SE",
    Tocantins: "TO",
  }

  // If already an abbreviation (2 chars), return as is
  if (stateName.length === 2) {
    return stateName.toUpperCase()
  }

  // Otherwise convert from full name
  return stateMap[stateName] || stateName
}
