"use client"

/**
 * TRACKING CLIENT V3 - Hardened Meta Pixel + CAPI
 *
 * Architecture:
 * - Three main functions: trackLead, trackInitiateCheckout, trackPurchase
 * - Each fires browser Pixel + calls backend CAPI endpoint
 * - Idempotent with Set-based deduplication
 * - Consistent event_id pattern across browser & server
 * - Robust PIX polling with duplicate prevention
 */

// ============================================================================
// TRACKING PARAMS & IDENTITY
// ============================================================================

import crypto from "crypto"

export interface TrackingParams {
  fbp: string
  fbc: string
  fbclid: string
  sessionId: string
}

export function getFBP(): string {
  if (typeof document === "undefined") return ""
  const match = document.cookie.match(/_fbp=([^;]+)/)
  return match ? match[1] : ""
}

export function getFBC(): string {
  if (typeof document === "undefined") return ""
  const fbclid = getFBCLID()
  if (!fbclid) {
    // Check existing _fbc cookie
    const match = document.cookie.match(/_fbc=([^;]+)/)
    return match ? match[1] : ""
  }
  // Build fbc in Meta format: fb.1.<timestamp>.<fbclid>
  const timestamp = Date.now()
  return `fb.1.${timestamp}.${fbclid}`
}

export function getFBCLID(): string {
  if (typeof window === "undefined") return ""
  const params = new URLSearchParams(window.location.search)
  return params.get("fbclid") || ""
}

export function generateSessionId(): string {
  // Check if session already exists
  if (typeof window !== "undefined") {
    const existing = sessionStorage.getItem("tracking_session_id")
    if (existing) return existing
  }

  const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`

  if (typeof window !== "undefined") {
    sessionStorage.setItem("tracking_session_id", sessionId)
  }

  return sessionId
}

export function getTrackingParams(): TrackingParams {
  return {
    fbp: getFBP(),
    fbc: getFBC(),
    fbclid: getFBCLID(),
    sessionId: generateSessionId(),
  }
}

// ============================================================================
// DEDUPLICATION REGISTRY
// ============================================================================

const trackedEvents = new Set<string>()

function isEventTracked(eventKey: string): boolean {
  return trackedEvents.has(eventKey)
}

function markEventTracked(eventKey: string): void {
  trackedEvents.add(eventKey)
}

// ============================================================================
// HASHING FUNCTIONS
// ============================================================================

function sha256(input: string): string {
  if (typeof window !== "undefined") {
    // Browser environment - use SubtleCrypto
    return input // Will be hashed server-side
  }
  // Node environment
  return crypto.createHash("sha256").update(input).digest("hex")
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase()
}

function normalizePhone(phone: string): string {
  const digitsOnly = phone.replace(/\D/g, "")
  if (digitsOnly.length === 11 || digitsOnly.length === 10) {
    return `+55${digitsOnly}`
  }
  if (digitsOnly.length > 11) {
    return `+${digitsOnly}`
  }
  return `+55${digitsOnly}`
}

// ============================================================================
// TRACKING FUNCTIONS
// ============================================================================

export async function trackLead(
  orderId: string | null,
  cartTotal: number,
  trackingParams: TrackingParams,
  userData: { email?: string; phone?: string; name?: string },
): Promise<void> {
  const eventId = `lead_${trackingParams.sessionId}`
  const eventKey = `lead_${orderId || trackingParams.sessionId}`

  if (isEventTracked(eventKey)) {
    console.log(`[TRACKING] Lead already tracked for ${eventKey}`)
    return
  }

  markEventTracked(eventKey)

  // 1. Fire browser Pixel
  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq(
      "track",
      "Lead",
      {
        value: cartTotal,
        currency: "BRL",
      },
      {
        eventID: eventId,
        ...(trackingParams.fbp && { fbp: trackingParams.fbp }),
        ...(trackingParams.fbc && { fbc: trackingParams.fbc }),
      },
    )
    console.log(`[PIXEL] Lead tracked - event_id: ${eventId}`)
  }

  // 2. Call backend CAPI
  try {
    const now = Math.floor(Date.now() / 1000)
    const payload = {
      event_name: "Lead",
      event_time: now,
      event_id: eventId,
      action_source: "website",
      event_source_url: typeof window !== "undefined" ? window.location.href : "",
      user_data: {
        ...(trackingParams.fbp && { fbp: trackingParams.fbp }),
        ...(trackingParams.fbc && { fbc: trackingParams.fbc }),
        ...(userData.email && { email: userData.email }),
        ...(userData.phone && { phone: userData.phone }),
        client_user_agent: typeof navigator !== "undefined" ? navigator.userAgent : "",
      },
      custom_data: {
        value: cartTotal,
        currency: "BRL",
        content_type: "product",
      },
    }

    const res = await fetch("/api/track/lead", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    if (!res.ok) {
      const text = await res.text().catch(() => "")
      console.warn(`[CAPI ERROR] Lead ${res.status} - ${text}`, payload)
    } else {
      console.log(`[CAPI] Lead 200 OK - event_id: ${eventId}`)
    }
  } catch (error) {
    console.error("[CAPI ERROR] Lead request failed:", error)
  }
}

export async function trackInitiateCheckout(
  orderId: string,
  cartTotal: number,
  trackingParams: TrackingParams,
  userData: { email?: string; phone?: string; name?: string },
): Promise<void> {
  const eventId = `initiatecheckout_${orderId}`
  const eventKey = `initiatecheckout_${orderId}`

  if (isEventTracked(eventKey)) {
    console.log(`[TRACKING] InitiateCheckout already tracked for ${eventKey}`)
    return
  }

  markEventTracked(eventKey)

  // 1. Fire browser Pixel
  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq(
      "track",
      "InitiateCheckout",
      {
        value: cartTotal,
        currency: "BRL",
        content_ids: ["protocolo-30-dias"],
        content_name: "Protocolo 30 Dias — Inova Mulher",
      },
      {
        eventID: eventId,
        ...(trackingParams.fbp && { fbp: trackingParams.fbp }),
        ...(trackingParams.fbc && { fbc: trackingParams.fbc }),
      },
    )
    console.log(`[PIXEL] InitiateCheckout tracked - event_id: ${eventId}`)
  }

  // 2. Call backend CAPI
  try {
    const now = Math.floor(Date.now() / 1000)
    const payload = {
      event_name: "InitiateCheckout",
      event_time: now,
      event_id: eventId,
      action_source: "website",
      event_source_url: typeof window !== "undefined" ? window.location.href : "",
      user_data: {
        ...(trackingParams.fbp && { fbp: trackingParams.fbp }),
        ...(trackingParams.fbc && { fbc: trackingParams.fbc }),
        ...(userData.email && { email: userData.email }),
        ...(userData.phone && { phone: userData.phone }),
        client_user_agent: typeof navigator !== "undefined" ? navigator.userAgent : "",
      },
      custom_data: {
        value: cartTotal,
        currency: "BRL",
        order_id: String(orderId),
        content_type: "product",
        content_ids: ["protocolo-30-dias"],
      },
    }

    const res = await fetch("/api/track/initiate-checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    if (!res.ok) {
      const text = await res.text().catch(() => "")
      console.warn(`[CAPI ERROR] InitiateCheckout ${res.status} - ${text}`, payload)
    } else {
      console.log(`[CAPI] InitiateCheckout 200 OK - event_id: ${eventId}`)
    }
  } catch (error) {
    console.error("[CAPI ERROR] InitiateCheckout request failed:", error)
  }
}

export async function trackPurchase(
  orderId: string,
  cartTotal: number,
  trackingParams: TrackingParams,
  userData: { email?: string; phone?: string; name?: string },
): Promise<void> {
  const eventId = `purchase_${orderId}`
  const eventKey = `purchase_${orderId}`

  if (isEventTracked(eventKey)) {
    console.log(`[TRACKING] Purchase already tracked for ${eventKey}`)
    return
  }

  markEventTracked(eventKey)

  const validCartTotal = typeof cartTotal === "number" && cartTotal > 0 ? cartTotal : 0
  if (validCartTotal === 0) {
    console.warn("[PIXEL] Invalid cart total for Purchase:", cartTotal)
  }

  // 1. Fire browser Pixel
  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq(
      "track",
      "Purchase",
      {
        value: validCartTotal,
        currency: "BRL",
        content_ids: ["protocolo-30-dias"],
        content_name: "Protocolo 30 Dias — Inova Mulher",
        external_id: orderId,
      },
      {
        eventID: eventId,
        ...(trackingParams.fbp && { fbp: trackingParams.fbp }),
        ...(trackingParams.fbc && { fbc: trackingParams.fbc }),
      },
    )
    console.log(`[PIXEL] Purchase tracked - event_id: ${eventId}`)
  }

  // Purchase via CAPI is now handled by backend webhook
  // This ensures Purchase is guaranteed even if user closes browser
  console.log(`[TRACKING] Purchase pixel sent, backend will handle CAPI via webhook`)
}

// ============================================================================
// PIX POLLING
// ============================================================================

const activePollings = new Map<string, NodeJS.Timeout>()

export async function startPixPolling(
  orderId: string,
  cartTotal: number,
  trackingParams: TrackingParams,
  userData: { email?: string; phone?: string; name?: string },
  options: {
    maxAttempts?: number
    intervalMs?: number
    onPaymentConfirmed?: () => void // New callback for post-payment action
  } = {},
): Promise<() => void> {
  const { maxAttempts = 60, intervalMs = 5000, onPaymentConfirmed } = options

  // Prevent duplicate polling for same order
  if (activePollings.has(orderId)) {
    console.log(`[POLLING] Already active for order ${orderId}, skipping duplicate`)
    return () => {}
  }

  let attempts = 0

  const checkPayment = async () => {
    try {
      attempts++
      console.log(`[POLLING] Attempt ${attempts}/${maxAttempts} for order ${orderId}`)

      const response = await fetch(`/api/order-status?order_id=${orderId}`)

      if (!response.ok) {
        console.error(`[POLLING] Failed to check payment status: ${response.status}`)
        return
      }

      const data = await response.json()

      if (data.status === "paid" || data.isPaid) {
        console.log(`[POLLING] ✅ Payment confirmed for order ${orderId}`)
        stopPolling()

        // Track Purchase event
        await trackPurchase(orderId, cartTotal, trackingParams, userData)

        if (onPaymentConfirmed) {
          onPaymentConfirmed()
        }
      } else if (data.status === "expired") {
        console.log(`[POLLING] ⚠️ Payment expired for order ${orderId}`)
        stopPolling()
      } else if (attempts >= maxAttempts) {
        console.log(`[POLLING] ⚠️ Max attempts (${maxAttempts}) reached for order ${orderId}`)
        stopPolling()
      }
    } catch (error) {
      console.error(`[POLLING] Error checking order ${orderId}:`, error)
    }
  }

  const stopPolling = () => {
    const interval = activePollings.get(orderId)
    if (interval) {
      clearInterval(interval)
      activePollings.delete(orderId)
      console.log(`[POLLING] Stopped for order ${orderId}`)
    }
  }

  // Start polling immediately
  checkPayment()

  // Then check at intervals
  const interval = setInterval(checkPayment, intervalMs)
  activePollings.set(orderId, interval)

  // Return stop function
  return stopPolling
}

// Clean up function for unmounting
export function stopAllPollings(): void {
  activePollings.forEach((interval, orderId) => {
    clearInterval(interval)
    console.log(`[POLLING] Stopped on unmount for order ${orderId}`)
  })
  activePollings.clear()
}
