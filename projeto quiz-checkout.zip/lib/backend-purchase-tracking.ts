/**
 * BACKEND PURCHASE TRACKING - Server-side Purchase event via CAPI
 * Called by webhook when payment is confirmed
 */

import { sendMetaCAPI } from "@/lib/meta-capi-service"
import { getOrderData, markPurchaseTracked, isPurchaseTracked } from "@/lib/order-data-store"

export async function sendBackendPurchase(orderId: string): Promise<{ success: boolean; message: string }> {
  try {
    if (isPurchaseTracked(orderId)) {
      console.log("[BACKEND-PURCHASE] Purchase already tracked for order:", orderId, "- Skipping")
      return { success: true, message: "Purchase already tracked (deduplicated)" }
    }

    const orderData = getOrderData(orderId)
    if (!orderData) {
      console.error("[BACKEND-PURCHASE] No order data found for:", orderId)
      return { success: false, message: "Order data not found" }
    }

    if (!orderData.totalAmount || orderData.totalAmount <= 0) {
      console.error("[BACKEND-PURCHASE] Invalid order value:", orderData.totalAmount)
      return { success: false, message: "Invalid order value" }
    }

    const eventId = `purchase_${orderId}`

    console.log("[BACKEND-PURCHASE] Sending Purchase via CAPI for order:", orderId)
    console.log("[BACKEND-PURCHASE] Event ID:", eventId)
    console.log("[BACKEND-PURCHASE] Value:", orderData.totalAmount)

    await sendMetaCAPI({
      eventName: "Purchase",
      eventId, // Same format as frontend for deduplication
      eventSourceUrl: orderData.sourceUrl,
      userAgent: orderData.userAgent,
      userData: {
        email: orderData.userData.email,
        phone: orderData.userData.phone,
        name: orderData.userData.name,
        fbp: orderData.trackingParams.fbp,
        fbc: orderData.trackingParams.fbc,
      },
      customData: {
        value: orderData.totalAmount,
        currency: orderData.currency,
        content_ids: ["protocolo-30-dias"],
        content_name: "Protocolo 30 Dias — Inova Mulher",
        content_type: "product",
      },
    })

    markPurchaseTracked(orderId)

    console.log("[BACKEND-PURCHASE] ✓ Purchase successfully sent for order:", orderId)
    return { success: true, message: "Purchase event sent successfully" }
  } catch (error) {
    console.error("[BACKEND-PURCHASE] Error sending Purchase for order:", orderId, error)
    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
    }
  }
}
