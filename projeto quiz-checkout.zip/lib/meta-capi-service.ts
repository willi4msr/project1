import crypto from "crypto"

/**
 * PIPELINE A: TRACKING - Dados reais para Meta
 * Este serviço gerencia todo o envio de eventos para a Meta via CAPI
 */

// Normalização de dados conforme especificações da Meta
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase()
}

export function normalizePhone(phone: string): string {
  const digitsOnly = phone.replace(/\D/g, "")

  // Formato E.164 para Brasil
  if (digitsOnly.length === 11 || digitsOnly.length === 10) {
    return `+55${digitsOnly}`
  }

  if (digitsOnly.length > 11) {
    return `+${digitsOnly}`
  }

  return `+55${digitsOnly}`
}

export function sha256(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex")
}

// Gera hashes para envio seguro à Meta
export function hashUserData(email: string, phone: string) {
  const normalizedEmail = normalizeEmail(email)
  const normalizedPhone = normalizePhone(phone)

  return {
    em: sha256(normalizedEmail),
    ph: sha256(normalizedPhone),
    external_id: sha256(normalizedEmail + normalizedPhone),
    normalizedEmail,
    normalizedPhone,
  }
}

interface MetaEventParams {
  eventName: "Lead" | "InitiateCheckout" | "Purchase"
  eventId: string // OBRIGATÓRIO para deduplicação
  eventSourceUrl: string
  userAgent: string
  userData: {
    email: string // real
    phone: string // real
    name?: string
    fbp?: string // cookie _fbp
    fbc?: string // cookie _fbc
    clientIp?: string
  }
  customData?: {
    value?: number
    currency?: string
    content_ids?: string[]
    content_name?: string
    content_type?: string
    contents?: Array<{
      id: string
      quantity: number
      item_price: number
    }>
  }
}

export async function sendMetaCAPI(params: MetaEventParams) {
  const pixelId = process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID
  const accessToken = process.env.FACEBOOK_CONVERSION_API_TOKEN
  const testEventCode = process.env.FACEBOOK_TEST_EVENT_CODE

  if (!pixelId || !accessToken) {
    console.error("[META-CAPI] Missing credentials")
    throw new Error("Missing Facebook credentials")
  }

  // Hash dos dados reais
  const hashedData = hashUserData(params.userData.email, params.userData.phone)

  // Monta user_data com hashes
  const user_data: any = {
    em: hashedData.em,
    ph: hashedData.ph,
    external_id: hashedData.external_id,
    client_ip_address: params.userData.clientIp,
    client_user_agent: params.userAgent,
  }

  // Adiciona FBP e FBC (não hasheados)
  if (params.userData.fbp) user_data.fbp = params.userData.fbp
  if (params.userData.fbc) user_data.fbc = params.userData.fbc

  // Hash do nome se fornecido
  if (params.userData.name) {
    const [firstName, ...lastNameParts] = params.userData.name.split(" ")
    if (firstName) user_data.fn = sha256(firstName.toLowerCase().trim())
    if (lastNameParts.length) user_data.ln = sha256(lastNameParts.join(" ").toLowerCase().trim())
  }

  const eventPayload = {
    event_name: params.eventName,
    event_time: Math.floor(Date.now() / 1000),
    event_id: params.eventId, // Mesmo event_id do Pixel
    event_source_url: params.eventSourceUrl,
    action_source: "website",
    user_data,
    custom_data: params.customData || {},
  }

  const payload = {
    data: [eventPayload],
    access_token: accessToken,
    ...(testEventCode && { test_event_code: testEventCode }),
  }

  console.log(`[META-CAPI] Sending ${params.eventName}`, {
    event_id: params.eventId,
    external_id: hashedData.external_id.substring(0, 8) + "...",
    fbp: params.userData.fbp?.substring(0, 10) + "..." || "missing",
    fbc: params.userData.fbc?.substring(0, 10) + "..." || "missing",
  })

  try {
    const response = await fetch(`https://graph.facebook.com/v21.0/${pixelId}/events`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error(`[META-CAPI] ${params.eventName} FAILED:`, result)
      throw new Error(`Meta API error: ${JSON.stringify(result)}`)
    }

    console.log(`[META-CAPI] ${params.eventName} SUCCESS:`, result)
    return { success: true, data: result }
  } catch (error) {
    console.error(`[META-CAPI] ${params.eventName} ERROR:`, error)
    throw error
  }
}
