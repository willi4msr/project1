/**
 * TRACKING STORE V2 - Proteção contra duplicação de eventos
 * Armazena em memória (runtime) quais purchases já foram enviados
 */

// Armazena order_ids que já tiveram Purchase enviado
const purchasesSent = new Set<string>()

export function isPurchaseSent(orderId: string): boolean {
  return purchasesSent.has(orderId)
}

export function markPurchaseAsSent(orderId: string): void {
  purchasesSent.add(orderId)
  console.log(`[TRACKING-STORE] Purchase marked as sent for order: ${orderId}`)
  console.log(`[TRACKING-STORE] Total purchases sent: ${purchasesSent.size}`)
}

// Retorna todos os order_ids que já enviaram Purchase
export function getAllSentPurchases(): string[] {
  return Array.from(purchasesSent)
}

// Limpa o histórico (apenas para testes)
export function clearPurchaseHistory(): void {
  purchasesSent.clear()
  console.log("[TRACKING-STORE] Purchase history cleared")
}
