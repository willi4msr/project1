// In-memory store for paid orders (in production, use Redis or database)
const paidOrders = new Map<string, { orderId: string; timestamp: number }>()

export function markOrderAsPaid(orderId: string) {
  const orderIdStr = String(orderId)
  paidOrders.set(orderIdStr, { orderId: orderIdStr, timestamp: Date.now() })
  console.log("[v0] Order marked as paid in store:", orderIdStr)
  console.log("[v0] Current paid orders in store:", Array.from(paidOrders.keys()))
}

export function isOrderPaid(orderId: string): boolean {
  const orderIdStr = String(orderId)
  const isPaid = paidOrders.has(orderIdStr)
  console.log("[v0] Checking if order is paid:", orderIdStr, "- Result:", isPaid)
  console.log("[v0] All paid orders in store:", Array.from(paidOrders.keys()))
  return isPaid
}

export function clearOldOrders() {
  const now = Date.now()
  const oneHour = 60 * 60 * 1000

  for (const [orderId, data] of paidOrders.entries()) {
    if (now - data.timestamp > oneHour) {
      paidOrders.delete(orderId)
      console.log("[v0] Cleared old order from store:", orderId)
    }
  }
}

// Clean old orders every 10 minutes
setInterval(clearOldOrders, 10 * 60 * 1000)
