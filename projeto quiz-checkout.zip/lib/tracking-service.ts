import crypto from "crypto"

/**
 * NORMALIZAÇÃO E HASHING
 * Seguindo as especificações da Meta para garantir match rate alto
 */

export function normalizeEmail(email: string): string {
  // Remove espaços e converte para lowercase
  return email.trim().toLowerCase()
}

export function normalizePhone(phone: string): string {
  // Remove todos os caracteres não numéricos
  const digitsOnly = phone.replace(/\D/g, "")

  // Converte para formato E.164 (internacional)
  // Se tem 11 dígitos (celular BR): +55XXXXXXXXXXX
  // Se tem 10 dígitos (fixo BR): +55XXXXXXXXXX
  if (digitsOnly.length === 11 || digitsOnly.length === 10) {
    return `+55${digitsOnly}`
  }

  // Se já tem código do país, retorna com +
  if (digitsOnly.length > 11) {
    return `+${digitsOnly}`
  }

  return `+55${digitsOnly}`
}

export function sha256(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex")
}

/**
 * GERAÇÃO DE HASHES PARA META
 */
export function hashUserData(email: string, phone: string) {
  const normalizedEmail = normalizeEmail(email)
  const normalizedPhone = normalizePhone(phone)

  return {
    em: sha256(normalizedEmail), // email hash
    ph: sha256(normalizedPhone), // phone hash
    external_id: sha256(normalizedEmail + normalizedPhone), // ID estável como CPF
    normalizedEmail,
    normalizedPhone,
  }
}

/**
 * CONVERSIONS API - Envio para Meta
 */
export async function sendMetaEvent(params: {
  eventName: string
  eventId: string
  eventSourceUrl: string
  userData: {
    em?: string // email hash
    ph?: string // phone hash
    fn?: string // first name hash
    external_id?: string
    fbp?: string
    fbc?: string
    client_ip_address?: string
    client_user_agent?: string
  }
  customData?: {
    currency?: string
    value?: number
    content_ids?: string[]
    content_type?: string
    contents?: Array<{
      id: string
      quantity: number
      item_price: number
    }>
  }
  actionSource?: string
}) {
  const pixelId = process.env.FACEBOOK_PIXEL_ID
  const accessToken = process.env.FACEBOOK_CONVERSION_API_TOKEN
  const testEventCode = process.env.FACEBOOK_TEST_EVENT_CODE

  if (!pixelId || !accessToken) {
    console.error("[TRACKING] Missing Facebook credentials")
    return { success: false, error: "Missing credentials" }
  }

  const eventData = {
    event_name: params.eventName,
    event_time: Math.floor(Date.now() / 1000),
    event_id: params.eventId,
    event_source_url: params.eventSourceUrl,
    action_source: params.actionSource || "website",
    user_data: params.userData,
    custom_data: params.customData || {},
  }

  const payload = {
    data: [eventData],
    ...(testEventCode && { test_event_code: testEventCode }),
  }

  console.log(`[TRACKING] Sending ${params.eventName} to Meta CAPI`, {
    event_id: params.eventId,
    external_id: params.userData.external_id,
    fbp: params.userData.fbp,
    fbc: params.userData.fbc,
  })

  try {
    const response = await fetch(`https://graph.facebook.com/v21.0/${pixelId}/events?access_token=${accessToken}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error("[TRACKING] Meta CAPI error:", result)
      return { success: false, error: result }
    }

    console.log("[TRACKING] Meta CAPI success:", result)
    return { success: true, data: result }
  } catch (error) {
    console.error("[TRACKING] Meta CAPI request failed:", error)
    return { success: false, error }
  }
}
