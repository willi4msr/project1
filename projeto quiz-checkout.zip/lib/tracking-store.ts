// Este arquivo mantém o mapeamento entre session_id e dados reais do usuário

interface TrackingData {
  sessionId: string
  externalId: string
  email: string
  phone: string
  firstName?: string
  fbp?: string
  fbc?: string
  fbclid?: string
  utmSource?: string
  utmMedium?: string
  utmCampaign?: string
  clientIp?: string
  clientUserAgent?: string
  createdAt: number
}

// Em produção, isso deve ser um banco de dados (Redis, PostgreSQL, etc)
// Por enquanto, usamos um Map em memória
const trackingStore = new Map<string, TrackingData>()

export function saveTrackingData(data: TrackingData) {
  trackingStore.set(data.sessionId, data)
  console.log(`[TRACKING STORE] Saved data for session: ${data.sessionId}`)
}

export function getTrackingData(sessionId: string): TrackingData | null {
  const data = trackingStore.get(sessionId)
  if (!data) {
    console.warn(`[TRACKING STORE] No data found for session: ${sessionId}`)
  }
  return data || null
}

export function getTrackingDataByExternalId(externalId: string): TrackingData | null {
  for (const data of trackingStore.values()) {
    if (data.externalId === externalId) {
      return data
    }
  }
  console.warn(`[TRACKING STORE] No data found for external_id: ${externalId}`)
  return null
}
