/**
 * ORDER DATA STORE - Stores order data for webhook processing
 * In production, use Redis or database
 */

interface OrderData {
  orderId: string
  totalAmount: number
  currency: string
  userData: {
    email: string
    phone: string
    name: string
  }
  trackingParams: {
    fbp: string
    fbc: string
    fbclid: string
    sessionId: string
  }
  userAgent: string
  sourceUrl: string
  timestamp: number
  purchaseTracked?: boolean // Flag to prevent duplicate Purchase events
}

const orderDataStore = new Map<string, OrderData>()

export function saveOrderData(orderId: string, data: Omit<OrderData, "orderId" | "timestamp" | "purchaseTracked">) {
  const orderData: OrderData = {
    ...data,
    orderId,
    timestamp: Date.now(),
    purchaseTracked: false,
  }
  orderDataStore.set(orderId, orderData)
  console.log("[ORDER-STORE] Saved order data for:", orderId)
}

export function getOrderData(orderId: string): OrderData | undefined {
  return orderDataStore.get(orderId)
}

export function markPurchaseTracked(orderId: string): boolean {
  const orderData = orderDataStore.get(orderId)
  if (!orderData) {
    console.warn("[ORDER-STORE] Order not found:", orderId)
    return false
  }

  if (orderData.purchaseTracked) {
    console.log("[ORDER-STORE] Purchase already tracked for:", orderId)
    return false
  }

  orderData.purchaseTracked = true
  orderDataStore.set(orderId, orderData)
  console.log("[ORDER-STORE] Marked purchase as tracked for:", orderId)
  return true
}

export function isPurchaseTracked(orderId: string): boolean {
  const orderData = orderDataStore.get(orderId)
  return orderData?.purchaseTracked || false
}

// Clean old orders (older than 2 hours)
export function cleanOldOrders() {
  const now = Date.now()
  const twoHours = 2 * 60 * 60 * 1000

  for (const [orderId, data] of orderDataStore.entries()) {
    if (now - data.timestamp > twoHours) {
      orderDataStore.delete(orderId)
      console.log("[ORDER-STORE] Cleaned old order:", orderId)
    }
  }
}

// Clean every 30 minutes
setInterval(cleanOldOrders, 30 * 60 * 1000)
