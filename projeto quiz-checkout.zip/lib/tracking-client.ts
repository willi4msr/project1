"use client"

/**
 * TRACKING CLIENT - FRONTEND
 * Responsável por:
 * 1. Capturar fbp/fbc
 * 2. Gerar session_id
 * 3. Enviar eventos para backend de tracking (dados reais)
 * 4. Disparar eventos Pixel
 */

export function generateSessionId(): string {
  // Gera um ID único para esta sessão
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

export function getCookie(name: string): string | null {
  if (typeof document === "undefined") return null

  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)

  if (parts.length === 2) {
    return parts.pop()?.split(";").shift() || null
  }

  return null
}

export function getUrlParam(name: string): string | null {
  if (typeof window === "undefined") return null

  const params = new URLSearchParams(window.location.search)
  return params.get(name)
}

export function getFacebookParams(): { fbp: string | null; fbc: string | null; fbclid: string | null } {
  // Primeiro tenta ler da URL (caso esteja vindo de redirect/iframe)
  const fbpFromUrl = getUrlParam("fbp")
  const fbcFromUrl = getUrlParam("fbc")
  const fbclidFromUrl = getUrlParam("fbclid")

  // Depois tenta ler dos cookies
  const fbpFromCookie = getCookie("_fbp")
  const fbcFromCookie = getCookie("_fbc")

  // Prioriza URL sobre cookie (para casos de iframe/redirect)
  const fbp = fbpFromUrl || fbpFromCookie
  const fbc = fbcFromUrl || fbcFromCookie
  const fbclid = fbclidFromUrl

  console.log("[TRACKING CLIENT] Facebook params:", { fbp, fbc, fbclid })

  return { fbp, fbc, fbclid }
}

export function getUtmParams(): { utmSource: string | null; utmMedium: string | null; utmCampaign: string | null } {
  return {
    utmSource: getUrlParam("utm_source"),
    utmMedium: getUrlParam("utm_medium"),
    utmCampaign: getUrlParam("utm_campaign"),
  }
}

export async function trackLead(params: {
  email: string
  phone: string
  firstName?: string
  sessionId: string
}) {
  const { fbp, fbc, fbclid } = getFacebookParams()
  const { utmSource, utmMedium, utmCampaign } = getUtmParams()

  console.log("[TRACKING CLIENT] Sending Lead event", { email: params.email, sessionId: params.sessionId })

  try {
    // Envia dados REAIS para o backend de tracking
    const response = await fetch("/api/track/lead", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: params.email,
        phone: params.phone,
        firstName: params.firstName,
        sessionId: params.sessionId,
        fbp,
        fbc,
        fbclid,
        utmSource,
        utmMedium,
        utmCampaign,
        eventSourceUrl: window.location.href,
      }),
    })

    const result = await response.json()
    console.log("[TRACKING CLIENT] Lead response:", result)

    // Dispara evento no Pixel com mesmo event_id para deduplicação
    if (typeof window !== "undefined" && (window as any).fbq) {
      ;(window as any).fbq("track", "Lead", {}, { eventID: result.eventId })
    }

    return result
  } catch (error) {
    console.error("[TRACKING CLIENT] Lead error:", error)
  }
}

export async function trackInitiateCheckout(params: {
  sessionId: string
  value: number
  currency?: string
  contentIds?: string[]
}) {
  console.log("[TRACKING CLIENT] Sending InitiateCheckout event", { sessionId: params.sessionId, value: params.value })

  try {
    const response = await fetch("/api/track/initiate-checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId: params.sessionId,
        value: params.value,
        currency: params.currency || "BRL",
        contentIds: params.contentIds,
        eventSourceUrl: window.location.href,
      }),
    })

    const result = await response.json()
    console.log("[TRACKING CLIENT] InitiateCheckout response:", result)

    // Dispara evento no Pixel com mesmo event_id para deduplicação
    if (typeof window !== "undefined" && (window as any).fbq) {
      ;(window as any).fbq(
        "track",
        "InitiateCheckout",
        {
          value: params.value,
          currency: params.currency || "BRL",
          content_ids: params.contentIds,
          content_type: "product",
        },
        { eventID: result.eventId },
      )
    }

    return result
  } catch (error) {
    console.error("[TRACKING CLIENT] InitiateCheckout error:", error)
  }
}
