"use client"

/**
 * TRACKING CLIENT V2 - Frontend
 * Gerencia eventos do Facebook Pixel e coordena com backend para CAPI
 */

// Captura cookies do Facebook
export function getFBP(): string {
  if (typeof document === "undefined") return ""
  const match = document.cookie.match(/_fbp=([^;]+)/)
  return match ? match[1] : ""
}

export function getFBC(): string {
  if (typeof document === "undefined") return ""
  const match = document.cookie.match(/_fbc=([^;]+)/)
  return match ? match[1] : ""
}

export function getFBCLID(): string {
  if (typeof window === "undefined") return ""
  const params = new URLSearchParams(window.location.search)
  return params.get("fbclid") || ""
}

// Gera session_id único
export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
}

// Dispara Lead (apenas Pixel no frontend, backend envia CAPI)
export function trackLead(email: string, phone: string) {
  const eventId = `lead_${Date.now()}`

  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq("track", "Lead", {}, { eventID: eventId })
    console.log("[PIXEL] Lead tracked - event_id:", eventId)
  }

  // Backend enviará CAPI em /api/track/lead
  return eventId
}

// Dispara InitiateCheckout
export function trackInitiateCheckout(orderId: string, value: number) {
  const eventId = `initiatecheckout_${orderId}`

  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq(
      "track",
      "InitiateCheckout",
      {
        value,
        currency: "BRL",
        content_ids: ["protocolo-30-dias"],
        content_name: "OzemFit PLUS Adesivo",
      },
      { eventID: eventId },
    )
    console.log("[PIXEL] InitiateCheckout tracked - event_id:", eventId)
  }

  return eventId
}

// Dispara Purchase (apenas Pixel, backend envia CAPI via webhook/polling)
export function trackPurchase(orderId: string, value: number) {
  const eventId = `purchase_${orderId}`

  if (typeof window !== "undefined" && (window as any).fbq) {
    ;(window as any).fbq(
      "track",
      "Purchase",
      {
        value,
        currency: "BRL",
        content_ids: ["protocolo-30-dias"],
        content_name: "Protocolo 30 Dias — Inova Mulher",
        external_id: orderId,
      },
      { eventID: eventId },
    )
    console.log("[PIXEL] Purchase tracked - event_id:", eventId)
  }

  return eventId
}

// Polling para verificar status do pagamento
export async function startPaymentPolling(
  orderId: string,
  onPaid: () => void,
  maxAttempts = 60, // 2 minutos (2s * 60)
): Promise<() => void> {
  let attempts = 0

  const checkPayment = async () => {
    try {
      attempts++
      console.log(`[POLLING] Attempt ${attempts}/${maxAttempts} for order ${orderId}`)

      const response = await fetch(`/api/order-status?order_id=${orderId}`)

      if (!response.ok) {
        console.error("[POLLING] Failed to check payment status")
        return
      }

      const data = await response.json()

      if (data.isPaid) {
        console.log(`[POLLING] ✅ Payment confirmed for order ${orderId}`)
        clearInterval(interval)
        onPaid()
        return
      }

      if (attempts >= maxAttempts) {
        console.log(`[POLLING] ⚠️ Max attempts reached for order ${orderId}`)
        clearInterval(interval)
      }
    } catch (error) {
      console.error("[POLLING] Error:", error)
    }
  }

  // Primeira verificação imediata
  checkPayment()

  // Depois verifica a cada 2 segundos
  const interval = setInterval(checkPayment, 2000)

  // Retorna função para parar o polling
  return () => {
    clearInterval(interval)
    console.log(`[POLLING] Stopped for order ${orderId}`)
  }
}
