"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Plus, Minus, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

type Product = {
  sku: string
  name: string
  price: number
  description: string
  image: string
}

type CartItem = Product & {
  qty: number
}

// Produtos de exemplo - você pode substituir por uma chamada à API
const SAMPLE_PRODUCTS: Product[] = [
  {
    sku: "TENIS-001",
    name: "Tênis de Corrida Pro",
    price: 299.9,
    description: "Tênis profissional para corrida com tecnologia de amortecimento",
    image: "/running-shoes.jpg",
  },
  {
    sku: "CAMISA-001",
    name: "Camisa Esportiva Dry-Fit",
    price: 89.9,
    description: "Camisa respirável com tecnologia de secagem rápida",
    image: "/sports-shirt.png",
  },
  {
    sku: "SHORT-001",
    name: "Short de Treino Premium",
    price: 79.9,
    description: "Short confortável ideal para treinos intensos",
    image: "/athletic-shorts.png",
  },
  {
    sku: "BONE-001",
    name: "Boné Esportivo UV",
    price: 49.9,
    description: "Boné com proteção UV e ajuste perfeito",
    image: "/sports-cap.jpg",
  },
  {
    sku: "MEIA-001",
    name: "Kit 3 Meias Esportivas",
    price: 39.9,
    description: "Kit com 3 pares de meias de alta performance",
    image: "/sports-socks.jpg",
  },
  {
    sku: "GARRAFA-001",
    name: "Garrafa Térmica 750ml",
    price: 69.9,
    description: "Garrafa térmica que mantém a temperatura por 12h",
    image: "/reusable-water-bottle.png",
  },
]

export default function ProductCatalog() {
  const router = useRouter()
  const { toast } = useToast()
  const [cart, setCart] = useState<CartItem[]>([])
  const [showCart, setShowCart] = useState(false)

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.sku === product.sku)
      if (existing) {
        return prev.map((item) => (item.sku === product.sku ? { ...item, qty: item.qty + 1 } : item))
      }
      return [...prev, { ...product, qty: 1 }]
    })
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao carrinho`,
    })
  }

  const updateQuantity = (sku: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => (item.sku === sku ? { ...item, qty: Math.max(0, item.qty + delta) } : item))
        .filter((item) => item.qty > 0),
    )
  }

  const removeFromCart = (sku: string) => {
    setCart((prev) => prev.filter((item) => item.sku !== sku))
  }

  const getCartTotal = () => {
    return cart.reduce((sum, item) => sum + item.price * item.qty, 0)
  }

  const getCartCount = () => {
    return cart.reduce((sum, item) => sum + item.qty, 0)
  }

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Carrinho vazio",
        description: "Adicione produtos ao carrinho antes de finalizar",
        variant: "destructive",
      })
      return
    }

    // Salva o carrinho no localStorage para usar no checkout
    localStorage.setItem("checkout_cart", JSON.stringify(cart))
    router.push("/checkout")
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b sticky top-0 bg-background z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Loja Esportiva</h1>
            <p className="text-sm text-muted-foreground">Os melhores produtos para seu treino</p>
          </div>
          <Button variant="outline" size="lg" onClick={() => setShowCart(!showCart)} className="relative">
            <ShoppingCart className="mr-2 h-5 w-5" />
            Carrinho
            {getCartCount() > 0 && <Badge className="ml-2 absolute -top-2 -right-2">{getCartCount()}</Badge>}
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Products Grid */}
          <div className={`${showCart ? "lg:col-span-3" : "lg:col-span-4"}`}>
            <div className="mb-6">
              <h2 className="text-3xl font-bold mb-2">Produtos em Destaque</h2>
              <p className="text-muted-foreground">Confira nossa seleção de produtos esportivos</p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {SAMPLE_PRODUCTS.map((product) => (
                <Card key={product.sku} className="overflow-hidden group hover:shadow-lg transition-shadow">
                  <div className="aspect-square overflow-hidden bg-muted">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold">R$ {product.price.toFixed(2)}</span>
                      <Button onClick={() => addToCart(product)} size="sm">
                        <Plus className="mr-1 h-4 w-4" />
                        Adicionar
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Cart Sidebar */}
          {showCart && (
            <div className="lg:col-span-1">
              <Card className="p-6 sticky top-24">
                <h3 className="text-xl font-bold mb-4">Seu Carrinho</h3>

                {cart.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Seu carrinho está vazio</p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                      {cart.map((item) => (
                        <div key={item.sku} className="flex gap-3 pb-4 border-b">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-sm truncate">{item.name}</h4>
                            <p className="text-sm font-bold">R$ {item.price.toFixed(2)}</p>
                            <div className="flex items-center gap-2 mt-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantity(item.sku, -1)}
                                className="h-7 w-7 p-0"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="text-sm font-medium w-8 text-center">{item.qty}</span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantity(item.sku, 1)}
                                className="h-7 w-7 p-0"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeFromCart(item.sku)}
                                className="h-7 w-7 p-0 ml-auto"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3 pt-4 border-t">
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span>R$ {getCartTotal().toFixed(2)}</span>
                      </div>
                      <Button onClick={handleCheckout} size="lg" className="w-full">
                        Finalizar Compra
                      </Button>
                    </div>
                  </>
                )}
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
