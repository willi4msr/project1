"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { CustomerStep } from "@/components/checkout/customer-step"
import { OrderStep } from "@/components/checkout/order-step"
import { PaymentStep } from "@/components/checkout/payment-step"
import { SuccessStep } from "@/components/checkout/success-step"
import { CheckoutProgress } from "@/components/checkout/checkout-progress"

export type CheckoutData = {
  customerId?: number
  orderId?: number
  customer?: {
    firstname: string
    lastname: string
    email: string
    telephone: string
    postcode: string
    address_street: string
    address_street_number: string
    address_street_complement?: string
    address_street_district: string
    address_city: string
    address_state: string
  }
  order?: {
    total: number
    products: Array<{
      sku: string
      name: string
      qty: number
      price: number
    }>
    shipping: number
    discount: number
  }
  payment?: {
    method: "creditcard" | "boleto" | "pix"
    transactionId?: string
  }
}

export default function CheckoutFlow() {
  const [currentStep, setCurrentStep] = useState(1)
  const [checkoutData, setCheckoutData] = useState<CheckoutData>({})

  useEffect(() => {
    const savedCart = localStorage.getItem("checkout_cart")
    if (savedCart) {
      const cartItems = JSON.parse(savedCart)
      const total = cartItems.reduce((sum: number, item: any) => sum + item.price * item.qty, 0)

      setCheckoutData((prev) => ({
        ...prev,
        order: {
          total,
          products: cartItems,
          shipping: 0,
          discount: 0,
        },
      }))
    }
  }, [])

  const updateCheckoutData = (data: Partial<CheckoutData>) => {
    setCheckoutData((prev) => ({ ...prev, ...data }))
  }

  const nextStep = () => setCurrentStep((prev) => Math.min(prev + 1, 4))
  const prevStep = () => setCurrentStep((prev) => Math.max(prev - 1, 1))

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 text-balance">Finalizar Compra</h1>
        <p className="text-muted-foreground">Complete seu pedido de forma rápida e segura</p>
      </div>

      <CheckoutProgress currentStep={currentStep} />

      <div className="grid lg:grid-cols-3 gap-8 mt-8">
        <div className="lg:col-span-2">
          <Card className="p-6">
            {currentStep === 1 && (
              <CustomerStep onNext={nextStep} updateData={updateCheckoutData} initialData={checkoutData.customer} />
            )}
            {currentStep === 2 && (
              <OrderStep
                onNext={nextStep}
                onBack={prevStep}
                updateData={updateCheckoutData}
                customerId={checkoutData.customerId}
                initialData={checkoutData.order}
              />
            )}
            {currentStep === 3 && (
              <PaymentStep
                onNext={nextStep}
                onBack={prevStep}
                updateData={updateCheckoutData}
                customerId={checkoutData.customerId}
                orderId={checkoutData.orderId}
              />
            )}
            {currentStep === 4 && <SuccessStep checkoutData={checkoutData} />}
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-8">
            <h3 className="text-lg font-semibold mb-4">Resumo do Pedido</h3>
            {checkoutData.order ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  {checkoutData.order.products.map((product, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {product.qty}x {product.name}
                      </span>
                      <span className="font-medium">R$ {(product.price * product.qty).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>R$ {checkoutData.order.total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Frete</span>
                    <span>R$ {checkoutData.order.shipping.toFixed(2)}</span>
                  </div>
                  {checkoutData.order.discount > 0 && (
                    <div className="flex justify-between text-sm text-green-600">
                      <span>Desconto</span>
                      <span>- R$ {checkoutData.order.discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold pt-2 border-t">
                    <span>Total</span>
                    <span>
                      R${" "}
                      {(checkoutData.order.total + checkoutData.order.shipping - checkoutData.order.discount).toFixed(
                        2,
                      )}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Adicione produtos ao carrinho para ver o resumo</p>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}
