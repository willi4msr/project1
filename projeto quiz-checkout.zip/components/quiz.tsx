"use client"

import { cn } from "@/lib/utils"

import React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import { Check, Trash2, ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { obfuscateEmail, obfuscatePhone } from "@/lib/data-obfuscation"
import Image from "next/image" // Import Image component
import { useRouter } from "next/navigation" // Import useRouter

import {
  getTrackingParams,
  trackLead,
  trackInitiateCheckout,
  trackPurchase,
  startPixPolling,
  stopAllPollings,
} from "@/lib/tracking-client-v3"

const TOTAL_PAGES = 22 // Changed TOTAL_PAGES from 21 to 22 to include thank you page
// const TOTAL_PAGES = 19

const QUIZ_PAGES = 14 // Quiz completes at page 14

type Answer = string | number | null

interface QuizState {
  currentPage: number
  isVisible: boolean
  shippingMethod: "pac" | "sedex" // Added shippingMethod to state
  selectedProduct?: { name: string; price: number }
  shippingCost?: number
  customerInfo?: {
    // Added customerInfo to state
    email: string
    telefone: string
    nome: string
  }
}

interface FormData {
  email: string
  phone: string
  name: string
  lastName: string
  cpf: string
  cep: string
  address: string
  number: string
  noNumber: boolean
  complement: string
  neighborhood: string
  city: string
  state: string
  country: string
  // </CHANGE> Removed gender and dateOfBirth as they're no longer collected
}

interface CreditCardData {
  cardNumber: string
  cardName: string
  expiryDate: string
  cvv: string
  installments: number
}

// Types from updates
interface ApiFormData {
  email: string
  phone: string
  name: string
  lastName: string
  cpf: string
  cep: string
  address: string
  number: string
  noNumber: boolean
  complement: string
  neighborhood: string
  city: string
  state: string
  country: string
}

// Removed the redeclaredObfuscateEmail andObfuscatePhone functions.
// They are now imported from "@/lib/data-obfuscation"

declare global {
  interface Window {
    fbq: any
  }
}

async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message)
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
  return hashHex
}

async function buildFacebookUserData({
  email,
  phone,
  name,
  city,
  state,
  cep,
  country = "BR",
}: {
  email?: string
  phone?: string
  name?: string
  city?: string
  state?: string
  cep?: string
  country?: string
}) {
  // Removed getFbParams and _fbc/_fbc cookie handling from here.
  // This function should only focus on building user_data from provided parameters.
  // Cookie handling is now managed in the useEffect hook.

  const user_data: any = {}

  // Hash PII fields with SHA256
  if (email) {
    const normalized = email.trim().toLowerCase()
    user_data.em = await sha256(normalized)
  }
  if (phone) {
    const cleaned = phone.replace(/\D/g, "")
    const normalized = cleaned.startsWith("55") ? `+${cleaned}` : `+55${cleaned}`
    user_data.ph = await sha256(normalized)
  }
  if (name) {
    const nameParts = name.trim().split(" ")
    const firstName =
      nameParts[0]
        ?.trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") || ""
    const lastName =
      nameParts
        .slice(1)
        .join(" ")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") || ""
    if (firstName) user_data.fn = await sha256(firstName)
    if (lastName) user_data.ln = await sha256(lastName)
  }
  if (city) {
    const normalized = city
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
    user_data.ct = await sha256(normalized)
  }
  if (state) {
    user_data.st = await sha256(state.toUpperCase())
  }
  if (cep) {
    user_data.zp = await sha256(cep.replace(/\D/g, ""))
  }
  if (country) {
    user_data.country = await sha256(country.toLowerCase())
  }

  // Add fbp/fbc WITHOUT hashing (as required by Meta)
  // These will be populated from cookies in the useEffect hook and passed to sendConversionEvent
  // For now, they are left out of buildFacebookUserData as it focuses on PII hashing.

  console.log("[v0] CAPI user_data built:", {
    em: user_data.em ? "hashed" : "missing",
    ph: user_data.ph ? "hashed" : "missing",
    fn: user_data.fn ? "hashed" : "missing",
    ln: user_data.ln ? "hashed" : "missing",
    ct: user_data.ct ? "hashed" : "missing",
    st: user_data.st ? "hashed" : "missing",
    zp: user_data.zp ? "hashed" : "missing",
    country: user_data.country ? "hashed" : "missing",
  })

  return user_data
}

const normalizeName = (name: string): string => {
  return name
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // Remove accents
}

const normalizeEmail = (email: string): string => {
  return email.trim().toLowerCase()
}

const normalizePhone = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, "") // Keep only numbers
  // Add +55 for Brazil if not present
  return cleaned.startsWith("55") ? `+${cleaned}` : `+55${cleaned}`
}

const getCookie = (name: string): string | null => {
  if (typeof document === "undefined") return null
  const nameEQ = name + "="
  const ca = document.cookie.split(";")
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === " ") c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

const getFbParams = (): { fbp: string | null; fbc: string | null } => {
  return {
    fbp: getCookie("_fbp"),
    fbc: getCookie("_fbc"),
  }
}

/*
async function saveFacebookTrackingData(
  orderId: string,
  data: {
    fbp?: string | null
    fbc?: string | null
    fbclid?: string | null
    eventSourceUrl?: string
    firstName?: string
    lastName?: string
    email?: string
    phone?: string
    city?: string
    state?: string
    zipCode?: string
    country?: string
  },
): Promise<void> {
  try {
    const payload = {
      ...data,
      orderId,
      eventSourceUrl: data.eventSourceUrl || window.location.href,
    }

    console.log("[v0] saveFacebookTrackingData payload:", payload)

    const response = await fetch("/api/checkout/save-tracking", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      console.error("Failed to save Facebook tracking data:", response.status, await response.text())
    } else {
      console.log("Facebook tracking data saved successfully")
      const result = await response.json()
      if (result.cookiesToSet && Array.isArray(result.cookiesToSet)) {
        result.cookiesToSet.forEach((cookie: string) => {
          document.cookie = cookie
        })
        console.log("[v0] Cookies set from API response:", result.cookiesToSet)
      }
    }
  } catch (error) {
    console.error("Error in saveFacebookTrackingData:", error)
  }
}
*/

const getPageName = (page: number): string => {
  switch (page) {
    case 1:
      return "Start"
    case 2:
      return "Gender"
    case 3:
      return "Age"
    case 4:
      return "Height"
    case 5:
      return "Current Weight"
    case 6:
      return "Desired Weight"
    case 7:
      return "Diet"
    case 8:
      return "Activity Level"
    case 9:
      return "Hunger Between Meals"
    case 10:
      return "Loading"
    case 11:
      return "Week 1 Instructions"
    case 12:
      return "Week 2 Instructions"
    case 13:
      return "Product Info"
    case 14:
      return "Checkout"
    case 15:
      return "Identification"
    case 16:
      return "Address"
    case 17:
      return "Shipping"
    case 18:
      return "Order Bump 2"
    case 19:
      return "Order Bump 1"
    case 20:
      return "Payment"
    case 21:
      return "PIX Generated"
    case 22: // Added page 22 - Thank you page
      return "Thank You Page"
    default:
      return "Unknown Page"
  }
}

function validateCPF(cpf: string): boolean {
  // Remove non-numeric characters
  const cleanCPF = cpf.replace(/\D/g, "")

  // Check if has 11 digits
  if (cleanCPF.length !== 11) return false

  // Check if all digits are the same
  if (/^(\d)\1{10}$/.test(cleanCPF)) return false

  // Validate first check digit
  let sum = 0
  for (let i = 0; i < 9; i++) {
    sum += Number.parseInt(cleanCPF.charAt(i)) * (10 - i)
  }
  let checkDigit = 11 - (sum % 11)
  if (checkDigit >= 10) checkDigit = 0
  if (checkDigit !== Number.parseInt(cleanCPF.charAt(9))) return false

  // Validate second check digit
  sum = 0
  for (let i = 0; i < 10; i++) {
    sum += Number.parseInt(cleanCPF.charAt(i)) * (11 - i)
  }
  checkDigit = 11 - (sum % 11)
  if (checkDigit >= 10) checkDigit = 0
  if (checkDigit !== Number.parseInt(cleanCPF.charAt(10))) return false

  return true
}

export default function Quiz({ formDataParam }: { formDataParam?: any }) {
  const router = useRouter() // Initialize useRouter
  const [state, setState] = useState<QuizState>({
    currentPage: 1,
    isVisible: true,
    shippingMethod: "sedex", // Default shipping method
  })
  const [orderBump1, setOrderBump1] = useState(false)
  const [orderBump2, setOrderBump2] = useState(false)
  const [orderBump1Active, setOrderBump1Active] = useState(false) // New state for Order Bump 1
  const [orderBump2Active, setOrderBump2Active] = useState(false) // New state for Order Bump 2
  const [cartOrderBump, setCartOrderBump] = useState(false)
  const [selectedShipping, setSelectedShipping] = useState<"pac" | "sedex">("sedex")
  const [paymentMethod, setPaymentMethod] = useState<"credit" | "pix">("pix")
  const [formData, setFormData] = useState<FormData>({
    email: "",
    phone: "",
    name: "",
    lastName: "",
    cpf: "",
    cep: "",
    address: "",
    number: "",
    noNumber: false,
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
    country: "Brasil",
  })
  const [cardData, setCardData] = useState<CreditCardData>({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
    installments: 1,
  })
  const [pixCode, setPixCode] = useState("")
  const [cartExpanded, setCartExpanded] = useState(true) // Set cart to always be expanded (true instead of false)
  const [timeLeft, setTimeLeft] = useState(600) // 10 minutes in seconds
  const [instructionsExpanded, setInstructionsExpanded] = useState(false)

  const [apiFormData, setApiFormData] = useState<FormData | null>(null)
  const [originalFormData, setOriginalFormData] = useState<FormData | null>(null)

  const [isProcessingPayment, setIsProcessingPayment] = useState(false)
  const [paymentError, setPaymentError] = useState<string | null>(null)
  const [customerId, setCustomerId] = useState<string | null>(null)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [paymentPollingInterval, setPaymentPollingInterval] = useState<NodeJS.Timeout | null>(null)
  const [isGeneratingPix, setIsGeneratingPix] = useState(false) // Added state for PIX generation
  const [cpfError, setCpfError] = useState<string>("") // Declare cpfError here
  const [isLoading, setIsLoading] = useState(false) // New loading state

  const [trackedEvents, setTrackedEvents] = useState<Set<string>>(new Set())

  const [hasTrackedViewContent, setHasTrackedViewContent] = useState(false)
  const [hasTrackedCompleteRegistration, setHasTrackedCompleteRegistration] = useState(false)
  const [hasTrackedInitiateCheckout, setHasTrackedInitiateCheckout] = useState(false)
  const [hasTrackedPurchase, setHasTrackedPurchase] = useState(false)
  const [trackedPurchases, setTrackedPurchases] = useState<Set<string>>(new Set())
  // </CHANGE>
  const activePollings = useRef<Record<string, NodeJS.Timeout>>({}) // Kept for now, might be replaced by stopAllPollings
  const sentPurchases = useRef<Set<string>>(new Set())
  // </CHANGE>

  useEffect(() => {
    return () => {
      stopAllPollings()
    }
  }, [])

  const pollingStopperRef = useRef<(() => void) | null>(null) // New ref for stopPixPolling

  const track = useCallback((event: string, properties?: Record<string, any>) => {
    console.log(`[v0] Tracking event: ${event}`, properties || "")
    // Replace with your actual analytics implementation (e.g., Google Analytics, Segment)
    if (window.fbq) {
      window.fbq("track", event, properties)
    }
    // Add other analytics providers here if needed
  }, [])

  const trackOnce = useCallback(
    (eventKey: string, callback: () => void) => {
      if (!trackedEvents.has(eventKey)) {
        setTrackedEvents((prev) => new Set(prev).add(eventKey))
        callback()
        console.log(`[v0] ${eventKey} tracked once`)
      }
      return !trackedEvents.has(eventKey) // Return true if it was tracked for the first time
    },
    [trackedEvents],
  )

  // Removed: const startPaymentPolling = useCallback(...)
  // Removed: const sendConversionEvent = useCallback(...)

  // Client-side tracking functions
  // These functions will now call the imported tracking functions directly or make API calls.

  // const sendConversionEvent = useCallback(
  //   async (eventName: string, eventData?: Record<string, any>) => {
  //     try {
  //       const eventId =
  //         eventData?.eventId || `${eventName.toLowerCase()}_${Date.now()}_${Math.random().toString(36).substring(7)}`

  //       // Build user_data using centralized function
  //       const user_data = await buildFacebookUserData({
  //         email: originalFormData?.email,
  //         phone: originalFormData?.phone,
  //         name: originalFormData?.name,
  //         city: originalFormData?.city,
  //         state: originalFormData?.state,
  //         cep: originalFormData?.cep,
  //         country: "BR",
  //       })

  //       // Add FBP and FBC cookies to the CAPI payload if they exist.
  //       const fbp = getCookie("_fbp") || ""
  //       const fbc = getCookie("_fbc") || ""
  //       // </CHANGE>

  //       const payload: any = {
  //         eventName,
  //         eventId,
  //         eventSourceUrl: window.location.href,
  //         userAgent: navigator.userAgent,
  //         user_data,
  //         // Add fbp and fbc to the payload directly.
  //         fbp: fbp || undefined,
  //         fbc: fbc || undefined,
  //         // </CHANGE>
  //       }

  //       // Add custom data if provided
  //       if (eventData?.customData) {
  //         payload.customData = eventData.customData
  //       }

  //       console.log("[v0] Sending CAPI event:", eventName, "with event_id:", eventId)
  //       console.log("[v0] CAPI Payload:", JSON.stringify(payload, null, 2)) // Log the entire payload for debugging

  //       const response = await fetch("/api/facebook-conversion", {
  //         method: "POST",
  //         headers: { "Content-Type": "application/json" },
  //         body: JSON.stringify(payload),
  //       })

  //       if (!response.ok) {
  //         const errorText = await response.text()
  //         let errorData
  //         try {
  //           errorData = JSON.parse(errorText)
  //         } catch {
  //           errorData = { message: errorText }
  //         }
  //         console.error(`[v0] CAPI ${eventName} failed:`, response.status, errorData)
  //       } else {
  //         console.log(`[v0] CAPI ${eventName} sent successfully`)
  //       }
  //     } catch (error) {
  //       console.error(`[v0] Error sending CAPI event:`, error)
  //     }
  //   },
  //   [originalFormData, track], // Removed redundant sendConversionEvent from dependency array if it's called inside
  // ) // </CHANGE>

  // Moved cookie initialization to a dedicated useEffect hook.
  useEffect(() => {
    if (typeof window !== "undefined") {
      const pixelId = process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID || "1118114006092334"

      // Check if pixel already initialized
      if (!(window as any).fbq) {
        ;((f: any, b: any, e: any, v: any, n?: any, t?: any, s?: any) => {
          if (f.fbq) return
          n = f.fbq = () => {
            n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments)
          }
          if (!f._fbq) f._fbq = n
          n.push = n
          n.loaded = !0
          n.version = "2.0"
          n.queue = []
          t = b.createElement(e)
          t.async = !0
          t.src = v
          s = b.getElementsByTagName(e)[0]
          s.parentNode.insertBefore(t, s)
        })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js")
        ;(window as any).fbq("init", pixelId)
        console.log(`[v0] Facebook Pixel initialized: ${pixelId}`)
      }

      // Set _fbp cookie if it doesn't exist
      const existingFbp = getCookie("_fbp")
      if (!existingFbp) {
        const timestamp = Date.now()
        const randomNum = Math.floor(Math.random() * 10000000000)
        const newFbpCookie = `fb.1.${timestamp}.${randomNum}`
        document.cookie = `_fbp=${newFbpCookie}; max-age=7776000; domain=.protocolo30dias.com; path=/; SameSite=Lax`
        console.log(`[v0] Created _fbp cookie: ${newFbpCookie}`)
      }

      // Set _fbc cookie if it doesn't exist and fbclid is present in URL
      const urlParams = new URLSearchParams(window.location.search)
      const fbclid = urlParams.get("fbclid")
      const existingFbc = getCookie("_fbc")
      if (fbclid && !existingFbc) {
        const fbcCookie = `fb.1.${Date.now()}.${fbclid}`
        document.cookie = `_fbc=${fbcCookie}; max-age=7776000; domain=.protocolo30dias.com; path=/; SameSite=Lax`
        console.log(`[v0] Created _fbc cookie from fbclid: ${fbcCookie}`)
      }
    }
  }, []) // Run once on mount
  // </CHANGE>

  useEffect(() => {
    const pageStartTime = Date.now()

    // track("Quiz Page View", {
    //   page: state.currentPage,
    //   pageName: getPageName(state.currentPage),
    //   progress: `${state.currentPage}/${TOTAL_PAGES}`,
    // })

    return () => {
      const timeSpent = Math.round((Date.now() - pageStartTime) / 1000)
      // track("Quiz Page Time", {
      //   page: state.currentPage,
      //   pageName: getPageName(state.currentPage),
      //   timeSpent: timeSpent,
      // })
    }
  }, [state.currentPage])

  useEffect(() => {
    if (state.currentPage === 21) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 0) {
            clearInterval(timer)
            return 0
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(timer)
    }
  }, [state.currentPage])

  useEffect(() => {
    if (state.currentPage === 14) {
      trackOnce("CompleteRegistration", () => {
        if (typeof window !== "undefined" && (window as any).fbq) {
          ;(window as any).fbq("track", "CompleteRegistration")
          console.log("[v0] Pixel event dispatched: CompleteRegistration")
        }
        // CAPI só será enviado para dados completos (InitiateCheckout, Purchase)
      })
    }
  }, [state.currentPage, trackOnce])

  useEffect(() => {
    if (state.currentPage === 15) {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }, [state.currentPage])

  useEffect(() => {
    if (state.currentPage === 16) {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }, [state.currentPage])

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (state.currentPage < TOTAL_PAGES) {
        // track("Quiz Abandoned", {
        //   page: state.currentPage,
        //   pageName: getPageName(state.currentPage),
        //   progress: `${state.currentPage}/${TOTAL_PAGES}`,
        // })
      }
    }

    window.addEventListener("beforeunload", handleBeforeUnload)
    return () => window.removeEventListener("beforeunload", handleBeforeUnload)
  }, [state.currentPage]) // Dependency array includes state.currentPage

  // The polling should continue running while on page 21 to detect payment

  useEffect(() => {
    // Cleanup polling when the component unmounts
    return () => {
      if (pollingStopperRef.current) {
        pollingStopperRef.current()
      }
    }
  }, []) // Empty dependency array - only runs on mount/unmount

  const calculateTotal = useCallback(() => {
    let subtotal = 0.0 // Base product price is 0 for the free offer

    // Order bumps
    if (orderBump2Active) subtotal += 49.9
    if (orderBump1Active) subtotal += 29.9
    if (cartOrderBump) subtotal += 19.9

    const shippingPrice = selectedShipping === "sedex" ? 24.9 : 18.9
    return subtotal + shippingPrice
  }, [orderBump1Active, orderBump2Active, cartOrderBump, selectedShipping])

  useEffect(() => {
    // Cleanup polling when the component unmounts or when currentPage changes and polling should stop
    return () => {
      if (paymentPollingInterval) {
        console.log("[v0] Cleaning up old polling interval on unmount/page change")
        clearInterval(paymentPollingInterval)
      }
      // Cleanup new polling system
      if (pollingStopperRef.current) {
        pollingStopperRef.current()
      }
    }
  }, [paymentPollingInterval]) // Dependency on paymentPollingInterval to ensure cleanup

  const handleAnswer = (answer: string | number) => {
    // track("Quiz Answer", {
    //   page: state.currentPage,
    //   pageName: getPageName(state.currentPage),
    //   answer: answer,
    // })

    setState((prev) => ({ ...prev, isVisible: false }))
    setTimeout(() => {
      setState((prev) => ({
        currentPage: Math.min(prev.currentPage + 1, TOTAL_PAGES),
        isVisible: true,
      }))
    }, 300)
  }

  const handleBack = useCallback(() => {
    setState((prev) => ({ ...prev, isVisible: false }))
    setTimeout(() => {
      setState((prev) => ({
        currentPage: Math.max(prev.currentPage - 1, 1),
        isVisible: true,
      }))
    }, 300)
  }, [])

  const nextPage = useCallback(() => {
    setState((prev) => ({
      ...prev,
      currentPage: Math.min(prev.currentPage + 1, TOTAL_PAGES),
    }))
  }, [])

  const prevPage = useCallback(() => {
    if (state.currentPage > 1) {
      setState((prev) => ({
        ...prev,
        currentPage: prev.currentPage - 1,
      }))
    }
  }, [state.currentPage])

  const handleContinue = useCallback(
    async (override?: boolean) => {
      console.log("[v0] handleContinue called, currentPage:", state.currentPage)

      // Page 15: Nome e Email
      if (state.currentPage === 15) {
        if (!formData.name || !formData.email || !formData.phone || !formData.cpf) {
          alert("Por favor, preencha todos os campos obrigatórios.")
          return
        }

        // Check for CPF error before proceeding
        if (cpfError) {
          alert("Por favor, corrija o CPF antes de continuar.")
          return
        }

        // Salvar dados originais
        setOriginalFormData({ ...formData })

        const [firstName, ...lastNameParts] = formData.name.trim().split(" ")
        const lastName = lastNameParts.join(" ")

        const transformedData = {
          ...formData,
          email: obfuscateEmail(formData.email, firstName, lastName),
          phone: obfuscatePhone(formData.phone),
        }
        setApiFormData(transformedData)

        // </CHANGE> Removed sensitive data logs - only log that data was processed
        console.log("[v0] User data processed and ready for page 16")
        // </CHANGE>

        nextPage()
        return
      }

      // Determine the answer based on the current page and relevant state
      let answerData: any = "continue" // Default for pages without specific answers

      if (state.currentPage === 2) {
        // Gender
        answerData = formData.gender // Use formData.gender for the answer
      } else if (state.currentPage === 3) {
        // Age
        // This would need a specific state to capture age selection if not directly in formData
        // For now, using a placeholder if age is not directly managed
        answerData = "age_selected"
      } else if (state.currentPage === 4) {
        // Height
        // This would need a specific state to capture height selection if not directly in formData
        // For now, using a placeholder if height is not directly managed
        answerData = formData.phone // Assuming phone is part of height step, adjust if needed
      } else if (state.currentPage === 5) {
        // Current Weight
        // This would need a specific state to capture current weight selection if not directly in formData
        // For now, using a placeholder if current weight is not directly managed
        answerData = formData.cpf // Assuming CPF is part of weight step, adjust if needed
      } else if (state.currentPage === 6) {
        // Desired Weight
        // This would need a specific state to capture desired weight selection if not directly in formData
        // For now, using a placeholder if desired weight is not directly managed
        answerData = formData.cep // Assuming CEP is part of weight step, adjust if needed
      } else if (state.currentPage === 7) {
        // Diet Quality
        // This would need a specific state to capture diet quality selection if not directly in formData
        // For now, using a placeholder if diet quality is not directly managed
        answerData = formData.address // Assuming address is part of diet step, adjust if needed
      } else if (state.currentPage === 8) {
        // Activity Level
        // This would need a specific state to capture activity level selection if not directly in formData
        // For now, using a placeholder if activity level is not directly managed
        answerData = formData.number // Assuming number is part of activity step, adjust if needed
      } else if (state.currentPage === 9) {
        // Hunger Between Meals
        // This would need a specific state to capture hunger between meals selection if not directly in formData
        // For now, using a placeholder if hunger between meals is not directly managed
        answerData = formData.complement // Assuming complement is part of hunger step, adjust if needed
      } else if (state.currentPage === 16) {
        // Address
        answerData = {
          cep: formData.cep,
          address: formData.address,
          number: formData.number,
          complement: formData.complement,
          neighborhood: formData.neighborhood,
          city: formData.city,
          state: formData.state,
        }
      } else if (state.currentPage === 17) {
        // Shipping
        answerData = selectedShipping
      } else if (state.currentPage === 18) {
        // Order Bump 2
        answerData = orderBump2Active
      } else if (state.currentPage === 19) {
        // Order Bump 1
        answerData = orderBump1Active
      }
      // Add more conditions for other pages if needed

      // track("Quiz Answer", {
      //   page: state.currentPage,
      //   pageName: getPageName(state.currentPage),
      //   answer: answerData,
      // })

      // Update apiFormData with address data from formData on page 16
      if (state.currentPage === 16) {
        setApiFormData((prev) => ({
          ...(prev || formData), // Merge with existing or use formData if prev is null
          cep: formData.cep,
          address: formData.address,
          number: formData.number,
          noNumber: formData.noNumber,
          complement: formData.complement,
          neighborhood: formData.neighborhood,
          city: formData.city,
          state: formData.state,
          country: formData.country,
        }))
        console.log("[v0] Updated apiFormData with address data from page 16")
      }

      setState((prev) => ({ ...prev, isVisible: false }))
      setTimeout(() => {
        nextPage()
        setState((prev) => ({ ...prev, isVisible: true }))
      }, 300)
    },
    [
      state.currentPage,
      formData,
      nextPage,
      calculateTotal,
      // sendConversionEvent, // Removed as it's no longer used directly in this function
      cpfError,
      setApiFormData,
      originalFormData,
      apiFormData,
      selectedShipping,
      orderBump1Active,
      orderBump2Active,
      track, // Added track as a dependency
      cpfError, // Re-added cpfError as it's used inside
    ],
  ) // Added calculateTotal and sendConversionEvent as dependencies

  const progress = Math.min((state.currentPage / QUIZ_PAGES) * 100, 100) // Changed progress calculation
  const isQuizComplete = state.currentPage > QUIZ_PAGES

  const calculateCart = useCallback(() => {
    let subtotal = 0

    // Order bumps
    if (orderBump2Active) subtotal += 49.9
    if (orderBump1Active) subtotal += 29.9
    if (cartOrderBump) subtotal += 19.9 // Add cart order bump

    const shippingPrice = selectedShipping === "sedex" ? 24.9 : 18.9
    const total = subtotal + shippingPrice

    console.log(
      "[v0] calculateCart - selectedShipping:",
      selectedShipping,
      "shippingPrice:",
      shippingPrice,
      "cartOrderBump:",
      cartOrderBump,
    )

    // API payload: always send the same product name with calculated total
    const apiPayload = {
      productName: "Protocolo 30 Dias — Inova Mulher",
      totalAmount: total,
    }

    return {
      subtotal,
      shippingPrice,
      total,
      apiPayload, // This is what should be sent to the payment API
    }
  }, [orderBump1Active, orderBump2Active, cartOrderBump, selectedShipping]) // Added cartOrderBump dependency

  useEffect(() => {
    return () => {
      if (pollingStopperRef.current) {
        pollingStopperRef.current()
        console.log("[v0] Polling stopped on unmount.")
      }
    }
  }, [])

  const handleGeneratePix = async () => {
    try {
      setIsLoading(true) // Use setIsLoading instead of setIsGeneratingPix
      setPaymentError(null)

      if (!originalFormData) {
        throw new Error("Dados do formulário não encontrados.")
      }

      // Ensure required fields are present
      if (!formData.name || !formData.email || !formData.phone || !formData.cpf) {
        throw new Error("Por favor, preencha todos os dados de identificação.")
      }
      if (!formData.cep || !formData.address || !formData.neighborhood || !formData.city || !formData.state) {
        throw new Error("Por favor, preencha todos os dados de endereço.")
      }
      if (!formData.number && !formData.noNumber) {
        throw new Error("Por favor, preencha o número do endereço ou marque S/N.")
      }
      if (!selectedShipping) {
        throw new Error("Por favor, selecione uma opção de frete.")
      }

      const cart = calculateCart()
      console.log("[v0] Generating PIX for order with total:", cart.total)

      // Use v3 tracking client functions
      const trackingParams = getTrackingParams()
      const userData = {
        email: originalFormData.email,
        phone: originalFormData.phone,
        name: originalFormData.name,
      }
      console.log("[v0] Tracking params:", trackingParams)

      await trackLead(null, calculateTotal(), trackingParams, userData)

      const obfuscatedData = {
        ...formData, // Use formData directly here for the API call
        email: obfuscateEmail(
          formData.email,
          formData.name?.split(" ")[0] || "",
          formData.name?.split(" ").slice(1).join(" ") || "",
        ),
        phone: obfuscatePhone(formData.phone),
      }

      const response = await fetch("/api/checkout/payment/pix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...obfuscatedData,
          originalEmail: originalFormData.email, // Original email for backend tracking
          originalPhone: originalFormData.phone, // Original phone for backend tracking
          products: [
            {
              name: "Protocolo 30 Dias — Inova Mulher",
              quantity: 1,
              price: cart.total,
            },
          ],
          totalAmount: cart.total,
          ...trackingParams,
        }),
      })
      // </CHANGE>

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.message || "Falha ao gerar código PIX")
      }

      const result = await response.json()

      if (!result.data?.pix_code) {
        console.error("[v0] No PIX code found in response:", result)
        throw new Error("O código PIX não foi retornado pela API.")
      }

      setPixCode(result.data.pix_code)
      setOrderId(result.data.order_id)

      await trackInitiateCheckout(result.data.order_id, cart.total, trackingParams, userData)

      // Transition to page 21 AFTER setting pixCode and orderId
      setState((prev) => ({ ...prev, currentPage: 21, isVisible: false }))
      setTimeout(() => {
        setState((prev) => ({ ...prev, isVisible: true }))
      }, 300)

      const stopPixPolling = await startPixPolling(result.data.order_id, cart.total, trackingParams, userData, {
        maxAttempts: 60,
        intervalMs: 5000,
        onPaymentConfirmed: () => {
          console.log("[v0] Payment confirmed, redirecting to thank you page")
          setState((prev) => ({ ...prev, currentPage: 22, isVisible: false }))
          setTimeout(() => {
            setState((prev) => ({ ...prev, isVisible: true }))
          }, 300)
        },
      })
      // </CHANGE>

      pollingStopperRef.current = stopPixPolling // Store the stop function

      console.log("[v0] PIX code generated and polling started for order:", result.data.order_id)
    } catch (error) {
      console.error("[v0] Error generating PIX:", error)
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
      setPaymentError(errorMessage)
      // Track error
      track("PIX Generation Error", {
        action: "pix_generation_error",
        error: errorMessage,
        url: window.location.href,
      })
    } finally {
      setIsLoading(false) // Use setIsLoading
    }
  }

  useEffect(() => {
    return () => {
      if (pollingStopperRef.current) {
        pollingStopperRef.current()
        console.log("[v0] Polling stopped on unmount.")
      }
    }
  }, [])

  const processPayment = async (
    method: "pix" | "credit" = "pix",
  ): Promise<{ pixCode?: string; orderId: string } | null> => {
    console.log("[v0] Starting payment process with method:", method)
    console.log("[v0] Current formData:", formData)
    console.log("[v0] Current apiFormData:", apiFormData)

    if (!apiFormData?.name || !apiFormData?.email || !apiFormData?.phone || !apiFormData?.cpf) {
      const message = "Por favor, preencha todos os dados de identificação"
      alert(message)
      console.error("[v0] Missing identification data:", { apiFormData })
      setPaymentError(message)
      return null
    }

    if (
      !apiFormData?.cep ||
      !apiFormData?.address ||
      !apiFormData?.neighborhood ||
      !apiFormData?.city ||
      !apiFormData?.state
    ) {
      const message = "Por favor, preencha todos os dados de endereço"
      alert(message)
      console.error("[v0] Missing address data:", {
        cep: apiFormData?.cep,
        address: apiFormData?.address,
        neighborhood: apiFormData?.neighborhood,
        city: apiFormData?.city,
        state: apiFormData?.state,
      })
      setPaymentError(message)
      return null
    }

    if (!apiFormData?.number && !apiFormData?.noNumber) {
      const message = "Por favor, preencha o número do endereço ou marque S/N"
      alert(message)
      console.error("[v0] Missing number data")
      setPaymentError(message)
      return null
    }

    if (!selectedShipping) {
      const message = "Por favor, selecione uma opção de frete"
      alert(message)
      console.error("[v0] No shipping selected")
      setPaymentError(message)
      return null
    }

    setIsProcessingPayment(true)
    setPaymentError(null)

    try {
      console.log("[v0] Step 1: Creating customer...")
      const nameParts = apiFormData.name.trim().split(" ")
      const firstname = nameParts[0] || ""
      const lastname = nameParts.slice(1).join(" ") || nameParts[0] || ""

      console.log("[v0] Name parts:", { firstname, lastname, fullName: apiFormData.name })
      console.log("[v0] Contact info:", {
        email: apiFormData.email,
        telephone: apiFormData.phone,
        cpf: apiFormData.cpf,
      })
      console.log("[v0] Address info:", {
        postcode: apiFormData.cep,
        address_street: apiFormData.address,
        address_street_number: apiFormData.number || "S/N",
        address_street_district: apiFormData.neighborhood,
        address_city: apiFormData.city,
        address_state: apiFormData.state,
      })

      const customerPayload = {
        firstname: firstname,
        lastname: lastname,
        email: apiFormData.email,
        telephone: apiFormData.phone,
        document_number: apiFormData.cpf.replace(/\D/g, ""),
        origin_url: "https://protocolo30dias.com/",
      }

      console.log("[v0] ========== CUSTOMER PAYLOAD ==========")
      console.log(JSON.stringify(customerPayload, null, 2))
      console.log("[v0] =======================================")

      const customerResponse = await fetch("/api/checkout/customer-simple", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customerPayload),
      })

      console.log("[v0] Customer response status:", customerResponse.status)
      const customerData = await customerResponse.json()
      console.log("[v0] ========== CUSTOMER RESPONSE ==========")
      console.log(JSON.stringify(customerData, null, 2))
      console.log("[v0] ==========================================")

      if (!customerResponse.ok) {
        console.error("[v0] Customer creation failed:", customerData)
        throw new Error(customerData.error || JSON.stringify(customerData.errors || customerData))
      }

      const customerId = customerData.data?.id || customerData.customer_id
      setCustomerId(customerId)
      console.log("[v0] Customer created with ID:", customerId)

      console.log("[v0] Step 2: Creating order...")
      const cart = calculateCart()

      // The InitiateCheckout with orderId-based event_id is fired after order creation (line ~1387)

      const orderPayload = {
        customer_id: customerId,
        products: [
          {
            sku: "PROTOCOLO-30-DIAS",
            name: "Protocolo 30 Dias — Inova Mulher",
            qty: 1,
            price: cart.total,
          },
        ],
        total: cart.total,
        digital_product: 1,
        origin_url: "https://protocolo30dias.com/",
      }

      console.log("[v0] Order payload:", orderPayload)

      const orderResponse = await fetch("/api/checkout/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload),
      })

      console.log("[v0] Order response status:", orderResponse.status)
      const orderData = await orderResponse.json()
      console.log("[v0] Order data:", orderData)

      if (!orderResponse.ok) {
        throw new Error(orderData.error || "Erro ao criar pedido")
      }

      const createdOrderId = orderData.data?.id || orderData.order_id
      setOrderId(createdOrderId)
      console.log("[v0] Order created with ID:", createdOrderId)

      /*
      const { fbp: currentFbp, fbc: currentFbc } = getFbParams()
      const urlParams = new URLSearchParams(window.location.search)
      await saveFacebookTrackingData(String(createdOrderId), {
        fbp: currentFbp,
        fbc: currentFbc,
        fbclid: urlParams.get("fbclid"),
        email: originalFormData?.email || "",
        phone: originalFormData?.phone || "",
        firstName: firstname,
        lastName: lastname,
        city: originalFormData?.city || "",
        state: originalFormData?.state || "",
        zipCode: originalFormData?.cep || "",
        country: "BR",
      })
      */
      console.log("[v0] Saved Facebook tracking data for order:", createdOrderId)

      console.log("[v0] Step 3: Processing payment via", method)
      // Step 3: Process payment
      if (method === "pix") {
        // Use v3 tracking client functions
        const { fbp, fbc, fbclid, sessionId } = getTrackingParams()
        const pixPayload = {
          order_id: createdOrderId,
          customer_id: customerId,
          cpf: apiFormData.cpf.replace(/\D/g, ""),
          fbp,
          fbc,
          sessionId,
        }

        console.log("[v0] PIX payload:", pixPayload)

        const pixResponse = await fetch("/api/checkout/payment/pix", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(pixPayload),
        })

        console.log("[v0] PIX response status:", pixResponse.status)
        const pixData = await pixResponse.json()
        console.log("[v0] ========== PIX RESPONSE DATA ==========")
        console.log(JSON.stringify(pixData, null, 2))
        console.log("[v0] ==========================================")

        if (!pixResponse.ok) {
          throw new Error(pixData.error || "Erro ao gerar PIX")
        }

        const extractedPixCode =
          pixData.data?.pix_emv ||
          pixData.pix_emv ||
          pixData.data?.pix_code ||
          pixData.pix_code ||
          pixData.data?.qrcode_text ||
          pixData.qrcode_text ||
          ""

        console.log("[v0] Extracted PIX code:", extractedPixCode ? `${extractedPixCode.substring(0, 50)}...` : "EMPTY")

        if (!extractedPixCode) {
          console.error("[v0] No PIX code found in response. Full data:", pixData)
          alert("Erro: Código PIX não foi gerado. Verifique os logs.")
          return null
        }

        setPixCode(extractedPixCode)
        // Transition to page 21 AFTER setting pixCode
        setState((prev) => ({ ...prev, currentPage: 21, isVisible: false }))
        setTimeout(() => {
          setState((prev) => ({ ...prev, isVisible: true }))
        }, 300)

        // startPixPolling is handled in handleGeneratePix now, which is called on page 20
        // This section is for credit card, but PIX logic is duplicated here for clarity if needed,
        // though ideally handleGeneratePix should be the sole entry point for PIX.

        // Track Vercel Analytics event for PIX generation
        track("Quiz PIX Generated", {
          action: "generate_pix",
          order_id: createdOrderId,
          url: window.location.href,
        })
        return { pixCode: extractedPixCode, orderId: createdOrderId }
      } else if (method === "credit") {
        // Use v3 tracking client functions
        const { fbp, fbc, fbclid, sessionId } = getTrackingParams()
        const creditCardPayload = {
          ...cardData,
          installments: cardData.installments || 1,
          order_id: createdOrderId,
          customer_id: customerId,
          fbp,
          fbc,
          sessionId,
        }

        console.log("[v0] Credit Card payload:", creditCardPayload)

        const creditResponse = await fetch("/api/checkout/payment/credit-card", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(creditCardPayload),
        })

        console.log("[v0] Credit card response status:", creditResponse.status)
        const creditData = await creditResponse.json()
        console.log("[v0] Credit card response data:", creditData)

        if (!creditResponse.ok) {
          throw new Error(creditData.error || "Erro ao processar pagamento com cartão")
        }

        // Redirecionar para página de sucesso após a confirmação do pagamento
        // O evento Purchase será disparado pelo polling quando o pagamento for confirmado
        // Track Vercel Analytics event for purchase completion
        track("Quiz Purchase", {
          action: "purchase",
          order_id: createdOrderId,
          value: cart.total,
          currency: "BRL",
          url: window.location.href,
        })
        return { orderId: createdOrderId }
      }
    } catch (error) {
      console.error("[v0] Payment error:", error)
      const errorMessage = error instanceof Error ? error.message : "Erro ao processar pagamento"
      setPaymentError(errorMessage)
      alert(`Erro ao processar pagamento: ${errorMessage}`)
      // Track Vercel Analytics event for payment error
      track("Quiz Payment Error", {
        action: "payment_error",
        error: errorMessage,
        url: window.location.href,
      })
      return null
    } finally {
      setIsProcessingPayment(false)
    }
    return null // Ensure a return value
  }

  const generatePixCode = async () => {
    const cart = calculateCart()
    try {
      setIsLoading(true)
      setPaymentError(null)

      if (!formData.name || !formData.email || !formData.phone || !formData.cpf) {
        throw new Error("Por favor, preencha todos os dados de identificação.")
      }
      if (!formData.cep || !formData.address || !formData.neighborhood || !formData.city || !formData.state) {
        throw new Error("Por favor, preencha todos os dados de endereço.")
      }
      if (!formData.number && !formData.noNumber) {
        throw new Error("Por favor, preencha o número do endereço ou marque S/N.")
      }
      if (!selectedShipping) {
        throw new Error("Por favor, selecione uma opção de frete.")
      }

      console.log("[v0] Generating PIX for order with total:", cart.total)

      // Use v3 tracking client functions
      const { fbp, fbc, fbclid, sessionId } = getTrackingParams()
      console.log("[v0] Tracking params:", { fbp, fbc, fbclid, sessionId })

      trackLead(originalFormData?.email || "", originalFormData?.phone || "", {
        fbp,
        fbc,
        sessionId,
      })

      const obfuscatedData = {
        ...formData, // Use formData directly here for the API call
        email: obfuscateEmail(
          formData.email,
          formData.name?.split(" ")[0] || "",
          formData.name?.split(" ").slice(1).join(" ") || "",
        ),
        phone: obfuscatePhone(formData.phone),
      }

      const response = await fetch("/api/checkout/payment/pix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...obfuscatedData,
          products: [
            {
              name: "Protocolo 30 Dias — Inova Mulher",
              quantity: 1,
              price: cart.total,
            },
          ],
          totalAmount: cart.total,
          fbp,
          fbc,
          sessionId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Falha ao gerar código PIX")
      }

      const result = await response.json()

      if (!result.data?.pix_code) {
        console.error("[v0] No PIX code found in response:", result)
        throw new Error("O código PIX não foi retornado pela API.")
      }

      setPixCode(result.data.pix_code)
      setOrderId(result.data.order_id)

      trackInitiateCheckout(result.data.order_id, cart.total, {
        fbp,
        fbc,
        sessionId,
      })

      setState((prev) => ({ ...prev, currentPage: 21, isVisible: false }))
      setTimeout(() => {
        setState((prev) => ({ ...prev, isVisible: true }))
      }, 300)

      const stopPixPolling = await startPixPolling(result.data.order_id, async () => {
        console.log(`[v0] Payment confirmed! Order: ${result.data.order_id}`)

        trackPurchase(result.data.order_id, cart.total, {
          fbp,
          fbc,
          sessionId,
        })

        router.push(
          `/obrigado?order_id=${result.data.order_id}&value=${cart.total}&email=${encodeURIComponent(
            originalFormData?.email || "",
          )}&phone=${encodeURIComponent(originalFormData?.phone || "")}&name=${encodeURIComponent(
            originalFormData?.name || "",
          )}&source=new-system&fbp=${encodeURIComponent(fbp)}&fbc=${encodeURIComponent(fbc)}&fbclid=${encodeURIComponent(fbclid)}`,
        )
      })

      pollingStopperRef.current = stopPixPolling

      console.log("[v0] PIX code generated and polling started for order:", result.data.order_id)
    } catch (error) {
      console.error("[v0] Error generating PIX:", error)
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
      setPaymentError(errorMessage)
      alert(`Erro ao gerar PIX: ${errorMessage}`)

      track("PIX Generation Error", {
        action: "pix_generation_error",
        error: errorMessage,
        url: window.location.href,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const processCreditCardPayment = async () => {
    setIsProcessingPayment(true)
    setPaymentError(null)

    try {
      const cart = calculateCart()
      // Use v3 tracking client functions
      const { fbp, fbc, fbclid, sessionId } = getTrackingParams()

      const result = await processPayment("credit")

      if (result) {
        console.log("[v0] Credit card payment initiated")
        // Redirecionar para página de sucesso após a confirmação do pagamento
        // O evento Purchase será disparado pelo polling quando o pagamento for confirmado
        // Track Vercel Analytics event for purchase completion
        track("Quiz Purchase", {
          action: "purchase",
          order_id: result.orderId,
          value: cart.total,
          currency: "BRL",
          url: window.location.href,
        })
      } else {
        setPaymentError("Erro ao processar pagamento. Tente novamente.")
      }
    } catch (error) {
      console.error("[v0] Error processing credit card payment:", error)
      setPaymentError("Erro ao processar pagamento. Tente novamente.")
    } finally {
      setIsProcessingPayment(false)
    }
  }

  const copyPixCode = () => {
    // Try modern clipboard API first
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(pixCode)
        .then(() => {
          console.log("[v0] PIX code copied successfully via Clipboard API")
          alert("Código PIX copiado!")
        })
        .catch((err) => {
          console.log("[v0] Clipboard API failed, using fallback method:", err)
          // Fallback for iframes and older browsers
          copyPixCodeFallback()
        })
    } else {
      console.log("[v0] Clipboard API not available, using fallback method")
      // Fallback for iframes and older browsers
      copyPixCodeFallback()
    }
  }

  // Fallback method that works in iframes
  const copyPixCodeFallback = () => {
    const textArea = document.createElement("textarea")
    textArea.value = pixCode
    textArea.style.position = "fixed"
    textArea.style.left = "-999999px"
    textArea.style.top = "-999999px"
    document.body.appendChild(textArea)
    textArea.focus()
    textArea.select()

    try {
      const successful = document.execCommand("copy")
      if (successful) {
        console.log("[v0] PIX code copied successfully via fallback method")
        alert("Código PIX copiado!")
      } else {
        console.log("[v0] Fallback copy failed")
        alert("Não foi possível copiar automaticamente. Por favor, selecione e copie o código manualmente.")
      }
    } catch (err) {
      console.log("[v0] Fallback copy error:", err)
      alert("Não foi possível copiar automaticamente. Por favor, selecione e copie o código manualmente.")
    }

    document.body.removeChild(textArea)
  }

  const renderPage = () => {
    console.log("[v0] Rendering page:", state.currentPage)

    // Page 20: Payment (PIX Only)
    if (state.currentPage === 20) {
      console.log("[v0] Rendering Payment Page (page 20)")
      const itemCount = 1 + (orderBump2Active ? 1 : 0) + (orderBump1Active ? 1 : 0)
      const cart = calculateCart()

      return (
        <div className="min-h-screen bg-gray-50 pb-safe">
          <div className="mx-auto max-w-md p-4">
            {/* Logo */}
            <div className="mb-6 flex items-center justify-between">
              <img src="/images/logo-quiz.png" alt="Logo" className="h-12 w-auto" />
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-[#22c55e] rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div className="text-right">
                  <div className="text-[#22c55e] font-bold text-sm">PAGAMENTO</div>
                  <div className="text-[#22c55e] font-bold text-xs">100% SEGURO</div>
                </div>
              </div>
            </div>

            {paymentError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                <p className="font-semibold">Erro ao processar pagamento:</p>
                <p className="text-sm">{paymentError}</p>
              </div>
            )}

            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-gray-900">Seu carrinho</h2>
                <div className="w-8 h-8 bg-[#22c55e] rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {itemCount}
                </div>
              </div>

              {/* Cart Items */}
              <div className="space-y-4">
                {/* Base Product */}
                <div className="flex gap-3">
                  <img src="/images/produto-30.png" alt="Produto" className="w-16 h-16 object-contain" />
                  <div className="flex-1">
                    <div className="font-semibold text-gray-900 text-sm">OzemFit PLUS 2x mais efeito</div>
                    <div className="text-gray-500 text-sm">30 Unidades</div>
                  </div>
                  <div className="text-sm text-gray-500">1 un.</div>
                </div>

                {(orderBump1Active || orderBump2Active) && (
                  <>
                    <div className="text-sm font-semibold text-gray-700">1 oferta adquirida</div>
                    <div className="border-2 border-dashed border-[#22c55e] rounded-lg p-3 bg-[#22c55e]/5">
                      <div className="flex gap-3">
                        <img src="/images/produto-90.png" alt="90 Unidades" className="w-16 h-16 object-contain" />
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 text-sm">OzemFit PLUS</div>
                          <div className="text-gray-500 text-sm">90 Unidades</div>
                          <div className="mt-1 flex flex-wrap items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">
                              1x de R${orderBump2Active ? "49,90" : "29,90"}
                            </span>
                            <span className="bg-[#22c55e] text-white text-xs font-bold px-2 py-1 rounded whitespace-nowrap">
                              R$100,0 OFF ✓
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {selectedShipping === "pac" && !orderBump1Active && !orderBump2Active && (
                  <div className="border-2 border-[#22c55e] rounded-lg p-4 bg-gradient-to-br from-[#22c55e]/5 to-white">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                            OFERTA EXCLUSIVA
                          </span>
                          <span className="text-xs text-gray-500">Apenas no carrinho</span>
                        </div>
                        <h3 className="font-bold text-gray-900 text-base">
                          Adicione +90 Unidades e ganhe Frete Sedex por R$ 19,90
                        </h3>
                      </div>
                      {cartOrderBump && (
                        <button
                          onClick={() => {
                            setCartOrderBump(false)
                            track("Quiz Remove Cart Order Bump", {
                              action: "remove_bump",
                              value: 19.9,
                              url: window.location.href,
                            })
                          }}
                          className="text-gray-400 hover:text-red-500 ml-2"
                        >
                          ✕
                        </button>
                      )}
                    </div>

                    {!cartOrderBump ? (
                      <>
                        <div className="flex gap-3 mb-3">
                          <img src="/images/produto-90.png" alt="90 Unidades" className="w-16 h-16 object-contain" />
                          <div className="flex-1">
                            <div className="font-semibold text-gray-900 text-sm">OzemFit PLUS + Sedex</div>
                            <div className="text-gray-500 text-sm">90 Unidades</div>
                            <div className="mt-1 flex items-center gap-2">
                              <span className="font-bold text-[#22c55e] text-lg">R$ 19,90</span>
                              <span className="text-gray-400 line-through text-sm">R$ 149,90</span>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setCartOrderBump(true)
                            track("Quiz Add Cart Order Bump", {
                              action: "add_bump",
                              value: 19.9,
                              url: window.location.href,
                            })
                          }}
                          className="w-full bg-[#22c55e] text-white py-3 px-4 rounded-lg font-bold hover:bg-[#22c55e]/90 transition-colors"
                        >
                          SIM! EU QUERO
                        </button>
                        <p className="text-xs text-center text-gray-500 mt-2">Oferta válida apenas nesta tela</p>
                      </>
                    ) : (
                      <div className="flex items-center justify-center gap-2 py-2">
                        <svg className="w-5 h-5 text-[#22c55e]" fill="currentColor" viewBox="0 0 20 20">
                          <path
                            fillRule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span className="text-[#22c55e] font-semibold">90 unidades adicionadas ao carrinho!</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Cart Summary */}
              <div className="mt-4 space-y-4 border-t pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold">R$ {cart.subtotal.toFixed(2).replace(".", ",")}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Frete</span>
                  <span className="font-semibold">R$ {cart.shippingPrice.toFixed(2).replace(".", ",")}</span>
                </div>
                <button className="text-[#4f46e5] text-sm font-medium hover:underline">Adicionar cupom</button>
                <div className="flex justify-between text-lg font-bold pt-2 border-t">
                  <span>Total</span>
                  <span>R$ {cart.total.toFixed(2).replace(".", ",")}</span>
                </div>
              </div>
            </div>

            {/* Payment Section */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Pagamento</h2>

              {/* Payment Method - PIX Only */}
              <div className="mb-6">
                <div className="border-2 border-[#22c55e] rounded-lg p-6 bg-white">
                  <img src="/images/pix-logo-oficial.png" alt="PIX" className="w-24 h-24 mx-auto object-contain mb-3" />
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-900">Pagamento via PIX</div>
                    <div className="text-sm text-gray-600 mt-1">Aprovação instantânea</div>
                  </div>
                </div>
              </div>

              {/* PIX Instructions */}
              <div className="bg-[#22c55e]/10 border border-[#22c55e]/20 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-[#22c55e] mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1H9z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <div className="text-sm text-gray-700">
                    <div className="font-semibold mb-1">Como funciona:</div>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Clique em "Finalizar Pedido"</li>
                      <li>Copie o código PIX gerado</li>
                      <li>Pague no app do seu banco</li>
                      <li>Aprovação em segundos!</li>
                    </ol>
                  </div>
                </div>
              </div>

              <Button
                onClick={
                  () => handleGeneratePix() // Call the updated handleGeneratePix
                }
                disabled={isLoading} // Use setIsLoading
                className="w-full bg-[#22c55e] hover:bg-[#16a34a] text-white font-bold py-6 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-lg"
              >
                {isLoading ? "PROCESSANDO..." : "FINALIZAR PEDIDO"}
              </Button>

              <button
                onClick={prevPage}
                className="w-full text-gray-400 hover:text-gray-600 font-medium py-3 text-center transition-colors mt-4"
              >
                Voltar
              </button>
            </div>
          </div>
        </div>
      )
    }

    // Page 21: PIX Generated
    if (state.currentPage === 21) {
      const cart = calculateCart()

      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      const timeDisplay = `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`

      return (
        <div className="min-h-screen bg-gray-50 px-4 py-6">
          <div className="max-w-2xl mx-auto">
            {/* Header */}
            <h1 className="text-2xl font-bold text-gray-800 text-center mb-6 leading-tight">
              Falta pouco! Para finalizar a compra, efetue o pagamento com PIX!
            </h1>

            {/* Main Card */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-4">
              {/* Timer */}
              <div className="text-center mb-6">
                <div className="text-gray-600 mb-2">O código expira em:</div>
                <div className="text-4xl font-bold text-red-500">{timeDisplay}</div>
              </div>

              {/* PIX Code */}
              <div className="mb-6">
                <div className="text-center mb-4">
                  <div className="text-gray-700 mb-1">Copie a chave abaixo e utilize a opção</div>
                  <div className="font-bold text-gray-900">PIX Copia e Cola:</div>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4 break-all text-sm text-gray-700">
                  {pixCode}
                </div>
                <button
                  onClick={copyPixCode}
                  className="w-full bg-[#22c55e] hover:bg-[#16a34a] text-white font-bold py-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <rect
                      x="9"
                      y="9"
                      width="13"
                      height="13"
                      rx="2"
                      ry="2"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  COPIAR CÓDIGO
                </button>
              </div>

              {/* Amount */}
              <div className="text-center text-lg mb-6">
                <span className="text-gray-600">Valor a ser pago: </span>
                <span className="text-[#22c55e] font-bold text-2xl">R$ {cart.total.toFixed(2).replace(".", ",")}</span>
              </div>

              {/* Instructions */}
              <div className="border-t pt-4">
                <button
                  onClick={() => setInstructionsExpanded(!instructionsExpanded)}
                  className="w-full flex items-center justify-between text-left font-semibold text-gray-900"
                >
                  <span>Instruções para pagamento</span>
                  <svg
                    className={`w-6 h-6 text-gray-600 transition-transform ${instructionsExpanded ? "rotate-180" : ""}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {instructionsExpanded && (
                  <div className="mt-4 space-y-4">
                    <div className="flex gap-3">
                      <div className="w-12 h-12 bg-[#22c55e] rounded-full flex items-center justify-center flex-shrink-0">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2z"
                          />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-700 text-sm">
                          Após copiar o código, abra seu aplicativo de pagamento onde você utiliza o Pix.
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="w-12 h-12 bg-[#22c55e] rounded-full flex items-center justify-center flex-shrink-0">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002 2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                          />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-700 text-sm">
                          Escolha a opção <strong>PIX Copia e Cola</strong> e insira o código copiado.
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="w-12 h-12 bg-[#22c55e] rounded-full flex items-center justify-center flex-shrink-0">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-700 text-sm">Confirme as informações e finalize sua compra.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* PIX Logo and Security Indicator */}
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <img src="/images/pix-logo-oficial.png" alt="PIX" className="h-8 object-contain" />
              <div className="h-8 w-px bg-gray-300" />
              <div className="flex items-center gap-2 text-gray-500">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                  />
                </svg>
                <span className="text-sm font-medium">Ambiente seguro</span>
              </div>
            </div>
          </div>
        </div>
      )
    }

    if (state.currentPage === 22) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 px-4 py-12 flex items-center justify-center">
          <div className="max-w-2xl w-full">
            {/* Success Card */}
            <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
              {/* Success Icon */}
              <div className="mb-6 flex justify-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                  <svg className="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Pagamento Confirmado! 🎉</h1>

              {/* Message */}
              <p className="text-lg text-gray-700 mb-6">
                Seu pedido foi confirmado com sucesso!
                <br />
                Você receberá um e-mail com os detalhes da compra em instantes.
              </p>

              {/* Order Details */}
              {orderId && (
                <div className="bg-gray-50 rounded-lg p-6 mb-6">
                  <p className="text-sm text-gray-600 mb-2">Número do Pedido:</p>
                  <p className="text-2xl font-bold text-gray-900">#{orderId}</p>
                </div>
              )}

              {/* Next Steps */}
              <div className="border-t pt-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Próximos Passos:</h2>
                <div className="space-y-3 text-left">
                  <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 font-bold text-sm">1</span>
                    </div>
                    <p className="text-gray-700">Verifique seu e-mail para os detalhes do pedido</p>
                  </div>
                  <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 font-bold text-sm">2</span>
                    </div>
                    <p className="text-gray-700">Aguarde a preparação e envio do seu produto</p>
                  </div>
                  <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-green-600 font-bold text-sm">3</span>
                    </div>
                    <p className="text-gray-700">Acompanhe o status do pedido através do código de rastreio</p>
                  </div>
                </div>
              </div>

              {/* Contact Support */}
              <div className="mt-8 pt-6 border-t">
                <p className="text-sm text-gray-600">
                  Dúvidas? Entre em contato conosco pelo e-mail:
                  <br />
                  <a href="mailto:contato@inovamulher.com.br" className="text-green-600 font-semibold hover:underline">
                    contato@inovamulher.com.br
                  </a>
                </p>
              </div>
            </div>

            {/* Footer Message */}
            <p className="text-center text-gray-600 mt-6">Obrigada por comprar conosco! ❤️</p>
          </div>
        </div>
      )
    }
    // </CHANGE>

    // Pages 1-19 rendering continues here
    if (state.currentPage === 1) return <QuizPage1 onAnswer={handleAnswer} />
    if (state.currentPage === 2) return <QuizPage2 onAnswer={handleAnswer} />
    if (state.currentPage === 3) return <QuizPage3 onAnswer={handleAnswer} />
    if (state.currentPage === 4) return <QuizPage4 onAnswer={handleAnswer} />
    if (state.currentPage === 5) return <QuizPage5 onAnswer={handleAnswer} />
    if (state.currentPage === 6) return <QuizPage6 onAnswer={handleAnswer} />
    if (state.currentPage === 7) return <QuizPage7 onAnswer={handleAnswer} />
    if (state.currentPage === 8) return <QuizPage8 onAnswer={handleAnswer} />
    if (state.currentPage === 9) return <QuizPage9 onAnswer={handleAnswer} />
    if (state.currentPage === 10) return <LoadingPage onComplete={handleContinue} />
    if (state.currentPage === 11) return <QuizPage11 onContinue={handleContinue} />
    if (state.currentPage === 12) return <QuizPage12 onContinue={handleContinue} />
    if (state.currentPage === 13) return <QuizPage13 onContinue={handleContinue} />
    if (state.currentPage === 14) return <CheckoutPage onContinue={handleContinue} />
    if (state.currentPage === 15)
      return (
        <IdentificationPage
          formData={formData}
          setFormData={setFormData}
          onContinue={handleContinue}
          onBack={handleBack}
          currentPage={state.currentPage}
          totalPages={TOTAL_PAGES}
          progress={progress}
        />
      )
    if (state.currentPage === 16)
      return (
        <AddressPage
          formData={formData}
          setFormData={setFormData}
          onContinue={handleContinue}
          onBack={handleBack}
          currentPage={state.currentPage}
          totalPages={TOTAL_PAGES}
          progress={progress}
        />
      )
    if (state.currentPage === 17)
      return (
        <ShippingPage
          selectedShipping={selectedShipping}
          setSelectedShipping={(value) => {
            console.log("[v0] Shipping selected:", value)
            setSelectedShipping(value)
            setState((prev) => ({ ...prev, shippingMethod: value, shippingCost: value === "sedex" ? 24.9 : 18.9 }))
          }}
          onContinue={handleContinue}
        />
      )
    if (state.currentPage === 18)
      return (
        <OrderBump2Page
          orderBump={orderBump2Active}
          setOrderBump={setOrderBump2Active}
          onContinue={handleContinue}
          onSkipToPayment={() => {
            console.log("[v0] Skipping to payment page 20")
            setState((prev) => ({ ...prev, isVisible: false }))
            setTimeout(() => {
              setState((prev) => ({
                ...prev,
                currentPage: 20,
                isVisible: true,
              }))
            }, 300)
          }}
        />
      )
    if (state.currentPage === 19) {
      console.log("[v0] Rendering OrderBump1 page 19")
      return (
        <OrderBump1Page
          orderBump={orderBump1Active}
          setOrderBump={setOrderBump1Active}
          onContinue={handleContinue}
          onSkipToPayment={() => {
            console.log("[v0] Skipping to payment page 20")
            setState((prev) => ({ ...prev, isVisible: false }))
            setTimeout(() => {
              setState((prev) => ({
                ...prev,
                currentPage: 20,
                isVisible: true,
              }))
            }, 300)
          }}
        />
      )
    }

    return null
  }

  return (
    <>
      {state.currentPage === 15 ? (
        <IdentificationPage
          formData={formData}
          setFormData={setFormData}
          onContinue={handleContinue}
          onBack={handleBack}
          currentPage={state.currentPage}
          totalPages={TOTAL_PAGES}
          progress={progress}
        />
      ) : state.currentPage === 16 ? (
        <AddressPage
          formData={formData}
          setFormData={setFormData}
          onContinue={handleContinue}
          onBack={handleBack}
          currentPage={state.currentPage}
          totalPages={TOTAL_PAGES}
          progress={progress}
        />
      ) : state.currentPage >= 20 ? ( // Render pages 20, 21, 22 directly
        <div
          className={cn(
            "transition-all duration-300",
            state.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4",
          )}
        >
          {renderPage()}
        </div>
      ) : (
        <div className="relative min-h-screen w-full overflow-x-hidden bg-white">
          {/* Header */}
          <header className="border-b border-gray-200 px-4 py-4">
            <div className="mx-auto flex max-w-md items-center justify-between">
              <button onClick={handleBack} className="min-w-[50px] text-gray-600 hover:text-gray-900">
                <ChevronLeft className="h-6 w-6" />
              </button>

              <div className="flex-1 text-center">
                <Image
                  src="/images/logo-quiz.png"
                  alt="OzemFit Adesivo"
                  width={140}
                  height={40}
                  className="mx-auto h-10 w-auto"
                  priority
                />
              </div>

              <div className="min-w-[50px] text-right text-sm font-semibold text-gray-900">
                {state.currentPage >= QUIZ_PAGES ? (
                  <div className="flex items-center justify-end gap-1.5">
                    <svg className="h-5 w-5" fill="#7CB342" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span style={{ color: "#7CB342" }}>Concluído</span>
                  </div>
                ) : (
                  `${state.currentPage}/${QUIZ_PAGES}`
                )}
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mx-auto mt-3 h-1.5 max-w-md overflow-hidden rounded-full bg-gray-200">
              <div className="h-full bg-black transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
            </div>
          </header>

          {/* Content */}
          <div
            className={cn(
              "flex-1 px-4 py-8 transition-all duration-300",
              state.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4",
            )}
          >
            <div className="mx-auto max-w-md">{renderPage()}</div>
          </div>

          {/* Footer */}
          <footer className="border-t border-gray-200 bg-white px-4 py-4 text-center text-xs text-gray-600">
            <div className="mx-auto max-w-md">
              © 2025 OzemFit Brasil LTD •{" "}
              <Dialog>
                <DialogTrigger asChild>
                  <button className="font-semibold underline hover:text-gray-900">Política de Privacidade</button>
                </DialogTrigger>
                <DialogContent className="max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Política de Privacidade</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 text-sm text-gray-700">
                    <p>
                      <strong>Última atualização:</strong> Janeiro de 2025
                    </p>

                    <section>
                      <h3 className="mb-2 font-semibold">1. Informações que Coletamos</h3>
                      <p>
                        Coletamos informações pessoais que você nos fornece voluntariamente ao participar do quiz e
                        realizar compras, incluindo nome, email, telefone, endereço e dados de pagamento.
                      </p>
                    </section>

                    <section>
                      <h3 className="mb-2 font-semibold">2. Como Usamos suas Informações</h3>
                      <p>
                        Utilizamos suas informações para processar pedidos, personalizar sua experiência, enviar
                        atualizações sobre produtos e melhorar nossos serviços.
                      </p>
                    </section>

                    <section>
                      <h3 className="mb-2 font-semibold">3. Compartilhamento de Dados</h3>
                      <p>
                        Não vendemos suas informações pessoais. Podemos compartilhar dados com prestadores de serviços
                        necessários para processar pagamentos e entregas.
                      </p>
                    </section>

                    <section>
                      <h3 className="mb-2 font-semibold">4. Segurança</h3>
                      <p>
                        Implementamos medidas de segurança para proteger suas informações pessoais contra acesso não
                        autorizado, alteração ou divulgação.
                      </p>
                    </section>

                    <section>
                      <h3 className="mb-2 font-semibold">5. Seus Direitos</h3>
                      <p>
                        Você tem o direito de acessar, corrigir ou excluir suas informações pessoais. Entre em contato
                        conosco para exercer esses direitos.
                      </p>
                    </section>

                    <section>
                      <h3 className="mb-2 font-semibold">6. Contato</h3>
                      <p>Para dúvidas sobre esta política, entre em contato através do email: contato@ozemfit.com.br</p>
                    </section>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </footer>
        </div>
      )}
    </>
  )
}

// Página 1: Início
function QuizPage1({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col items-center text-center">
      <h1 className="mb-8 text-[2rem] font-bold leading-tight text-gray-900 text-center">
        <span className="bg-[#7CB342] px-2 text-white">Parabéns!</span> Você ganhou 30 dias de{" "}
        <span className="bg-[#7CB342] px-2 text-white">tratamento grátis!</span>
      </h1>

      <div className="mb-8">
        <Image
          src="/images/gif-da-pagina-01.gif"
          alt="Demonstração do produto"
          width={300}
          height={300}
          className="rounded-lg"
          unoptimized
        />
      </div>

      <Button
        onClick={() => onAnswer("start")}
        className="h-14 w-full max-w-sm bg-black text-base font-semibold text-white hover:bg-gray-900"
        size="lg"
      >
        EXPERIMENTE GRÁTIS
      </Button>
    </div>
  )
}

// Página 2: Sexo
function QuizPage2({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual seu sexo?</h2>

      <div className="space-y-4">
        <OptionButton icon="👩" label="SOU MULHER" onClick={() => onAnswer("female")} />
        <OptionButton icon="🙋‍♂️" label="SOU HOMEM" onClick={() => onAnswer("male")} />
      </div>
    </div>
  )
}

// Página 3: Idade
function QuizPage3({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Quantos anos você tem?</h2>

      <div className="space-y-4">
        <OptionButton label="18-25 anos" onClick={() => onAnswer("18-25")} />
        <OptionButton label="26-35 anos" onClick={() => onAnswer("26-35")} />
        <OptionButton label="36-45 anos" onClick={() => onAnswer("36-45")} />
        <OptionButton label="46-60 anos" onClick={() => onAnswer("46-60")} />
        <OptionButton label="60+ anos" onClick={() => onAnswer("60+")} />
      </div>
    </div>
  )
}

// Página 4: Altura
function QuizPage4({ onAnswer }: { onAnswer: (answer: number) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual sua altura?</h2>

      <div className="space-y-4">
        <OptionButton label="Menos de 1,50m" onClick={() => onAnswer(145)} />
        <OptionButton label="1,50m - 1,60m" onClick={() => onAnswer(155)} />
        <OptionButton label="1,60m - 1,70m" onClick={() => onAnswer(165)} />
        <OptionButton label="1,70m - 1,80m" onClick={() => onAnswer(175)} />
        <OptionButton label="1,80m - 1,90m" onClick={() => onAnswer(185)} />
        <OptionButton label="Mais de 1,90m" onClick={() => onAnswer(195)} />
      </div>
    </div>
  )
}

// Página 5: Peso atual
function QuizPage5({ onAnswer }: { onAnswer: (answer: number) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual seu peso atual?</h2>

      <div className="space-y-4">
        <OptionButton label="Menos de 50kg" onClick={() => onAnswer(45)} />
        <OptionButton label="50kg - 60kg" onClick={() => onAnswer(55)} />
        <OptionButton label="60kg - 70kg" onClick={() => onAnswer(65)} />
        <OptionButton label="70kg - 80kg" onClick={() => onAnswer(75)} />
        <OptionButton label="80kg - 90kg" onClick={() => onAnswer(85)} />
        <OptionButton label="90kg - 100kg" onClick={() => onAnswer(95)} />
        <OptionButton label="100kg - 120kg" onClick={() => onAnswer(110)} />
        <OptionButton label="Mais de 120kg" onClick={() => onAnswer(130)} />
      </div>
    </div>
  )
}

// Página 6: Peso desejado
function QuizPage6({ onAnswer }: { onAnswer: (answer: number) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual seu peso desejado?</h2>

      <div className="space-y-4">
        <OptionButton label="Menos de 50kg" onClick={() => onAnswer(45)} />
        <OptionButton label="50kg - 60kg" onClick={() => onAnswer(55)} />
        <OptionButton label="60kg - 70kg" onClick={() => onAnswer(65)} />
        <OptionButton label="70kg - 80kg" onClick={() => onAnswer(75)} />
        <OptionButton label="80kg - 90kg" onClick={() => onAnswer(85)} />
        <OptionButton label="90kg - 100kg" onClick={() => onAnswer(95)} />
        <OptionButton label="Mais de 100kg" onClick={() => onAnswer(110)} />
      </div>
    </div>
  )
}

// Página 7: Alimentação
function QuizPage7({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Como você se alimenta?</h2>

      <div className="space-y-4">
        <OptionButton icon="🍕" label="Como de tudo" onClick={() => onAnswer("tudo")} />
        <OptionButton icon="🥗" label="Como saudável na maior parte do tempo" onClick={() => onAnswer("saudavel")} />
        <OptionButton icon="🍔" label="Tenho dificuldade de controlar" onClick={() => onAnswer("dificuldade")} />
      </div>
    </div>
  )
}

// Página 8: Atividade física
function QuizPage8({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Pratica atividade física?</h2>

      <div className="space-y-4">
        <OptionButton icon="🏃" label="Sim, regularmente" onClick={() => onAnswer("regular")} />
        <OptionButton icon="🚶" label="Às vezes" onClick={() => onAnswer("as-vezes")} />
        <OptionButton icon="🛋️" label="Não pratico" onClick={() => onAnswer("nao")} />
      </div>
    </div>
  )
}

// Página 9: Fome entre refeições
function QuizPage9({ onAnswer }: { onAnswer: (answer: string) => void }) {
  return (
    <div className="flex flex-col">
      <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Sente fome entre as refeições?</h2>

      <div className="space-y-4">
        <OptionButton icon="😋" label="Sim, muita fome" onClick={() => onAnswer("muita")} />
        <OptionButton icon="🙂" label="Às vezes" onClick={() => onAnswer("as-vezes")} />
        <OptionButton icon="😌" label="Raramente" onClick={() => onAnswer("raramente")} />
      </div>
    </div>
  )
}

// Página 10: Loading
function LoadingPage({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(onComplete, 500)
          return 100
        }
        return prev + 1
      })
    }, 50)

    return () => clearInterval(interval)
  }, [onComplete]) // Added onComplete as dependency

  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="mb-8">
        <div className="mb-4 h-16 w-16 animate-spin rounded-full border-4 border-gray-200 border-t-[#7CB342]"></div>
      </div>

      <h2 className="mb-4 text-2xl font-bold text-gray-900">Analisando suas respostas...</h2>
      <p className="mb-8 text-gray-600">Estamos criando seu plano personalizado</p>

      <div className="w-full max-w-xs">
        <div className="h-2 overflow-hidden rounded-full bg-gray-200">
          <div className="h-full bg-[#7CB342] transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
        <p className="mt-2 text-sm text-gray-600">{progress}%</p>
      </div>
    </div>
  )
}

// Página 11: Instruções semana 1
function QuizPage11({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col text-center">
      <h2 className="mb-6 text-2xl font-bold leading-tight text-gray-900">
        Pegue um papel e uma caneta e <span className="bg-[#7CB342] px-2 py-1 text-white">anote seu plano</span>:
      </h2>

      <p className="mb-8 text-left text-base leading-relaxed text-gray-700">
        Colar 1 adesivo (na região do pulso) logo após acordar, todos os dias e remover sempre antes de dormir. Fazer
        isso durante 7 dias (primeira semana de uso).
      </p>

      <Button
        onClick={onContinue}
        className="h-14 w-full bg-black text-base font-semibold text-white hover:bg-gray-900"
      >
        CONTINUAR
      </Button>
    </div>
  )
}

// Página 12: Instruções semana 2
function QuizPage12({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col text-center">
      <h2 className="mb-6 text-2xl font-bold leading-tight text-gray-900">
        Pegue um papel e uma caneta e <span className="bg-[#7CB342] px-2 py-1 text-white">anote seu plano</span>:
      </h2>

      <p className="mb-8 text-base leading-relaxed text-gray-700">
        <span className="font-semibold underline">Na segunda semana</span> você segue o mesmo plano, porém cole o
        adesivo na barriga. Uma semana no pulso e outra na barriga até finalizar o pacote de 30 unidades.
      </p>

      <Button
        onClick={onContinue}
        className="h-14 w-full bg-black text-base font-semibold text-white hover:bg-gray-900"
      >
        CONTINUAR
      </Button>
    </div>
  )
}

// Página 13: Informação sobre o produto
function QuizPage13({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col text-center">
      <h2 className="mb-6 text-2xl font-bold leading-tight text-gray-900">
        Seu corpo ira absorver pequenas doses de semaglutida, o mesmo princípio ativo do{" "}
        <span className="bg-[#7CB342] px-2 py-1 text-white">Ozempic®</span>
      </h2>

      <p className="mb-8 text-base leading-relaxed text-gray-700">
        Como resultado, você ira perder peso e transformar seu corpo de forma não invasiva e 100% segura.
      </p>

      <Button
        onClick={onContinue}
        className="h-14 w-full bg-black text-base font-semibold text-white hover:bg-gray-900"
      >
        CONTINUAR
      </Button>
    </div>
  )
}

// Página 14: Checkout
function CheckoutPage({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col text-center">
      <h2 className="mb-6 text-2xl font-bold leading-tight text-gray-900">
        Chegou a hora de <span className="bg-[#7CB342] px-2 py-1 text-white">resgatar</span> seu pacote com{" "}
        <span className="bg-[#7CB342] px-2 py-1 text-white">desconto de 100%</span>
      </h2>

      <p className="mb-6 text-center text-sm text-gray-700">Sua nova jornada ira comecar e nos estaremos juntos 🖤</p>

      <div className="mb-6 flex justify-center">
        <Image
          src="/images/produto-da-pagina14.png"
          alt="OzemFit Plus 2X - 30 Adesivos"
          width={280}
          height={280}
          className="object-contain"
        />
      </div>

      <div className="mb-6 flex items-center justify-between rounded-lg border-2 border-gray-300 bg-white p-4">
        <span className="text-lg font-semibold text-gray-900">OzemFit 30 Unidades</span>
        <span className="text-xl font-bold text-gray-900">R$ 00,00</span>
      </div>

      <Button onClick={onContinue} className="w-full bg-black py-6 text-lg font-semibold text-white hover:bg-gray-800">
        RESGATAR
      </Button>
    </div>
  )
}

// Página 15: Identification
function IdentificationPage({
  formData,
  setFormData,
  onContinue,
  onBack,
  currentPage,
  totalPages,
  progress,
}: {
  formData: FormData
  setFormData: (data: FormData) => void
  onContinue: () => void
  onBack: () => void
  currentPage: number
  totalPages: number
  progress: number
}) {
  const [cpfError, setCpfError] = React.useState<string>("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateCPF(formData.cpf)) {
      setCpfError("CPF inválido. Verifique os números do seu CPF.")
      return
    }

    setCpfError("")
    onContinue()
  }

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "")

    if (value.length <= 11) {
      if (value.length > 9) {
        value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
      } else if (value.length > 6) {
        value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3")
      } else if (value.length > 3) {
        value = value.replace(/(\d{3})(\d{1,3})/, "$1.$2")
      }

      setFormData({ ...formData, cpf: value })

      // Clear error when user types
      if (cpfError) setCpfError("")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 animate-in fade-in duration-300">
      {/* Header - Padrão do Quiz */}
      <header className="border-b border-gray-200 px-4 py-4 bg-white">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <button onClick={onBack} className="min-w-[50px] text-gray-600 hover:text-gray-900">
            <ChevronLeft className="h-6 w-6" />
          </button>

          <div className="flex-1 text-center">
            <Image
              src="/images/logo-quiz.png"
              alt="OzemFit Adesivo"
              width={140}
              height={40}
              className="mx-auto h-10 w-auto"
              priority
            />
          </div>

          <div className="min-w-[50px] text-right text-sm font-semibold">
            <div className="flex items-center justify-end gap-1.5">
              <svg className="h-5 w-5" fill="#7CB342" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              <span style={{ color: "#7CB342" }}>Concluído</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mx-auto mt-3 h-1.5 max-w-md overflow-hidden rounded-full bg-gray-200">
          <div className="h-full bg-black transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Cart Summary */}
          <div className="rounded-lg bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-gray-900">Seu carrinho</h2>
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#7cb342] text-sm font-bold text-white">
                  1
                </div>
                <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>

            <div className="mb-4 flex items-center gap-3 pb-4 border-b border-gray-200">
              <img src="/images/produto-da-pagina14.png" alt="OzemFit PLUS 2x" className="h-16 w-16 object-contain" />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">OzemFit PLUS 2x mais efeito</h3>
                <p className="text-sm text-gray-500">30 Unidades</p>
              </div>
              <div className="text-sm text-gray-600">1 un.</div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-700">
                <span>Subtotal</span>
                <span>R$ 0,00</span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>Frete</span>
                <span>-</span>
              </div>
              <div className="text-blue-600">
                <button className="text-sm hover:underline">Adicionar cupom</button>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-2 text-lg font-bold text-gray-900">
                <span>Total</span>
                <span>R$ 0,00</span>
              </div>
            </div>
          </div>

          {/* Identification Form */}
          <div className="rounded-lg bg-white p-6 shadow-sm">
            <h2 className="mb-6 text-center text-2xl font-bold leading-tight text-[#1e3a8a]">
              Preencha seus dados{" "}
              <span className="inline-block bg-[#7CB342] px-3 py-1 text-white">Identifique-se:</span>
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email" className="mb-2 block text-sm font-medium text-gray-900">
                  E-mail
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="email@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="phone" className="mb-2 block text-sm font-medium text-gray-900">
                  Telefone
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(99) 99999-9999"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="name" className="mb-2 block text-sm font-medium text-gray-900">
                  Nome completo
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Nome e Sobrenome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="cpf" className="mb-2 block text-sm font-medium text-gray-900">
                  CPF
                </Label>
                <Input
                  id="cpf"
                  type="text"
                  placeholder="123.456.789-12"
                  value={formData.cpf}
                  onChange={handleCPFChange}
                  required
                  className={`h-12 rounded-md bg-white ${cpfError ? "border-red-500" : "border-gray-300"}`}
                />
                {cpfError && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {cpfError}
                  </p>
                )}
              </div>

              <div className="rounded-lg border border-gray-300 bg-white p-4">
                <p className="mb-3 text-sm font-medium text-gray-900">
                  Usamos seus dados de forma 100% segura para garantir a sua satisfação:
                </p>
                <div className="space-y-2.5 text-sm text-gray-700">
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]" />
                    <span>Enviar o seu comprovante de compra e pagamento;</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]" />
                    <span>Ativar a sua garantia de devolução caso não fique satisfeito;</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]" />
                    <span>Acompanhar o andamento do seu pedido;</span>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="h-14 w-full bg-black text-base font-semibold uppercase text-white hover:bg-gray-900"
              >
                IR PARA A ENTREGA
              </Button>
            </form>
          </div>
        </div>

        <div className="mt-8 text-center text-xs text-gray-600">
          © 2025 OzemFit Brasil LTD •{" "}
          <a href="#" className="text-gray-600 underline hover:text-gray-900">
            Política de Privacidade
          </a>
        </div>
      </div>
    </div>
  )
}

// Página 16: Endereço
function AddressPage({
  formData,
  setFormData,
  onContinue,
  onBack,
  currentPage,
  totalPages,
  progress,
}: {
  formData: FormData
  setFormData: (data: FormData) => void
  onContinue: () => void
  onBack: () => void
  currentPage: number
  totalPages: number
  progress: number
}) {
  const [loadingCep, setLoadingCep] = useState(false)

  const brazilianStates = [
    "Acre",
    "Alagoas",
    "Amapá",
    "Amazonas",
    "Bahia",
    "Ceará",
    "Distrito Federal",
    "Espírito Santo",
    "Goiás",
    "Maranhão",
    "Mato Grosso",
    "Mato Grosso do Sul",
    "Minas Gerais",
    "Pará",
    "Paraíba",
    "Paraná",
    "Pernambuco",
    "Piauí",
    "Rio de Janeiro",
    "Rio Grande do Norte",
    "Rio Grande do Sul",
    "Rondônia",
    "Roraima",
    "Santa Catarina",
    "São Paulo",
    "Sergipe",
    "Tocantins",
  ]

  const stateUfMap: Record<string, string> = {
    AC: "Acre",
    AL: "Alagoas",
    AP: "Amapá",
    AM: "Amazonas",
    BA: "Bahia",
    CE: "Ceará",
    DF: "Distrito Federal",
    ES: "Espírito Santo",
    GO: "Goiás",
    MA: "Maranhão",
    MT: "Mato Grosso",
    MS: "Mato Grosso do Sul",
    MG: "Minas Gerais",
    PA: "Pará",
    PB: "Paraíba",
    PR: "Paraná",
    PE: "Pernambuco",
    PI: "Piauí",
    RJ: "Rio de Janeiro",
    RN: "Rio Grande do Norte",
    RS: "Rio Grande do Sul",
    RO: "Rondônia",
    RR: "Roraima",
    SC: "Santa Catarina",
    SP: "São Paulo",
    SE: "Sergipe",
    TO: "Tocantins",
  }

  const handleCepChange = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, "")
    setFormData({ ...formData, cep })

    if (cleanCep.length === 8) {
      setLoadingCep(true)
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`)
        const data = await response.json()

        if (!data.erro) {
          const fullStateName = stateUfMap[data.uf] || data.uf

          setFormData({
            ...formData,
            cep,
            address: data.logradouro || "",
            neighborhood: data.bairro || "",
            city: data.localidade || "",
            state: fullStateName,
          })
        }
      } catch (error) {
        console.error("Erro ao buscar CEP:", error)
      } finally {
        setLoadingCep(false)
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onContinue()
  }

  return (
    <div className="min-h-screen bg-gray-50 animate-in fade-in duration-300">
      {/* Header - Padrão do Quiz */}
      <header className="border-b border-gray-200 px-4 py-4 bg-white">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <button onClick={onBack} className="min-w-[50px] text-gray-600 hover:text-gray-900">
            <ChevronLeft className="h-6 w-6" />
          </button>

          <div className="flex-1 text-center">
            <Image
              src="/images/logo-quiz.png"
              alt="OzemFit Adesivo"
              width={140}
              height={40}
              className="mx-auto h-10 w-auto"
              priority
            />
          </div>

          <div className="min-w-[50px] text-right text-sm font-semibold">
            <div className="flex items-center justify-end gap-1.5">
              <svg className="h-5 w-5" fill="#7CB342" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              <span style={{ color: "#7CB342" }}>Concluído</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mx-auto mt-3 h-1.5 max-w-md overflow-hidden rounded-full bg-gray-200">
          <div className="h-full bg-black transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Cart Summary */}
          <div className="rounded-lg bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-gray-900">Seu carrinho</h2>
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#7cb342] text-sm font-bold text-white">
                  1
                </div>
                <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>

            <div className="mb-4 flex items-center gap-3 pb-4 border-b border-gray-200">
              <img src="/images/produto-da-pagina14.png" alt="OzemFit PLUS 2x" className="h-16 w-16 object-contain" />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">OzemFit PLUS 2x mais efeito</h3>
                <p className="text-sm text-gray-500">30 Unidades</p>
              </div>
              <div className="text-sm text-gray-600">1 un.</div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-700">
                <span>Subtotal</span>
                <span>R$ 0,00</span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>Frete</span>
                <span>-</span>
              </div>
              <div className="text-blue-600">
                <button className="text-sm hover:underline">Adicionar cupom</button>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-2 text-lg font-bold text-gray-900">
                <span>Total</span>
                <span>R$ 0,00</span>
              </div>
            </div>
          </div>

          {/* Address Form */}
          <div className="rounded-lg bg-white p-6 shadow-sm">
            <h2 className="mb-6 text-center text-2xl font-bold leading-tight text-[#1e3a8a]">
              Endereço para <span className="inline-block bg-[#7CB342] px-3 py-1 text-white">Entrega:</span>
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="cep" className="mb-2 block text-sm font-medium text-gray-900">
                  CEP
                </Label>
                <Input
                  id="cep"
                  type="text"
                  placeholder="12345-000"
                  value={formData.cep}
                  onChange={(e) => handleCepChange(e.target.value)}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                  disabled={loadingCep}
                />
                {loadingCep && <p className="mt-1 text-xs text-gray-500">Buscando endereço...</p>}
              </div>

              <div>
                <Label htmlFor="address" className="mb-2 block text-sm font-medium text-gray-900">
                  Endereço
                </Label>
                <Input
                  id="address"
                  type="text"
                  placeholder="Rua, Avenida, Alameda"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div className="flex gap-3">
                <div className="flex-1">
                  <Label htmlFor="number" className="mb-2 block text-sm font-medium text-gray-900">
                    Número
                  </Label>
                  <Input
                    id="number"
                    type="text"
                    placeholder="3213"
                    value={formData.number}
                    onChange={(e) => setFormData({ ...formData, number: e.target.value })}
                    required={!formData.noNumber}
                    disabled={formData.noNumber}
                    className="h-12 rounded-md border-gray-300 bg-white"
                  />
                </div>
                <div className="flex items-end pb-3">
                  <label className="flex cursor-pointer items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-gray-300"
                      checked={formData.noNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, noNumber: e.target.checked, number: e.target.checked ? "S/N" : "" })
                      }
                    />
                    S/N
                  </label>
                </div>
              </div>

              <div>
                <Label htmlFor="complement" className="mb-2 block text-sm font-medium text-gray-900">
                  Complemento
                </Label>
                <Input
                  id="complement"
                  type="text"
                  placeholder="Apartamento, unidade, prédio, andar, etc."
                  value={formData.complement}
                  onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="neighborhood" className="mb-2 block text-sm font-medium text-gray-900">
                  Bairro
                </Label>
                <Input
                  id="neighborhood"
                  type="text"
                  placeholder="Centro"
                  value={formData.neighborhood}
                  onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="city" className="mb-2 block text-sm font-medium text-gray-900">
                  Cidade
                </Label>
                <Input
                  id="city"
                  type="text"
                  placeholder="Cidade"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  required
                  className="h-12 rounded-md border-gray-300 bg-white"
                />
              </div>

              <div>
                <Label htmlFor="state" className="mb-2 block text-sm font-medium text-gray-900">
                  Estado
                </Label>
                <select
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  required
                  className="flex h-12 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gray-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="">Selecione o estado</option>
                  {brazilianStates.map((state) => (
                    <option key={state} value={state}>
                      {state}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="country" className="mb-2 block text-sm font-medium text-gray-900">
                  País
                </Label>
                <select
                  id="country"
                  value="Brasil"
                  disabled
                  className="flex h-12 w-full rounded-md border border-gray-300 bg-gray-100 px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gray-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="Brasil">Brasil</option>
                </select>
              </div>

              <div className="rounded-lg border border-gray-300 bg-white p-4">
                <p className="mb-3 text-sm font-medium text-gray-900">
                  Usamos seus dados de forma 100% segura para garantir a sua satisfação:
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <svg
                      className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span>Enviar o seu comprovante de compra e pagamento;</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg
                      className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span>Ativar a sua garantia de devolução caso não fique satisfeito;</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <svg
                      className="mt-0.5 h-5 w-5 flex-shrink-0 text-[#7cb342]"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span>Acompanhar o andamento do seu pedido;</span>
                  </li>
                </ul>
              </div>

              <Button type="submit" className="w-full bg-black py-6 text-lg font-semibold text-white hover:bg-gray-800">
                IR PARA O PAGAMENTO
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 bg-white px-4 py-6 text-center text-sm text-gray-600">
        <p>
          © 2025 OzemFit Brasil LTD •{" "}
          <a href="#" className="text-blue-600 hover:underline">
            Política de Privacidade
          </a>
        </p>
      </div>
    </div>
  )
}

// Página 17: Frete
function ShippingPage({
  selectedShipping,
  setSelectedShipping,
  onContinue,
}: {
  selectedShipping: "pac" | "sedex"
  setSelectedShipping: (value: "pac" | "sedex") => void
  onContinue: () => void
}) {
  return (
    <div className="flex flex-col gap-6">
      {/* Cart Summary Section */}
      <div className="rounded-lg bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">Seu carrinho</h2>
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#7cb342] text-sm font-bold text-white">
            1
          </div>
        </div>

        <div className="mb-4 flex items-center gap-3 pb-4 border-b border-gray-200">
          <img src="/images/produto-da-pagina14.png" alt="OzemFit PLUS 2x" className="h-16 w-16 object-contain" />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900">OzemFit PLUS 2x mais efeito</h3>
            <p className="text-sm text-gray-500">30 Unidades</p>
          </div>
          <div className="text-sm text-gray-600">1 un.</div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex justify-between text-gray-700">
            <span>Subtotal</span>
            <span>R$ 0,00</span>
          </div>
          <div className="flex justify-between text-gray-700">
            <span>Frete</span>
            <span>R$ {selectedShipping === "sedex" ? "24,90" : "18,90"}</span>
          </div>
          <div className="text-blue-600">
            <button className="text-sm hover:underline">Adicionar cupom</button>
          </div>
          <div className="flex justify-between border-t border-gray-200 pt-2 text-lg font-bold text-gray-900">
            <span>Total</span>
            <span>R$ {selectedShipping === "sedex" ? "24,90" : "18,90"}</span>
          </div>
        </div>
      </div>

      {/* Shipping Selection Section */}
      <div className="rounded-lg bg-white p-6 shadow-sm">
        <h2 className="mb-6 text-center text-2xl font-bold leading-tight text-gray-900">
          Escolha seu <span className="bg-[#7CB342] px-2 py-1 text-white">Frete:</span>
        </h2>

        <p className="mb-6 text-center text-sm text-gray-700">Escolha o melhor frete para você</p>

        <RadioGroup value={selectedShipping} onValueChange={(value) => setSelectedShipping(value as "pac" | "sedex")}>
          <div className="mb-4 space-y-4">
            <label
              className={cn(
                "flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all",
                selectedShipping === "pac" ? "border-gray-400 bg-gray-50" : "border-gray-200 bg-white",
              )}
            >
              <div className="flex items-center gap-3">
                <RadioGroupItem value="pac" id="pac" />
                <div>
                  <div className="font-semibold text-gray-900">Correios PAC</div>
                  <div className="text-sm text-gray-600">de 10 a 15 dias.</div>
                </div>
              </div>
              <div className="text-lg font-bold text-gray-900">R$18,90</div>
            </label>

            <label
              className={cn(
                "flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all",
                selectedShipping === "sedex" ? "border-[#7CB342] bg-green-50" : "border-gray-200 bg-white",
              )}
            >
              <div className="flex items-center gap-3">
                <RadioGroupItem value="sedex" id="sedex" />
                <div>
                  <div className="font-semibold text-gray-900">Correios SEDEX</div>
                  <div className="text-sm text-gray-600">de 3 até 5 dias úteis.</div>
                </div>
              </div>
              <div className="text-lg font-bold text-gray-900">R$24,90</div>
            </label>
          </div>
        </RadioGroup>

        <p className="mb-6 text-center text-xs text-gray-500">
          A previsão de entrega pode variar de acordo com a região e facilidade de acesso ao seu endereço
        </p>

        <Button
          onClick={onContinue}
          className="h-14 w-full bg-black text-base font-semibold text-white hover:bg-gray-900"
        >
          CONTINUAR
        </Button>
      </div>
    </div>
  )
}

// Página 18: Order Bump 2
function OrderBump2Page({
  orderBump,
  setOrderBump,
  onContinue,
  onSkipToPayment,
}: {
  orderBump: boolean
  setOrderBump: (value: boolean) => void
  onContinue: () => void
  onSkipToPayment: () => void
}) {
  const [isWaiting, setIsWaiting] = React.useState(false)

  React.useEffect(() => {
    if (orderBump && isWaiting) {
      const timer = setTimeout(() => {
        onSkipToPayment()
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [orderBump, isWaiting, onSkipToPayment])

  const handleAddOrderBump = () => {
    setOrderBump(true)
    setIsWaiting(true)
    // track("Quiz Add Order Bump 2", {
    //   action: "add_bump",
    //   value: 49.9,
    //   url: window.location.href,
    // })
  }

  return (
    <div className="flex flex-col">
      <h2 className="mb-6 text-center text-2xl font-bold leading-tight text-gray-900">
        Gostaria de adicionar essa <span className="bg-[#7CB342] px-2 py-1 text-white">Oferta?</span>
      </h2>

      <p className="mb-4 text-sm">
        <span className="text-[#7CB342] font-semibold">1 Oferta Disponível</span> para você:
      </p>

      <div className="mb-6 rounded-lg border-2 border-dashed border-[#7CB342] bg-white p-4">
        <div className="mb-3 flex items-center justify-between">
          <span className="inline-flex items-center gap-1 rounded bg-[#7CB342] px-3 py-1 text-sm font-bold text-white">
            OFERTA DISPONÍVEL ✓
          </span>
          {orderBump && !isWaiting && (
            <button onClick={() => setOrderBump(false)} className="text-gray-400 hover:text-red-500">
              <Trash2 className="h-5 w-5" />
            </button>
          )}
        </div>

        <div className="mb-3 flex items-start gap-4">
          <Image
            src="/images/produto-da-pagina18.png"
            alt="OzemFit Plus 2X - 90 Adesivos"
            width={100}
            height={100}
            className="flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <h3 className="mb-1 text-lg font-bold text-gray-900">Adicione +90 Unidades</h3>
            <p className="mb-2 text-sm text-gray-600">Valor Promocional</p>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-red-500 line-through">R$149,90</span>
              <span className="text-xl font-bold text-[#7CB342] whitespace-nowrap">R$49,90</span>
            </div>
          </div>
        </div>

        <p className="mb-4 text-xs text-gray-500">Ofertas exclusivas para esta compra!</p>

        <Button
          onClick={handleAddOrderBump}
          disabled={isWaiting}
          className={`mb-3 h-12 w-full text-base font-semibold transition-all ${
            isWaiting ? "bg-[#7CB342] text-white hover:bg-[#7CB342]" : "bg-black text-white hover:bg-gray-900"
          }`}
        >
          {isWaiting ? "ADICIONADO ✓" : "ADICIONAR 90 UNIDADES"}
        </Button>

        {!isWaiting && (
          <button
            onClick={onContinue}
            className="w-full text-center text-base font-medium text-gray-600 hover:text-gray-900 underline transition-colors"
          >
            Continuar sem adicionar
          </button>
        )}
      </div>
    </div>
  )
}

// Página 19: Order Bump 1
function OrderBump1Page({
  orderBump,
  setOrderBump,
  onContinue,
  onSkipToPayment,
}: {
  orderBump: boolean
  setOrderBump: (value: boolean) => void
  onContinue: () => void
  onSkipToPayment: () => void
}) {
  const [isWaiting, setIsWaiting] = React.useState(false)

  React.useEffect(() => {
    if (orderBump && isWaiting) {
      const timer = setTimeout(() => {
        onSkipToPayment()
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [orderBump, isWaiting, onSkipToPayment])

  const handleAddOrderBump = () => {
    setOrderBump(true)
    setIsWaiting(true)
    // track("Quiz Add Order Bump 1", {
    //   action: "add_bump",
    //   value: 29.9,
    //   url: window.location.href,
    // })
  }

  return (
    <div className="flex flex-col text-center">
      <h2 className="mb-6 text-2xl font-bold leading-tight text-gray-900">
        É altamente recomendado que você{" "}
        <span className="bg-[#7CB342] px-2 py-1 text-white">adicione +90 unidades</span>:
      </h2>

      <p className="mb-8 text-base leading-relaxed text-gray-700">
        Para um tratamento experimental efetivo e duradouro adicione +90 pelo menor preço possível de 29,90 reais.
      </p>

      <Button
        onClick={handleAddOrderBump}
        disabled={isWaiting}
        className={`mb-3 h-14 w-full text-base font-semibold transition-all ${
          isWaiting ? "bg-[#7CB342] text-white hover:bg-[#7CB342]" : "bg-black text-white hover:bg-gray-900"
        }`}
      >
        {isWaiting ? "ADICIONADO ✓" : "ADICIONAR 90 UNIDADES"}
      </Button>

      {!isWaiting && (
        <button onClick={onContinue} className="w-full text-center text-base text-gray-400 hover:text-gray-600">
          Continuar sem adicionar
        </button>
      )}
    </div>
  )
}

// Componente reutilizável para opções
function OptionButton({ icon, label, onClick }: { icon?: string; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-xl border-2 border-gray-200 bg-white p-5 text-left transition-all hover:border-[#7CB342] hover:bg-gray-50 active:scale-[0.98]"
    >
      <div className="flex items-center gap-4">
        {icon && <span className="text-4xl">{icon}</span>}
        <span className="text-lg font-semibold text-gray-900">{label}</span>
      </div>
      <svg className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
      </svg>
    </button>
  )
}
