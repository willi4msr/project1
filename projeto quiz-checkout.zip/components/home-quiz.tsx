"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { Check, ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import Image from "next/image"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const TOTAL_PAGES = 20
const QUIZ_PAGES = 14

type Answer = string | number | null

interface QuizState {
  currentPage: number
  isVisible: boolean // using isVisible for fade transitions
}

interface FormData {
  email: string
  phone: string
  name: string
  cpf: string
  cep: string
  address: string
  number: string
  noNumber: boolean
  complement: string
  neighborhood: string
  city: string
  state: string
  country: string
}

interface CreditCardData {
  cardNumber: string
  cardName: string
  expiryDate: string
  cvv: string
  installments: number
}

export default function HomeQuiz() {
  const [state, setState] = useState<QuizState>({
    currentPage: 1,
    isVisible: true, // properly typed as boolean
  })
  const [orderBump1, setOrderBump1] = useState(false)
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)
  const [orderBump2, setOrderBump2] = useState(false)
  const [orderBump3, setOrderBump3] = useState(false)
  const [orderBump4, setOrderBump4] = useState(false)
  const [orderBump5, setOrderBump5] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<"credit" | "pix">("pix") // REMOVED: credit card option
  const [formData, setFormData] = useState<FormData>({
    email: "",
    phone: "",
    name: "",
    cpf: "",
    cep: "",
    address: "",
    number: "",
    noNumber: false,
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
    country: "Brasil",
  })
  const [cardData, setCardData] = useState<CreditCardData>({
    // REMOVED: cardData, only used for credit card
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
    installments: 1,
  })
  const [pixCode, setPixCode] = useState("")
  const [cartExpanded, setCartExpanded] = useState(true)
  const [timeLeft, setTimeLeft] = useState(600)
  const [instructionsExpanded, setInstructionsExpanded] = useState(false)

  const [apiFormData, setApiFormData] = useState<FormData | null>(null)

  const [isProcessingPayment, setIsProcessingPayment] = useState(false)
  const [paymentError, setPaymentError] = useState<string | null>(null)
  const [customerId, setCustomerId] = useState<string | null>(null)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [paymentPollingInterval, setPaymentPollingInterval] = useState<NodeJS.Timeout | null>(null)

  // Function to send Facebook Conversion API event (placeholder)
  const sendConversionEvent = async (eventName: string, eventData: any) => {
    console.log(`[FB Conversion API] Event: ${eventName}`, eventData)
    // In a real application, you would implement the actual API call here.
    // Example:
    // await fetch('/api/facebook-conversion', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ eventName, eventData }),
    // });
  }

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0))
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    if (state.currentPage === 17) {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }, [state.currentPage])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const [answers, setAnswers] = useState<Record<number, Answer>>({
    1: null,
    2: null,
    3: null,
    4: null,
    5: null,
    6: null,
    7: null,
    8: null,
    9: null,
    10: null,
    11: null,
    12: null,
    13: null,
    14: null,
  })

  const [privacyDialogOpen, setPrivacyDialogOpen] = useState(false)

  const handleAnswer = (pageNum: number, value: Answer) => {
    setAnswers((prev) => ({ ...prev, [pageNum]: value }))
    if (pageNum === 14) {
      setTimeout(() => setCurrentPage(15), 300)
    }
  }

  const setCurrentPage = useCallback((page: number) => {
    setState((prev) => ({ ...prev, isVisible: false }))
    setTimeout(() => {
      setState({ currentPage: page, isVisible: true })
    }, 300) // 300ms fade out duration
  }, [])

  const goBack = () => {
    if (state.currentPage > 1) {
      setCurrentPage(state.currentPage - 1)
    }
  }

  const logoAlignment = state.currentPage === 1 ? "justify-start pl-4" : "justify-center"
  const progressPercentage = Math.min((state.currentPage / QUIZ_PAGES) * 100, 100)
  const displayCounter = state.currentPage <= QUIZ_PAGES ? `${state.currentPage}/${QUIZ_PAGES}` : "Completo"

  const calculateSubtotal = () => {
    const basePrice = 18.9
    const orderBump1Price = orderBump1 ? 6 : 0
    const orderBump2Price = orderBump2 ? 29.9 : 0
    const orderBump3Price = orderBump3 ? 35.9 : 0
    const orderBump4Price = orderBump4 ? 49.9 : 0
    const orderBump5Price = orderBump5 ? 55.9 : 0
    return basePrice + orderBump1Price + orderBump2Price + orderBump3Price + orderBump4Price + orderBump5Price
  }

  const calculateTotal = () => {
    const basePrice = 18.9
    const orderBump1Price = orderBump1 ? 6 : 0
    const orderBump2Price = orderBump2 ? 29.9 : 0
    const orderBump3Price = orderBump3 ? 35.9 : 0
    const orderBump4Price = orderBump4 ? 49.9 : 0
    const orderBump5Price = orderBump5 ? 55.9 : 0
    return basePrice + orderBump1Price + orderBump2Price + orderBump3Price + orderBump4Price + orderBump5Price
  }

  const processPayment = async () => {
    try {
      setIsProcessingPayment(true)
      setPaymentError(null)

      if (!apiFormData) {
        throw new Error("Dados do formulario nao encontrados")
      }

      const nameParts = apiFormData.name.trim().split(" ")
      const firstname = nameParts[0] || ""
      const lastname = nameParts.slice(1).join(" ") || nameParts[0] || ""

      const customerResponse = await fetch("/api/checkout/customer-simple", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstname: firstname,
          lastname: lastname,
          email: apiFormData.email,
          telephone: apiFormData.phone,
          document_number: apiFormData.cpf,
          origin_url: "https://protocolo30dias.com/",
        }),
      }).catch((error) => {
        console.error("[v0] Network error:", error)
        throw new Error("Erro de conexao. Verifique sua internet.")
      })

      if (!customerResponse.ok) {
        const errorData = await customerResponse.json().catch(() => ({}))
        throw new Error(errorData.error || "Erro ao criar cliente")
      }

      const customerData = await customerResponse.json()
      const customer_id = customerData.data?.id || customerData.customer_id

      if (!customer_id) {
        throw new Error("ID do cliente nao foi retornado pela API")
      }

      setCustomerId(customer_id)

      console.log("[v0] Cliente criado com ID:", customer_id)

      const selectedTotal =
        (orderBump1 ? 6 : 0) +
        (orderBump2 ? 29.9 : 0) +
        (orderBump3 ? 35.9 : 0) +
        (orderBump4 ? 49.9 : 0) +
        (orderBump5 ? 55.9 : 0)
      const finalTotal = 18.9 + selectedTotal

      const products = [
        {
          sku: "PROT30D",
          name: "Protocolo 30 Dias - Inova Mulher",
          qty: 1,
          price: finalTotal,
        },
      ]

      const orderResponse = await fetch("/api/checkout/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_id, // Now using the customer_id variable correctly
          products,
          total: finalTotal,
          digital_product: 1,
          origin_url: "https://protocolo30dias.com/",
        }),
      }).catch((error) => {
        console.error("[v0] Network error:", error)
        throw new Error("Erro de conexao. Verifique sua internet.")
      })

      if (!orderResponse.ok) {
        const errorData = await orderResponse.json().catch(() => ({}))
        throw new Error(errorData.error || "Erro ao criar pedido")
      }

      const orderData = await orderResponse.json()
      const order_id = orderData.data?.id || orderData.order_id

      if (!order_id) {
        throw new Error("ID do pedido nao foi retornado pela API")
      }

      setOrderId(order_id)

      console.log("[v0] Pedido criado com ID:", order_id)

      return { customer_id, order_id }
    } catch (error) {
      console.error("[v0] Erro no processamento:", error)
      setPaymentError(error instanceof Error ? error.message : "Erro desconhecido")
      throw error
    } finally {
      setIsProcessingPayment(false)
    }
  }

  const startPaymentPolling = useCallback(
    (order_id: string) => {
      console.log("[v0] Starting payment polling for order:", order_id)

      const checkPayment = async () => {
        try {
          const response = await fetch(`/api/checkout/check-payment?order_id=${order_id}`)
          const data = await response.json()

          console.log(`[v0] Checking payment status for order: ${order_id} - Paid: ${data.isPaid}`)

          if (data.isPaid) {
            console.log("[v0] Payment confirmed! Redirecting to thank you page...")

            // Clear polling interval
            if (paymentPollingInterval) {
              clearInterval(paymentPollingInterval)
              setPaymentPollingInterval(null)
            }

            // Get customer data
            const customerEmail = apiFormData?.email || formData.email || ""
            const customerPhone = apiFormData?.phone || formData.phone || ""
            const customerName = apiFormData?.name || formData.name || ""
            const totalValue = calculateTotal()

            const trackingResponse = await fetch(`/api/checkout/get-tracking?order_id=${order_id}`)
            const trackingData = await trackingResponse.json()

            const fbp = trackingData.fbp || ""
            const fbc = trackingData.fbc || ""
            const fbclid = trackingData.fbclid || ""

            window.location.href = `/obrigado?order_id=${order_id}&value=${totalValue}&source=new-quiz&email=${encodeURIComponent(customerEmail)}&phone=${encodeURIComponent(customerPhone)}&name=${encodeURIComponent(customerName)}&fbp=${encodeURIComponent(fbp)}&fbc=${encodeURIComponent(fbc)}&fbclid=${encodeURIComponent(fbclid)}`
          }
        } catch (error) {
          console.error("[v0] Error checking payment:", error)
        }
      }

      // Check immediately
      checkPayment()

      // Then check every 2 seconds
      const interval = setInterval(checkPayment, 2000)
      setPaymentPollingInterval(interval)
    },
    [apiFormData, formData, paymentPollingInterval],
  )

  useEffect(() => {
    return () => {
      if (paymentPollingInterval) {
        clearInterval(paymentPollingInterval)
      }
    }
  }, [paymentPollingInterval])

  const generatePixCode = async () => {
    try {
      let finalCustomerId = customerId
      let finalOrderId = orderId

      if (!finalCustomerId || !finalOrderId) {
        const { customer_id, order_id } = await processPayment()

        if (!customer_id || !order_id) {
          throw new Error("IDs nao foram gerados corretamente")
        }

        finalCustomerId = customer_id
        finalOrderId = order_id

        setOrderId(order_id)
      }

      if (!apiFormData) {
        throw new Error("Dados do formulario nao encontrados")
      }

      const pixResponse = await fetch("/api/checkout/payment/pix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          order_id: finalOrderId,
          customer_id: finalCustomerId,
          cpf: apiFormData.cpf,
        }),
      }).catch((error) => {
        console.error("[v0] Network error:", error)
        throw new Error("Erro de conexao. Verifique sua internet.")
      })

      if (!pixResponse.ok) {
        const errorData = await pixResponse.json().catch(() => ({}))
        throw new Error(errorData.error || "Erro ao gerar codigo PIX")
      }

      const pixData = await pixResponse.json()
      const pixEmvCode = pixData.data?.pix_emv || pixData.pix_emv || pixData.pix_code

      if (!pixEmvCode) {
        console.error("[v0] PIX response:", pixData)
        throw new Error("Codigo PIX nao encontrado na resposta")
      }

      setPixCode(pixEmvCode)
      setCurrentPage(19)

      if (finalOrderId) {
        startPaymentPolling(finalOrderId)
      }
    } catch (error) {
      console.error("[v0] Erro ao gerar PIX:", error)
      setPaymentError(error instanceof Error ? error.message : "Erro ao gerar codigo PIX")
    }
  }

  const handleSubmitIdentification = async (e: React.FormEvent) => {
    e.preventDefault()

    setApiFormData({
      ...formData,
    })

    setCurrentPage(16)
  }

  const handleCheckout = () => {
    if (paymentMethod === "pix") {
      generatePixCode()
    } else {
      // REMOVED: setCurrentPage(20) - credit card payment
      // This path is no longer reachable as credit card is removed.
    }
  }

  const processCreditCardPayment = async () => {
    // REMOVED: this function is no longer used
    try {
      setIsProcessingPayment(true)
      setPaymentError(null)

      // Validate card data
      if (!cardData.cardNumber || !cardData.cardName || !cardData.expiryDate || !cardData.cvv) {
        throw new Error("Por favor, preencha todos os dados do cartão")
      }

      // First, create customer and order
      const { customer_id, order_id } = await processPayment()

      if (!customer_id || !order_id) {
        throw new Error("Erro ao criar pedido. Tente novamente.")
      }

      // Parse expiry date (MM/YY format)
      const [month, year] = cardData.expiryDate.split("/")

      if (!month || !year || month.length !== 2 || year.length !== 2) {
        throw new Error("Data de validade inválida. Use o formato MM/AA")
      }

      // Prepare cart data
      const selectedTotal =
        (orderBump1 ? 6 : 0) +
        (orderBump2 ? 29.9 : 0) +
        (orderBump3 ? 35.9 : 0) +
        (orderBump4 ? 49.9 : 0) +
        (orderBump5 ? 55.9 : 0)
      const finalTotal = 18.9 + selectedTotal

      // Call credit card payment API
      const paymentResponse = await fetch("/api/checkout/payment/creditcard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cart: {
            order_id: order_id,
          },
          customer: {
            customer_id: customer_id,
          },
          payment: {
            creditcard: {
              number: cardData.cardNumber.replace(/\s/g, ""),
              name: cardData.cardName,
              cvv: cardData.cvv,
              month: month,
              year: "20" + year,
              installments: cardData.installments,
              document_number: apiFormData?.cpf || "",
            },
          },
        }),
      })

      if (!paymentResponse.ok) {
        const errorData = await paymentResponse.json().catch(() => ({}))
        throw new Error(errorData.error || "Erro ao processar pagamento com cartão")
      }

      const paymentData = await paymentResponse.json()

      if (!paymentData.success) {
        throw new Error(paymentData.text || paymentData.message || "Pagamento não autorizado")
      }

      // Send Facebook Conversion API event
      await sendConversionEvent("Purchase", {
        value: finalTotal,
        currency: "BRL",
        content_ids: ["PROT30D"],
        content_type: "product",
      })

      // Redirect to success page or show success message
      alert("Pagamento aprovado com sucesso!")
      // You can redirect to a success page here if needed
    } catch (error) {
      console.error("[v0] Erro no pagamento:", error)
      setPaymentError(error instanceof Error ? error.message : "Erro ao processar pagamento")
      alert(`Erro ao processar pagamento: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    } finally {
      setIsProcessingPayment(false)
    }
  }

  const renderQuizContent = () => {
    switch (state.currentPage) {
      case 1:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-3xl font-bold text-gray-900">
              Vamos iniciar seu <span className="bg-[#22C55E] px-2 text-white">plano de emagracimento</span> com nosso
              Protocolo?
            </h2>
            <div className="mb-8 flex justify-center">
              <Image
                src="/protocolo-30-dias-inicio.jpg"
                alt="Protocolo 30 Dias"
                width={400}
                height={400}
                className="rounded-lg"
              />
            </div>
            <button
              onClick={() => setCurrentPage(2)}
              className="h-14 w-full rounded-xl bg-[#22C55E] text-lg font-semibold text-white hover:bg-[#16A34A] active:scale-95 transition-all"
            >
              Sim, quero começar!
            </button>
            <div className="mt-6 text-center text-sm text-gray-600">
              Protocolo 30 Dias -{" "}
              <button onClick={() => setShowPrivacyModal(true)} className="text-[#22C55E] hover:underline font-medium">
                Política de Privacidade
              </button>
            </div>
          </div>
        )

      case 2:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              O que mais te incomoda no seu corpo hoje?
            </h2>
            <div className="space-y-3">
              {["Peso", "Gordura localizada", "Falta de energia", "Ansiedade", "Outro"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(2, option)
                    setCurrentPage(3)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[2] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 3:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual é o seu maior objetivo?</h2>
            <div className="space-y-3">
              {["Emagrecer", "Ganhar massa muscular", "Melhorar saude", "Aumentar disposicao", "Outros"].map(
                (option) => (
                  <button
                    key={option}
                    onClick={() => {
                      handleAnswer(3, option)
                      setCurrentPage(4)
                    }}
                    className={cn(
                      "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                      answers[3] === option
                        ? "border-[#22C55E] bg-[#22C55E] text-white"
                        : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                    )}
                  >
                    {option}
                  </button>
                ),
              )}
            </div>
          </div>
        )

      case 4:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Ha quanto tempo voce tenta alcancar seu objetivo?
            </h2>
            <div className="space-y-3">
              {["Menos de 3 meses", "3-6 meses", "6-12 meses", "Mais de 1 ano"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(4, option)
                    setCurrentPage(5)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[4] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 5:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Voce ja tentou algum metodo antes?</h2>
            <div className="space-y-3">
              {["Sim, varios", "Sim, alguns", "Nao, e minha primeira vez"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(5, option)
                    setCurrentPage(6)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[5] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 6:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Qual foi o principal motivo para nao dar certo?
            </h2>
            <div className="space-y-3">
              {["Falta de resultados", "Muito caro", "Muito complicado", "Falta de tempo", "Nao tentei antes"].map(
                (option) => (
                  <button
                    key={option}
                    onClick={() => {
                      handleAnswer(6, option)
                      setCurrentPage(7)
                    }}
                    className={cn(
                      "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                      answers[6] === option
                        ? "border-[#22C55E] bg-[#22C55E] text-white"
                        : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                    )}
                  >
                    {option}
                  </button>
                ),
              )}
            </div>
          </div>
        )

      case 7:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Voce tem algum problema de saude?</h2>
            <div className="space-y-3">
              {[
                { label: "Tenho", icon: "✓" },
                { label: "Nao tenho", icon: null },
              ].map((option) => (
                <button
                  key={option.label}
                  onClick={() => {
                    handleAnswer(7, option.label)
                    setCurrentPage(8)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all flex items-center",
                    answers[7] === option.label
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option.icon && <span className="mr-2">{option.icon}</span>}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        )

      case 8:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Qual e o seu nivel de atividade fisica?
            </h2>
            <div className="space-y-3">
              {["Sedentario", "Leve (1-2x/semana)", "Moderado (3-4x/semana)", "Intenso (5+x/semana)"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(8, option)
                    setCurrentPage(9)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[8] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 9:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Como voce descreveria sua alimentacao?
            </h2>
            <div className="space-y-3">
              {["Muito saudavel", "Equilibrada", "Precisa melhorar", "Desorganizada"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(9, option)
                    setCurrentPage(10)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[9] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 10:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Quanto tempo você pode dedicar por dia?
            </h2>
            <div className="space-y-3">
              {["15-30 minutos", "30-45 minutos", "45-60 minutos", "Mais de 1 hora"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(10, option)
                    setCurrentPage(11)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[10] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 11:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Voce tem alguma restricao alimentar?</h2>
            <div className="space-y-3">
              {["Nao tenho", "Vegetariana", "Vegana", "Intolerancia a lactose", "Outra"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(11, option)
                    setCurrentPage(12)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[11] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 12:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Qual é o seu nível de motivação hoje?</h2>
            <div className="space-y-3">
              {["Muito motivada", "Motivada", "Razoavelmente motivada", "Preciso de ajuda"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(12, option)
                    setCurrentPage(13)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[12] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 13:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">O que mais te motiva a mudar?</h2>
            <div className="space-y-3">
              {["Saude", "Autoestima", "Qualidade de vida", "Bem-estar", "Todos os acima"].map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    handleAnswer(13, option)
                    setCurrentPage(14)
                  }}
                  className={cn(
                    "h-14 w-full rounded-xl border-2 text-left px-4 text-base font-medium transition-all",
                    answers[13] === option
                      ? "border-[#22C55E] bg-[#22C55E] text-white"
                      : "border-gray-300 bg-white text-gray-700 hover:border-[#22C55E]",
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )

      case 14:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">
              Esta pronta para transformar sua vida?
            </h2>
            <button
              onClick={() => handleAnswer(14, "Sim")}
              className="h-14 w-full rounded-xl bg-[#22C55E] text-lg font-semibold text-white hover:bg-[#16A34A] disabled:bg-gray-300 disabled:cursor-not-allowed transition-all"
            >
              Sim, estou pronta!
            </button>
          </div>
        )

      case 15:
        return (
          <div
            className={`flex flex-col transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h2 className="mb-8 text-center text-2xl font-bold text-gray-900">Vamos conhecer voce melhor</h2>
            <form onSubmit={handleSubmitIdentification} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome Completo</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  value={formData.cpf}
                  onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                  required
                />
              </div>
              <div className="flex items-start space-x-2">
                <input type="checkbox" id="privacy" required className="mt-1" />
                <label htmlFor="privacy" className="text-sm text-gray-600">
                  Eu aceito a{" "}
                  <button type="button" onClick={() => setPrivacyDialogOpen(true)} className="text-[#22C55E] underline">
                    Politica de Privacidade
                  </button>
                </label>
              </div>
              <Button type="submit" className="w-full h-12 bg-[#22C55E] hover:bg-[#16A34A] text-white">
                Continuar
              </Button>
            </form>

            <Dialog open={privacyDialogOpen} onOpenChange={setPrivacyDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Politica de Privacidade</DialogTitle>
                </DialogHeader>
                <div className="max-h-96 overflow-y-auto">
                  <p className="text-sm text-gray-600">
                    Este e um exemplo de politica de privacidade. Seus dados serao tratados com seguranca e
                    confidencialidade.
                  </p>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        )

      case 16:
        return (
          <div
            className={`flex flex-col w-full px-8 py-8 transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">
              Chegou a hora de resgatar seu <span className="bg-[#22C55E] text-white px-2 py-1">Protocolo 30 Dias</span>
            </h1>
            <p className="mb-8 text-center text-gray-600">Sua nova jornada ira comecar e nos estaremos juntos ❤️</p>
            <div className="mb-8 flex justify-center">
              <Image
                src="/protocolo-30-dias-running.jpg"
                alt="Protocolo 30 Dias"
                width={400}
                height={400}
                className="object-contain rounded-lg"
              />
            </div>
            <div className="mb-8 rounded-xl bg-white p-6 shadow-sm flex items-center justify-between">
              <div className="text-xl font-bold text-gray-900">Protocolo 30 Dias</div>
              <div className="text-2xl font-bold text-gray-900">R$ 18,90</div>
            </div>
            <button
              onClick={() => setCurrentPage(17)}
              className="w-full rounded-xl bg-[#22C55E] py-4 text-xl font-bold text-white hover:bg-[#16A34A] transition-colors"
            >
              RESGATAR
            </button>
          </div>
        )

      case 17:
        return (
          <div
            className={`min-h-screen bg-gray-50 transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <div className="mx-auto max-w-md p-4">
              {/* Logo and Security Badge */}
              <div className="mb-6 flex items-center justify-between">
                <Image
                  src="/images/protocolo-30-dias-logo-horizontal.png"
                  alt="Protocolo 30 Dias"
                  className="h-10 w-auto object-contain"
                  width={120}
                  height={40}
                />
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#22C55E] rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div className="text-right">
                    <div className="text-[#22C55E] font-bold text-sm">PAGAMENTO</div>
                    <div className="text-[#22C55E] font-bold text-xs">100% SEGURO</div>
                  </div>
                </div>
              </div>

              {paymentError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                  <p className="font-semibold">Erro ao processar pagamento:</p>
                  <p className="text-sm">{paymentError}</p>
                </div>
              )}

              {/* Cart Section */}
              <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-gray-900">Seu carrinho</h2>
                  <div className="w-8 h-8 bg-[#22C55E] rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {1 +
                      (orderBump1 ? 1 : 0) +
                      (orderBump2 ? 1 : 0) +
                      (orderBump3 ? 1 : 0) +
                      (orderBump4 ? 1 : 0) +
                      (orderBump5 ? 1 : 0)}
                  </div>
                </div>

                <div className="space-y-4">
                  {/* Base Product */}
                  <div className="flex gap-3">
                    <Image
                      src="/protocolo-30-dias-inicio.jpg"
                      alt="Protocolo 30 Dias"
                      width={64}
                      height={64}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900 text-sm">Protocolo 30 Dias</div>
                      <div className="text-gray-500 text-sm">Inova Mulher</div>
                      <div className="font-semibold text-gray-900 text-sm">R$ 18,90</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500">1 un.</div>
                    </div>
                  </div>

                  <div className="space-y-3 border-t pt-4">
                    <div className="text-sm font-semibold text-gray-700">Ofertas especiais</div>

                    {/* Order Bump 1 */}
                    <div
                      onClick={() => setOrderBump1(!orderBump1)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        orderBump1
                          ? "border-[#22C55E] bg-[#22C55E]/5"
                          : "border-gray-300 bg-white hover:border-[#22C55E]/50"
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div
                            className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                              orderBump1 ? "bg-[#22C55E] border-[#22C55E]" : "border-gray-300"
                            }`}
                          >
                            {orderBump1 && (
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 text-sm">Guia Alimentar 30 Dias</div>
                          <div className="text-gray-500 text-xs">Plano nutricional completo</div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">+ R$ 6,00</span>
                            <span className="bg-[#22C55E] text-white text-xs font-bold px-2 py-0.5 rounded">
                              OFERTA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Order Bump 2 */}
                    <div
                      onClick={() => setOrderBump2(!orderBump2)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        orderBump2
                          ? "border-[#22C55E] bg-[#22C55E]/5"
                          : "border-gray-300 bg-white hover:border-[#22C55E]/50"
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div
                            className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                              orderBump2 ? "bg-[#22C55E] border-[#22C55E]" : "border-gray-300"
                            }`}
                          >
                            {orderBump2 && (
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 text-sm">Treinos Personalizados</div>
                          <div className="text-gray-500 text-xs">Videos e exercicios exclusivos</div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">+ R$ 29,90</span>
                            <span className="bg-[#22C55E] text-white text-xs font-bold px-2 py-0.5 rounded">
                              OFERTA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      onClick={() => setOrderBump3(!orderBump3)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        orderBump3
                          ? "border-[#22C55E] bg-[#22C55E]/5"
                          : "border-gray-300 bg-white hover:border-[#22C55E]/50"
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div
                            className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                              orderBump3 ? "bg-[#22C55E] border-[#22C55E]" : "border-gray-300"
                            }`}
                          >
                            {orderBump3 && (
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 text-sm">Receitas Fit</div>
                          <div className="text-gray-500 text-xs">Mais de 50 receitas saudaveis</div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">+ R$ 35,90</span>
                            <span className="bg-[#22C55E] text-white text-xs font-bold px-2 py-0.5 rounded">
                              OFERTA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      onClick={() => setOrderBump4(!orderBump4)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        orderBump4
                          ? "border-[#22C55E] bg-[#22C55E]/5"
                          : "border-gray-300 bg-white hover:border-[#22C55E]/50"
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div
                            className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                              orderBump4 ? "bg-[#22C55E] border-[#22C55E]" : "border-gray-300"
                            }`}
                          >
                            {orderBump4 && (
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          {/* Changed from "Grupo VIP WhatsApp" */}
                          <div className="font-semibold text-gray-900 text-sm">Guia Detox Avancado</div>
                          {/* Added description */}
                          <div className="text-gray-500 text-xs">Desintoxique e emagreca</div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">+ R$ 49,90</span>
                            <span className="bg-[#22C55E] text-white text-xs font-bold px-2 py-0.5 rounded">
                              OFERTA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      onClick={() => setOrderBump5(!orderBump5)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        orderBump5
                          ? "border-[#22C55E] bg-[#22C55E]/5"
                          : "border-gray-300 bg-white hover:border-[#22C55E]/50"
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div
                            className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                              orderBump5 ? "bg-[#22C55E] border-[#22C55E]" : "border-gray-300"
                            }`}
                          >
                            {orderBump5 && (
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 text-sm">Levar todas promocoes</div>
                          <div className="text-gray-500 text-xs">Todas as ofertas juntas com desconto</div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">+ R$ 55,90</span>
                            <span className="bg-[#22C55E] text-white text-xs font-bold px-2 py-0.5 rounded">
                              OFERTA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cart Summary */}
                <div className="mt-4 space-y-4 border-t pt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-semibold">R$ {calculateSubtotal().toFixed(2).replace(".", ",")}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-2 border-t">
                    <span>Total</span>
                    <span className="text-[#22C55E]">R$ {calculateTotal().toFixed(2).replace(".", ",")}</span>
                  </div>
                </div>
              </div>

              {/* Payment Section */}
              <div className="bg-white rounded-lg shadow-sm p-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Pagamento</h2>

                {/* Payment Method Toggle - REMOVED: credit card button */}
                <div className="flex gap-4 mb-6">
                  <button
                    onClick={() => setPaymentMethod("pix")}
                    className="flex-1 p-6 rounded-lg border-2 border-[#22C55E] bg-white transition-all"
                  >
                    <Image
                      src="/images/pix-logo-oficial.png"
                      alt="PIX"
                      width={80}
                      height={80}
                      className="w-20 h-20 mx-auto object-contain"
                    />
                  </button>
                </div>

                {/* REMOVED: Credit Card Form */}

                {/* PIX Payment */}
                {paymentMethod === "pix" && (
                  <div>
                    <button
                      onClick={generatePixCode}
                      disabled={isProcessingPayment}
                      className="w-full bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold py-4 rounded-lg transition-colors text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isProcessingPayment ? "PROCESSANDO..." : "GERAR PIX"}
                    </button>
                  </div>
                )}

                <button
                  onClick={() => setCurrentPage(16)}
                  className="w-full text-gray-400 hover:text-gray-600 font-medium py-3 text-center transition-colors mt-4"
                >
                  Voltar
                </button>
              </div>
            </div>
          </div>
        )

      case 19:
        return (
          <div
            className={`flex flex-col items-center justify-center min-h-screen px-6 py-8 bg-gray-50 transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
          >
            <div className="w-full max-w-md">
              <h1 className="text-2xl font-bold text-gray-900 text-center mb-8 leading-tight">
                Falta pouco! Para finalizar a compra, efetue o pagamento com PIX!
              </h1>

              <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
                <div className="text-center mb-6">
                  <p className="text-gray-600 mb-2">O codigo expira em:</p>
                  <p className="text-5xl font-bold text-red-500">09:22</p>
                </div>

                <div className="mb-6">
                  <p className="text-center text-gray-700 mb-4">
                    Copie a chave abaixo e utilize a opcao
                    <br />
                    <span className="font-bold text-gray-900">PIX Copia e Cola:</span>
                  </p>

                  {pixCode ? (
                    <>
                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
                        <p className="text-sm text-gray-700 break-all leading-relaxed">{pixCode}</p>
                      </div>

                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(pixCode)
                          alert("Codigo PIX copiado!")
                        }}
                        className="w-full bg-[#22C55E] text-white py-4 rounded-lg font-bold text-lg hover:bg-[#16A34A] transition-colors flex items-center justify-center gap-2"
                      >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <rect
                            x="9"
                            y="9"
                            width="13"
                            height="13"
                            rx="2"
                            ry="2"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        COPIAR CODIGO
                      </button>
                    </>
                  ) : (
                    <div className="text-center text-gray-500">Carregando codigo PIX...</div>
                  )}
                </div>

                <div className="text-center mb-6">
                  <p className="text-gray-600">
                    Valor a ser pago:{" "}
                    <span className="text-[#22C55E] font-bold text-2xl">
                      R${" "}
                      {(
                        18.9 +
                        (orderBump1 ? 6 : 0) +
                        (orderBump2 ? 29.9 : 0) +
                        (orderBump3 ? 35.9 : 0) +
                        (orderBump4 ? 49.9 : 0) +
                        (orderBump5 ? 55.9 : 0)
                      )
                        .toFixed(2)
                        .replace(".", ",")}
                    </span>
                  </p>
                </div>

                <details className="border-t border-gray-200 pt-4">
                  <summary className="cursor-pointer text-gray-900 font-semibold flex items-center justify-between">
                    Instrucoes para pagamento
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </summary>
                  <div className="mt-4 text-sm text-gray-600 space-y-2">
                    <p>1. Abra o app do seu banco</p>
                    <p>2. Escolha a opcao PIX Copia e Cola</p>
                    <p>3. Cole o codigo copiado</p>
                    <p>4. Confirme o pagamento</p>
                  </div>
                </details>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-center gap-6 text-gray-500 text-sm">
                  <img src="/images/pix-logo.png" alt="PIX - powered by Banco Central" className="h-8 w-auto" />
                  <div className="flex items-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                      />
                    </svg>
                    <span>Ambiente seguro</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      // REMOVED: case 20, which was for credit card payment
      // case 20:
      //   return (
      //     <div
      //       className={`flex flex-col items-center justify-center min-h-screen px-6 py-8 bg-gray-50 transition-opacity duration-300 ${state.isVisible ? "opacity-100" : "opacity-0"}`}
      //     >
      //       <div className="w-full max-w-md">
      //         <h1 className="text-2xl font-bold text-gray-900 text-center mb-8 leading-tight">
      //           Falta pouco! Para finalizar a compra, efetue o pagamento com Cartão de Crédito!
      //         </h1>

      //         <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
      //           <div className="text-center mb-6">
      //             <p className="text-gray-600 mb-2">O pagamento será processado em:</p>
      //             <p className="text-5xl font-bold text-red-500">09:22</p>
      //           </div>
      //           <div className="text-center mb-6">
      //             <p className="text-gray-600">
      //               Valor a ser pago:{" "}
      //               <span className="text-[#22C55E] font-bold text-2xl">
      //                 R${" "}
      //                 {(
      //                   18.9 +
      //                   (orderBump1 ? 6 : 0) +
      //                   (orderBump2 ? 29.9 : 0) +
      //                   (orderBump3 ? 35.9 : 0) +
      //                   (orderBump4 ? 49.9 : 0) +
      //                   (orderBump5 ? 55.9 : 0)
      //                 )
      //                   .toFixed(2)
      //                   .replace(".", ",")}
      //               </span>
      //             </p>
      //           </div>

      //           <details className="border-t border-gray-200 pt-4">
      //             <summary className="cursor-pointer text-gray-900 font-semibold flex items-center justify-between">
      //               Instruções para pagamento com Cartão de Crédito
      //               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      //                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      //               </svg>
      //             </summary>
      //             <div className="mt-4 text-sm text-gray-600 space-y-2">
      //               <p>1. Preencha os dados do seu cartão de crédito com segurança.</p>
      //               <p>2. Escolha o número de parcelas desejado.</p>
      //               <p>3. Clique em "Finalizar Compra" para concluir.</p>
      //             </div>
      //           </details>
      //         </div>

      //         <div className="mt-8 pt-6 border-t border-gray-200">
      //           <div className="flex items-center justify-center gap-6 text-gray-500 text-sm">
      //             <img src="/images/pix-logo.png" alt="PIX - powered by Banco Central" className="h-8 w-auto" />
      //             <div className="flex items-center gap-2">
      //               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      //                 <path
      //                   strokeLinecap="round"
      //                   strokeLinejoin="round"
      //                   strokeWidth={2}
      //                   d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
      //                 />
      //               </svg>
      //               <span>Ambiente seguro</span>
      //             </div>
      //           </div>
      //         </div>
      //       </div>
      //     </div>
      //   )

      default:
        return <div>Pagina nao encontrada</div>
    }
  }

  return (
    <>
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="relative max-h-[80vh] w-full max-w-2xl overflow-y-auto rounded-lg bg-white p-6 shadow-xl">
            <button
              onClick={() => setShowPrivacyModal(false)}
              className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
            >
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Política de Privacidade</h2>
            <div className="space-y-4 text-sm text-gray-700">
              <p>
                <strong>Última atualização:</strong> {new Date().toLocaleDateString("pt-BR")}
              </p>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">1. Informações que Coletamos</h3>
                <p>
                  Coletamos informações que você nos fornece diretamente, incluindo nome, e-mail, telefone e outras
                  informações de contato quando você se cadastra no Protocolo 30 Dias.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">2. Como Usamos Suas Informações</h3>
                <p>
                  Utilizamos suas informações para fornecer, manter e melhorar nossos serviços, processar transações,
                  enviar comunicações relacionadas ao produto e responder às suas solicitações.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">3. Compartilhamento de Informações</h3>
                <p>
                  Não vendemos suas informações pessoais. Podemos compartilhar suas informações com prestadores de
                  serviços terceirizados que nos auxiliam na operação do negócio, sempre sob confidencialidade.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">4. Segurança</h3>
                <p>
                  Implementamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não
                  autorizado, alteração, divulgação ou destruição.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">5. Seus Direitos</h3>
                <p>
                  Você tem o direito de acessar, corrigir ou excluir suas informações pessoais a qualquer momento. Para
                  exercer esses direitos, entre em contato conosco através dos canais de atendimento.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">6. Cookies</h3>
                <p>
                  Utilizamos cookies e tecnologias similares para melhorar sua experiência, analisar o uso do site e
                  personalizar conteúdo.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">7. Alterações na Política</h3>
                <p>
                  Podemos atualizar esta política periodically. Notificaremos você sobre mudanças significativas através
                  do e-mail cadastrado ou por meio de avisos no site.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">8. Contato</h3>
                <p>
                  Se você tiver dúvidas sobre esta Política de Privacidade, entre em contato conosco através dos nossos
                  canais de atendimento ao cliente.
                </p>
              </section>
            </div>
            <button
              onClick={() => setShowPrivacyModal(false)}
              className="mt-6 w-full rounded-lg bg-[#22C55E] py-3 font-semibold text-white hover:bg-[#16A34A]"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
      <div className="relative min-h-screen bg-white">
        {state.currentPage === 17 || state.currentPage === 19 ? (
          renderQuizContent()
        ) : (
          <>
            <div className="sticky top-0 z-50 bg-white shadow-sm">
              <div className="mx-auto flex max-w-md items-center justify-between px-6 py-4">
                {state.currentPage > 1 && (
                  <button onClick={goBack} className="w-6 text-gray-600">
                    <ChevronLeft className="h-6 w-6" />
                  </button>
                )}

                <div className={cn("flex flex-1 items-center", logoAlignment)}>
                  <Image
                    src="/images/protocolo-30-dias-logo-horizontal.png"
                    alt="Protocolo 30 Dias"
                    className="h-10 w-auto object-contain"
                    width={200}
                    height={40}
                  />
                </div>

                <div className="w-16 text-right">
                  {state.currentPage <= QUIZ_PAGES ? (
                    <div className="text-sm font-medium text-gray-900">{`${state.currentPage}/${QUIZ_PAGES}`}</div>
                  ) : (
                    <div className="flex items-center justify-end gap-1">
                      <Check className="h-4 w-4" style={{ fill: "#7CB342", stroke: "#7CB342" }} />
                      <span className="text-sm font-medium" style={{ color: "#7CB342" }}>
                        Completo
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="h-1 bg-gray-200">
                <div
                  className="h-full bg-[#22C55E] transition-all duration-300"
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
            </div>

            <div className="mx-auto max-w-md px-6 py-8">{renderQuizContent()}</div>
          </>
        )}
      </div>
    </>
  )
}
