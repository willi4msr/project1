"use client"

import { CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { CheckoutData } from "@/components/checkout-flow"

type SuccessStepProps = {
  checkoutData: CheckoutData
}

export function SuccessStep({ checkoutData }: SuccessStepProps) {
  return (
    <div className="text-center py-12 space-y-6">
      <div className="flex justify-center">
        <div className="rounded-full bg-green-100 p-6">
          <CheckCircle2 className="h-16 w-16 text-green-600" />
        </div>
      </div>

      <div className="space-y-2">
        <h2 className="text-3xl font-bold">Pedido Confirmado!</h2>
        <p className="text-muted-foreground">
          Seu pedido foi processado com sucesso e você receberá um e-mail de confirmação em breve.
        </p>
      </div>

      <div className="bg-muted p-6 rounded-lg max-w-md mx-auto space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">ID do Pedido:</span>
          <span className="font-mono font-semibold">#{checkoutData.orderId}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Forma de Pagamento:</span>
          <span className="font-medium capitalize">
            {checkoutData.payment?.method === "creditcard"
              ? "Cartão de Crédito"
              : checkoutData.payment?.method === "pix"
                ? "PIX"
                : "Boleto Bancário"}
          </span>
        </div>
      </div>

      <div className="flex justify-center gap-4">
        <Button variant="outline" onClick={() => window.location.reload()}>
          Fazer Novo Pedido
        </Button>
        <Button onClick={() => (window.location.href = "/")}>Voltar ao Início</Button>
      </div>
    </div>
  )
}
