"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Plus, Trash2 } from "lucide-react"

type OrderStepProps = {
  onNext: () => void
  onBack: () => void
  updateData: (data: any) => void
  customerId?: number
  initialData?: any
}

type Product = {
  sku: string
  name: string
  qty: number
  price: number
}

export function OrderStep({ onNext, onBack, updateData, customerId, initialData }: OrderStepProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [products, setProducts] = useState<Product[]>(
    initialData?.products || [{ sku: "", name: "", qty: 1, price: 0 }],
  )
  const [shipping, setShipping] = useState(initialData?.shipping || 0)
  const [discount, setDiscount] = useState(initialData?.discount || 0)

  useEffect(() => {
    if (initialData?.products && initialData.products.length > 0) {
      setProducts(initialData.products)
    }
  }, [initialData])

  const addProduct = () => {
    setProducts([...products, { sku: "", name: "", qty: 1, price: 0 }])
  }

  const removeProduct = (index: number) => {
    setProducts(products.filter((_, i) => i !== index))
  }

  const updateProduct = (index: number, field: keyof Product, value: any) => {
    const newProducts = [...products]
    newProducts[index] = { ...newProducts[index], [field]: value }
    setProducts(newProducts)
  }

  const calculateTotal = () => {
    return products.reduce((sum, product) => sum + product.price * product.qty, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const total = calculateTotal()
      const response = await fetch("/api/checkout/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_id: customerId,
          total,
          products,
          shipping,
          discount,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao criar pedido")
      }

      updateData({
        orderId: data.order_id,
        order: {
          total,
          products,
          shipping,
          discount,
        },
      })

      toast({
        title: "Pedido criado!",
        description: "Seu pedido foi criado com sucesso.",
      })

      onNext()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Carrinho de Compras</h2>
        <p className="text-sm text-muted-foreground">Adicione os produtos ao seu pedido</p>
      </div>

      <div className="space-y-4">
        {products.map((product, index) => (
          <div key={index} className="p-4 border rounded-lg space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Produto {index + 1}</h3>
              {products.length > 1 && (
                <Button type="button" variant="ghost" size="sm" onClick={() => removeProduct(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>SKU *</Label>
                <Input
                  required
                  value={product.sku}
                  onChange={(e) => updateProduct(index, "sku", e.target.value)}
                  placeholder="123456"
                />
              </div>
              <div className="space-y-2">
                <Label>Nome do Produto *</Label>
                <Input
                  required
                  value={product.name}
                  onChange={(e) => updateProduct(index, "name", e.target.value)}
                  placeholder="Tênis de Corrida"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Quantidade *</Label>
                <Input
                  type="number"
                  min="1"
                  required
                  value={product.qty}
                  onChange={(e) => updateProduct(index, "qty", Number.parseInt(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label>Preço Unitário (R$) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={product.price}
                  onChange={(e) => updateProduct(index, "price", Number.parseFloat(e.target.value))}
                  placeholder="99.90"
                />
              </div>
            </div>

            <div className="text-right text-sm font-medium">
              Subtotal: R$ {(product.price * product.qty).toFixed(2)}
            </div>
          </div>
        ))}

        <Button type="button" variant="outline" onClick={addProduct} className="w-full bg-transparent">
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Produto
        </Button>
      </div>

      <div className="border-t pt-6 space-y-4">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="shipping">Frete (R$)</Label>
            <Input
              id="shipping"
              type="number"
              step="0.01"
              min="0"
              value={shipping}
              onChange={(e) => setShipping(Number.parseFloat(e.target.value) || 0)}
              placeholder="0.00"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="discount">Desconto (R$)</Label>
            <Input
              id="discount"
              type="number"
              step="0.01"
              min="0"
              value={discount}
              onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
              placeholder="0.00"
            />
          </div>
        </div>

        <div className="bg-muted p-4 rounded-lg">
          <div className="flex justify-between text-lg font-bold">
            <span>Total do Pedido:</span>
            <span>R$ {(calculateTotal() + shipping - discount).toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="flex justify-between">
        <Button type="button" variant="outline" onClick={onBack}>
          Voltar
        </Button>
        <Button type="submit" size="lg" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Continuar para Pagamento
        </Button>
      </div>
    </form>
  )
}
