"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/hooks/use-toast"
import { CreditCard, Barcode, QrCode, Loader2 } from "lucide-react"

type PaymentStepProps = {
  onNext: () => void
  onBack: () => void
  updateData: (data: any) => void
  customerId?: number
  orderId?: number
}

export function PaymentStep({ onNext, onBack, updateData, customerId, orderId }: PaymentStepProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<"creditcard" | "boleto" | "pix">("creditcard")
  const [cardData, setCardData] = useState({
    number: "",
    name: "",
    cvv: "",
    month: "",
    year: "",
    installments: 1,
    document_number: "",
  })
  const [boletoData, setBoletoData] = useState({
    document_number: "",
  })
  const [pixData, setPixData] = useState({
    document_number: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      let endpoint = ""
      const body: any = {
        cart: { order_id: orderId },
        customer: { customer_id: customerId },
      }

      if (paymentMethod === "creditcard") {
        endpoint = "/api/checkout/payment/creditcard"
        body.payment = {
          creditcard: {
            number: cardData.number.replace(/\s/g, ""),
            name: cardData.name,
            cvv: cardData.cvv,
            month: Number.parseInt(cardData.month),
            year: Number.parseInt(cardData.year),
            installments: cardData.installments,
            document_number: cardData.document_number.replace(/\D/g, ""),
          },
        }
      } else if (paymentMethod === "boleto") {
        endpoint = "/api/checkout/payment/boleto"
        body.payment = {
          boleto: {
            document_number: boletoData.document_number.replace(/\D/g, ""),
          },
        }
      } else if (paymentMethod === "pix") {
        endpoint = "/api/checkout/payment/pix"
        body.payment = {
          pix: {
            document_number: pixData.document_number.replace(/\D/g, ""),
          },
        }
      }

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao processar pagamento")
      }

      updateData({
        payment: {
          method: paymentMethod,
          transactionId: data.transaction_id,
          ...data,
        },
      })

      toast({
        title: "Pagamento processado!",
        description: "Seu pagamento foi processado com sucesso.",
      })

      onNext()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Forma de Pagamento</h2>
        <p className="text-sm text-muted-foreground">Escolha como deseja pagar</p>
      </div>

      <RadioGroup value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
        <div className="space-y-3">
          <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
            <RadioGroupItem value="creditcard" id="creditcard" />
            <Label htmlFor="creditcard" className="flex items-center cursor-pointer flex-1">
              <CreditCard className="mr-2 h-5 w-5" />
              <span className="font-medium">Cartão de Crédito</span>
            </Label>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
            <RadioGroupItem value="pix" id="pix" />
            <Label htmlFor="pix" className="flex items-center cursor-pointer flex-1">
              <QrCode className="mr-2 h-5 w-5" />
              <span className="font-medium">PIX</span>
            </Label>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
            <RadioGroupItem value="boleto" id="boleto" />
            <Label htmlFor="boleto" className="flex items-center cursor-pointer flex-1">
              <Barcode className="mr-2 h-5 w-5" />
              <span className="font-medium">Boleto Bancário</span>
            </Label>
          </div>
        </div>
      </RadioGroup>

      {paymentMethod === "creditcard" && (
        <div className="space-y-4 border-t pt-6">
          <div className="space-y-2">
            <Label htmlFor="card_number">Número do Cartão *</Label>
            <Input
              id="card_number"
              required
              value={cardData.number}
              onChange={(e) => setCardData({ ...cardData, number: e.target.value })}
              placeholder="1234 5678 9012 3456"
              maxLength={19}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="card_name">Nome no Cartão *</Label>
            <Input
              id="card_name"
              required
              value={cardData.name}
              onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
              placeholder="NOME SOBRENOME"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="card_month">Mês *</Label>
              <Input
                id="card_month"
                required
                value={cardData.month}
                onChange={(e) => setCardData({ ...cardData, month: e.target.value })}
                placeholder="12"
                maxLength={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="card_year">Ano *</Label>
              <Input
                id="card_year"
                required
                value={cardData.year}
                onChange={(e) => setCardData({ ...cardData, year: e.target.value })}
                placeholder="25"
                maxLength={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="card_cvv">CVV *</Label>
              <Input
                id="card_cvv"
                required
                value={cardData.cvv}
                onChange={(e) => setCardData({ ...cardData, cvv: e.target.value })}
                placeholder="123"
                maxLength={4}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="card_document">CPF *</Label>
              <Input
                id="card_document"
                required
                value={cardData.document_number}
                onChange={(e) => setCardData({ ...cardData, document_number: e.target.value })}
                placeholder="000.000.000-00"
                maxLength={14}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="installments">Parcelas *</Label>
              <Input
                id="installments"
                type="number"
                min="1"
                max="12"
                required
                value={cardData.installments}
                onChange={(e) => setCardData({ ...cardData, installments: Number.parseInt(e.target.value) })}
              />
            </div>
          </div>
        </div>
      )}

      {paymentMethod === "pix" && (
        <div className="space-y-4 border-t pt-6">
          <div className="space-y-2">
            <Label htmlFor="pix_document">CPF/CNPJ *</Label>
            <Input
              id="pix_document"
              required
              value={pixData.document_number}
              onChange={(e) => setPixData({ ...pixData, document_number: e.target.value })}
              placeholder="000.000.000-00"
            />
          </div>
          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm text-muted-foreground">
              Após confirmar, você receberá um QR Code para realizar o pagamento via PIX.
            </p>
          </div>
        </div>
      )}

      {paymentMethod === "boleto" && (
        <div className="space-y-4 border-t pt-6">
          <div className="space-y-2">
            <Label htmlFor="boleto_document">CPF/CNPJ *</Label>
            <Input
              id="boleto_document"
              required
              value={boletoData.document_number}
              onChange={(e) => setBoletoData({ ...boletoData, document_number: e.target.value })}
              placeholder="000.000.000-00"
            />
          </div>
          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm text-muted-foreground">
              O boleto será gerado após a confirmação e poderá ser pago em qualquer banco.
            </p>
          </div>
        </div>
      )}

      <div className="flex justify-between">
        <Button type="button" variant="outline" onClick={onBack}>
          Voltar
        </Button>
        <Button type="submit" size="lg" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Finalizar Pagamento
        </Button>
      </div>
    </form>
  )
}
