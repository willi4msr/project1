"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

type CustomerStepProps = {
  onNext: () => void
  updateData: (data: any) => void
  initialData?: any
}

export function CustomerStep({ onNext, updateData, initialData }: CustomerStepProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    firstname: initialData?.firstname || "",
    lastname: initialData?.lastname || "",
    email: initialData?.email || "",
    telephone: initialData?.telephone || "",
    postcode: initialData?.postcode || "",
    address_street: initialData?.address_street || "",
    address_street_number: initialData?.address_street_number || "",
    address_street_complement: initialData?.address_street_complement || "",
    address_street_district: initialData?.address_street_district || "",
    address_city: initialData?.address_city || "",
    address_state: initialData?.address_state || "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/checkout/customer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao criar cliente")
      }

      updateData({
        customerId: data.customer_id,
        customer: formData,
      })

      toast({
        title: "Dados salvos!",
        description: "Seus dados foram salvos com sucesso.",
      })

      onNext()
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Dados Pessoais</h2>
        <p className="text-sm text-muted-foreground">Preencha seus dados para continuar com a compra</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstname">Nome *</Label>
          <Input
            id="firstname"
            required
            value={formData.firstname}
            onChange={(e) => setFormData({ ...formData, firstname: e.target.value })}
            placeholder="João"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastname">Sobrenome *</Label>
          <Input
            id="lastname"
            required
            value={formData.lastname}
            onChange={(e) => setFormData({ ...formData, lastname: e.target.value })}
            placeholder="Silva"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email">E-mail *</Label>
          <Input
            id="email"
            type="email"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="joao@exemplo.com"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="telephone">Telefone *</Label>
          <Input
            id="telephone"
            required
            value={formData.telephone}
            onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
            placeholder="(11) 99999-9999"
          />
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold mb-4">Endereço de Entrega</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="postcode">CEP *</Label>
            <Input
              id="postcode"
              required
              value={formData.postcode}
              onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
              placeholder="01010-000"
              maxLength={9}
            />
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="address_street">Rua *</Label>
              <Input
                id="address_street"
                required
                value={formData.address_street}
                onChange={(e) => setFormData({ ...formData, address_street: e.target.value })}
                placeholder="Rua São Bento"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address_street_number">Número *</Label>
              <Input
                id="address_street_number"
                required
                value={formData.address_street_number}
                onChange={(e) => setFormData({ ...formData, address_street_number: e.target.value })}
                placeholder="123"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address_street_complement">Complemento</Label>
            <Input
              id="address_street_complement"
              value={formData.address_street_complement}
              onChange={(e) => setFormData({ ...formData, address_street_complement: e.target.value })}
              placeholder="Apto 45"
            />
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="address_street_district">Bairro *</Label>
              <Input
                id="address_street_district"
                required
                value={formData.address_street_district}
                onChange={(e) => setFormData({ ...formData, address_street_district: e.target.value })}
                placeholder="Centro"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address_city">Cidade *</Label>
              <Input
                id="address_city"
                required
                value={formData.address_city}
                onChange={(e) => setFormData({ ...formData, address_city: e.target.value })}
                placeholder="São Paulo"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address_state">Estado *</Label>
              <Input
                id="address_state"
                required
                value={formData.address_state}
                onChange={(e) => setFormData({ ...formData, address_state: e.target.value })}
                placeholder="SP"
                maxLength={2}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" size="lg" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Continuar para o Carrinho
        </Button>
      </div>
    </form>
  )
}
