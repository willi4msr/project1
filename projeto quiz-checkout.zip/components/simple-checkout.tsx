"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/hooks/use-toast"
import { CreditCard, QrCode, Barcode, Loader2, CheckCircle2, ShieldCheck, Copy, Check } from "lucide-react"
import Image from "next/image"

const PRODUCT = {
  name: "Protocolo 30 Dias — Inova Mulher",
  price: 18.9,
  sku: "PROTOCOLO-30D",
  description: "Transforme sua vida em 30 dias com o método exclusivo Inova Mulher",
}

export default function SimpleCheckout() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [orderId, setOrderId] = useState<number>()
  const [paymentMethod, setPaymentMethod] = useState<"creditcard" | "pix" | "boleto">("creditcard")
  const [pixData, setPixData] = useState<{ pix_qrcode: string; pix_emv: string } | null>(null)
  const [copied, setCopied] = useState(false)
  const [checkingPayment, setCheckingPayment] = useState(false)

  // Dados do cliente
  const [customerData, setCustomerData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    telephone: "",
    document_number: "",
  })

  // Dados do cartão
  const [cardData, setCardData] = useState({
    number: "",
    name: "",
    cvv: "",
    month: "",
    year: "",
    installments: 1,
  })

  const copyPixCode = () => {
    if (pixData?.pix_emv) {
      navigator.clipboard.writeText(pixData.pix_emv)
      setCopied(true)
      toast({
        title: "Código copiado!",
        description: "Cole no seu app de pagamentos para finalizar.",
      })
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    console.log("[v0] Iniciando checkout com método:", paymentMethod)
    console.log("[v0] Dados do cliente:", { ...customerData, document_number: "***" })

    try {
      // 1. Criar cliente (sem endereço para produto digital)
      console.log("[v0] Criando cliente...")
      const customerResponse = await fetch("/api/checkout/customer-simple", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customerData),
      })

      const customerResult = await customerResponse.json()
      console.log("[v0] Resposta do cliente:", customerResponse.ok ? "Sucesso" : "Erro", customerResult)

      if (!customerResponse.ok) {
        throw new Error(customerResult.error || "Erro ao criar cliente. Verifique suas credenciais da API.")
      }

      if (!customerResult.success) {
        throw new Error(customerResult.text || customerResult.message || "Erro ao criar cliente")
      }

      const customerId = customerResult.data?.id

      if (!customerId) {
        throw new Error("ID do cliente não foi retornado pela API")
      }

      // 2. Criar pedido
      console.log("[v0] Criando pedido para cliente:", customerId)
      const orderResponse = await fetch("/api/checkout/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_id: customerId,
          products: [
            {
              sku: PRODUCT.sku,
              name: PRODUCT.name,
              qty: 1,
              price: PRODUCT.price,
            },
          ],
          total: PRODUCT.price,
          shipping: 0,
          discount: 0,
        }),
      })

      const orderResult = await orderResponse.json()
      console.log("[v0] Resposta do pedido:", orderResponse.ok ? "Sucesso" : "Erro", orderResult)

      if (!orderResponse.ok) {
        throw new Error(orderResult.error || "Erro ao criar pedido")
      }

      if (!orderResult.success) {
        throw new Error(orderResult.text || orderResult.message || "Erro ao criar pedido")
      }

      const orderId = orderResult.data?.id

      if (!orderId) {
        throw new Error("ID do pedido não foi retornado pela API")
      }

      setOrderId(orderId)
      console.log("[v0] Pedido criado com ID:", orderId)

      // 3. Processar pagamento
      console.log("[v0] Processando pagamento via:", paymentMethod)
      let paymentEndpoint = ""
      const paymentBody: any = {
        cart: { order_id: orderId },
        customer: { customer_id: customerId },
      }

      if (paymentMethod === "creditcard") {
        paymentEndpoint = "/api/checkout/payment/creditcard"
        paymentBody.payment = {
          creditcard: {
            number: cardData.number.replace(/\s/g, ""),
            name: cardData.name,
            cvv: cardData.cvv,
            month: Number.parseInt(cardData.month),
            year: Number.parseInt(cardData.year),
            installments: cardData.installments,
            document_number: customerData.document_number.replace(/\D/g, ""),
          },
        }
      } else if (paymentMethod === "pix") {
        paymentEndpoint = "/api/checkout/payment/pix"
        paymentBody.payment = {
          pix: {
            document_number: customerData.document_number.replace(/\D/g, ""),
          },
        }
      } else if (paymentMethod === "boleto") {
        paymentEndpoint = "/api/checkout/payment/boleto"
        paymentBody.payment = {
          boleto: {
            document_number: customerData.document_number.replace(/\D/g, ""),
          },
        }
      }

      const paymentResponse = await fetch(paymentEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentBody),
      })

      const paymentResult = await paymentResponse.json()
      console.log("[v0] Resposta do pagamento:", paymentResponse.ok ? "Sucesso" : "Erro", paymentResult)

      if (!paymentResponse.ok) {
        throw new Error(paymentResult.error || "Erro ao processar pagamento")
      }

      if (!paymentResult.success) {
        throw new Error(paymentResult.text || paymentResult.message || "Erro ao processar pagamento")
      }

      console.log("[v0] Checkout concluído com sucesso!")

      if (paymentMethod === "pix" && paymentResult.data) {
        console.log("[v0] Dados PIX recebidos:", paymentResult.data)
        setPixData({
          pix_qrcode: paymentResult.data.pix_qrcode,
          pix_emv: paymentResult.data.pix_emv,
        })
      } else {
        setSuccess(true)
      }
    } catch (error: any) {
      console.error("[v0] Erro no checkout:", error)
      toast({
        title: "Erro no pagamento",
        description: error.message || "Ocorreu um erro ao processar seu pagamento. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const checkPaymentStatus = async (orderId: number) => {
    try {
      const response = await fetch("/api/checkout/order-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order_id: orderId }),
      })

      const result = await response.json()

      if (result.success && result.data) {
        console.log("[v0] Status do pagamento:", result.data.status)

        // Se o pagamento foi aprovado, redireciona
        if (result.data.status === "aprovado" || result.data.status === "paid" || result.data.status === "approved") {
          console.log("[v0] Pagamento aprovado! Redirecionando...")

          // Obter URL de redirecionamento (pode vir de variável de ambiente)
          const redirectUrl = process.env.NEXT_PUBLIC_REDIRECT_URL

          if (redirectUrl) {
            window.location.href = redirectUrl
          } else {
            // Se não houver URL configurada, mostra tela de sucesso
            setPixData(null)
            setSuccess(true)
          }

          return true
        }
      }

      return false
    } catch (error) {
      console.error("[v0] Erro ao verificar status:", error)
      return false
    }
  }

  useEffect(() => {
    if (pixData && orderId) {
      setCheckingPayment(true)

      // Verificar a cada 3 segundos
      const interval = setInterval(async () => {
        const isPaid = await checkPaymentStatus(orderId)
        if (isPaid) {
          clearInterval(interval)
          setCheckingPayment(false)
        }
      }, 3000)

      // Limpar após 10 minutos (timeout)
      const timeout = setTimeout(() => {
        clearInterval(interval)
        setCheckingPayment(false)
        console.log("[v0] Timeout de verificação de pagamento atingido")
      }, 600000) // 10 minutos

      return () => {
        clearInterval(interval)
        clearTimeout(timeout)
      }
    }
  }, [pixData, orderId])

  if (pixData) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <Card className="p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="flex justify-center">
              <div className="rounded-full bg-blue-100 p-4">
                <QrCode className="h-12 w-12 text-blue-600" />
              </div>
            </div>
            <h2 className="text-3xl font-bold">Pague com PIX</h2>
            <p className="text-muted-foreground">Escaneie o QR Code ou copie o código para pagar</p>
            {checkingPayment && (
              <div className="flex items-center justify-center gap-2 text-sm text-blue-600">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Aguardando confirmação do pagamento...</span>
              </div>
            )}
          </div>

          <div className="flex justify-center bg-white p-6 rounded-lg">
            <Image
              src={`data:image/png;base64,${pixData.pix_qrcode}`}
              alt="QR Code PIX"
              width={300}
              height={300}
              className="rounded-lg"
            />
          </div>

          <div className="space-y-3">
            <Label>Código PIX (Copia e Cola)</Label>
            <div className="flex gap-2">
              <Input value={pixData.pix_emv} readOnly className="font-mono text-xs" />
              <Button onClick={copyPixCode} variant="outline" size="icon">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <p className="text-sm font-medium">Como pagar:</p>
            <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
              <li>Abra o app do seu banco</li>
              <li>Escolha pagar com PIX</li>
              <li>Escaneie o QR Code ou cole o código</li>
              <li>Confirme o pagamento de R$ {PRODUCT.price.toFixed(2)}</li>
            </ol>
          </div>

          <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
            <p className="text-sm text-blue-900">
              Após o pagamento, você será redirecionado automaticamente. O sistema verifica o pagamento a cada 3
              segundos.
            </p>
          </div>

          <Button onClick={() => setPixData(null)} variant="outline" className="w-full">
            Voltar
          </Button>
        </Card>
      </div>
    )
  }

  if (success) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <Card className="p-8 text-center space-y-6">
          <div className="flex justify-center">
            <div className="rounded-full bg-green-100 p-6">
              <CheckCircle2 className="h-16 w-16 text-green-600" />
            </div>
          </div>

          <div className="space-y-2">
            <h2 className="text-3xl font-bold">Compra Confirmada!</h2>
            <p className="text-muted-foreground">
              Você receberá um e-mail com as instruções de acesso ao {PRODUCT.name}
            </p>
          </div>

          <div className="bg-muted p-6 rounded-lg space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Pedido:</span>
              <span className="font-mono font-semibold">#{orderId}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Produto:</span>
              <span className="font-medium">{PRODUCT.name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Valor:</span>
              <span className="font-bold">R$ {PRODUCT.price.toFixed(2)}</span>
            </div>
          </div>

          <Button onClick={() => (window.location.href = "/")} size="lg">
            Voltar ao Início
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 text-balance">{PRODUCT.name}</h1>
          <p className="text-muted-foreground">{PRODUCT.description}</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Formulário */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Dados Pessoais */}
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold">Seus Dados</h3>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstname">Nome *</Label>
                      <Input
                        id="firstname"
                        required
                        value={customerData.firstname}
                        onChange={(e) => setCustomerData({ ...customerData, firstname: e.target.value })}
                        placeholder="Maria"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastname">Sobrenome *</Label>
                      <Input
                        id="lastname"
                        required
                        value={customerData.lastname}
                        onChange={(e) => setCustomerData({ ...customerData, lastname: e.target.value })}
                        placeholder="Silva"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail *</Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      value={customerData.email}
                      onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
                      placeholder="maria@exemplo.com"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="telephone">Telefone *</Label>
                      <Input
                        id="telephone"
                        required
                        value={customerData.telephone}
                        onChange={(e) => setCustomerData({ ...customerData, telephone: e.target.value })}
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="document">CPF *</Label>
                      <Input
                        id="document"
                        required
                        value={customerData.document_number}
                        onChange={(e) => setCustomerData({ ...customerData, document_number: e.target.value })}
                        placeholder="000.000.000-00"
                        maxLength={14}
                      />
                    </div>
                  </div>
                </div>

                {/* Forma de Pagamento */}
                <div className="space-y-4 border-t pt-6">
                  <h3 className="text-xl font-semibold">Forma de Pagamento</h3>

                  <RadioGroup value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
                        <RadioGroupItem value="creditcard" id="creditcard" />
                        <Label htmlFor="creditcard" className="flex items-center cursor-pointer flex-1">
                          <CreditCard className="mr-2 h-5 w-5" />
                          <span className="font-medium">Cartão de Crédito</span>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
                        <RadioGroupItem value="pix" id="pix" />
                        <Label htmlFor="pix" className="flex items-center cursor-pointer flex-1">
                          <QrCode className="mr-2 h-5 w-5" />
                          <span className="font-medium">PIX - Aprovação Imediata</span>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-accent">
                        <RadioGroupItem value="boleto" id="boleto" />
                        <Label htmlFor="boleto" className="flex items-center cursor-pointer flex-1">
                          <Barcode className="mr-2 h-5 w-5" />
                          <span className="font-medium">Boleto Bancário</span>
                        </Label>
                      </div>
                    </div>
                  </RadioGroup>

                  {/* Dados do Cartão */}
                  {paymentMethod === "creditcard" && (
                    <div className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="card_number">Número do Cartão *</Label>
                        <Input
                          id="card_number"
                          required
                          value={cardData.number}
                          onChange={(e) => setCardData({ ...cardData, number: e.target.value })}
                          placeholder="1234 5678 9012 3456"
                          maxLength={19}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="card_name">Nome no Cartão *</Label>
                        <Input
                          id="card_name"
                          required
                          value={cardData.name}
                          onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
                          placeholder="MARIA SILVA"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="card_month">Mês *</Label>
                          <Input
                            id="card_month"
                            required
                            value={cardData.month}
                            onChange={(e) => setCardData({ ...cardData, month: e.target.value })}
                            placeholder="12"
                            maxLength={2}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="card_year">Ano *</Label>
                          <Input
                            id="card_year"
                            required
                            value={cardData.year}
                            onChange={(e) => setCardData({ ...cardData, year: e.target.value })}
                            placeholder="25"
                            maxLength={2}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="card_cvv">CVV *</Label>
                          <Input
                            id="card_cvv"
                            required
                            value={cardData.cvv}
                            onChange={(e) => setCardData({ ...cardData, cvv: e.target.value })}
                            placeholder="123"
                            maxLength={4}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="installments">Parcelas *</Label>
                        <select
                          id="installments"
                          required
                          value={cardData.installments}
                          onChange={(e) => setCardData({ ...cardData, installments: Number.parseInt(e.target.value) })}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value={1}>1x de R$ {PRODUCT.price.toFixed(2)} sem juros</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {paymentMethod === "pix" && (
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        Após confirmar, você receberá um QR Code para pagamento instantâneo via PIX.
                      </p>
                    </div>
                  )}

                  {paymentMethod === "boleto" && (
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        O boleto será gerado após a confirmação. Pagamento em até 3 dias úteis.
                      </p>
                    </div>
                  )}
                </div>

                <Button type="submit" size="lg" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Finalizar Compra - R$ {PRODUCT.price.toFixed(2)}
                </Button>
              </form>
            </Card>
          </div>

          {/* Resumo */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-8 space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Resumo da Compra</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Produto</span>
                    <span className="font-medium text-right">{PRODUCT.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Quantidade</span>
                    <span className="font-medium">1</span>
                  </div>
                  <div className="border-t pt-3 flex justify-between">
                    <span className="font-semibold">Total</span>
                    <span className="text-2xl font-bold">R$ {PRODUCT.price.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6 space-y-3">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Compra 100% Segura</p>
                    <p className="text-xs text-muted-foreground">Seus dados estão protegidos</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Acesso Imediato</p>
                    <p className="text-xs text-muted-foreground">Receba por e-mail após o pagamento</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
