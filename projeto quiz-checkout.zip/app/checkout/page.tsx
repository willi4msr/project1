import CheckoutFlow from "@/components/checkout-flow"

export default function CheckoutPage() {
  return (
    <main className="min-h-screen bg-background">
      <CheckoutFlow />
    </main>
  )
}
