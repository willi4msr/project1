"use client"
import { useSearchParams } from "next/navigation"

function generateEventId(orderId: string): string {
  return `purchase_${orderId}_${Date.now()}`
}

function getFacebookCookies() {
  if (typeof document === "undefined") return { fbp: null, fbc: null }

  const fbp =
    document.cookie
      .split("; ")
      .find((row) => row.startsWith("_fbp="))
      ?.split("=")[1] || null
  const fbc =
    document.cookie
      .split("; ")
      .find((row) => row.startsWith("_fbc="))
      ?.split("=")[1] || null

  return { fbp, fbc }
}

export default function ThankYouPage() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("order_id")
  const value = searchParams.get("value")
  const source = searchParams.get("source")

  const isOldQuiz = source === "old-quiz"

  // Removed all Facebook tracking - it's now handled in the quiz polling

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 py-8 bg-gradient-to-b from-green-50 to-white">
      <div className="w-full max-w-md text-center">
        <div className="mb-8 flex justify-center">
          <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center">
            <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-4">Pagamento Confirmado!</h1>

        <p className="text-lg text-gray-700 mb-8">
          {isOldQuiz
            ? "Obrigado pela sua compra! Seu pedido foi confirmado, fique atento ao seu email."
            : "Obrigado pela sua compra! Seu treino personalizado foi confirmado e você receberá as instruções em breve."}
        </p>

        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="text-sm text-gray-600 mb-2">Número do Pedido</div>
          <div className="font-mono text-gray-900 font-bold mb-4">{orderId || "N/A"}</div>

          {!isOldQuiz && (
            <>
              <div className="text-sm text-gray-600 mb-2">Valor Pago</div>
              <div className="text-2xl font-bold text-green-600">R$ {value || "6,00"}</div>
            </>
          )}
        </div>

        <div className="bg-green-50 border border-green-200 rounded-xl p-6">
          <p className="text-sm text-gray-700 leading-relaxed">
            <strong>Próximos passos:</strong>
            <br />
            {isOldQuiz
              ? "Você receberá um e-mail com todas as informações sobre seu pedido. Fique atento à sua caixa de entrada!"
              : "Você receberá um e-mail com todas as informações sobre seu treino personalizado. Fique atento à sua caixa de entrada!"}
          </p>
        </div>
      </div>
    </div>
  )
}
