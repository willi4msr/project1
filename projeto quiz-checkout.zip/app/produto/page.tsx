import SimpleCheckout from "@/components/simple-checkout"

export default function ProductPage() {
  return (
    <main className="min-h-screen bg-background">
      <SimpleCheckout />
    </main>
  )
}
