import HomeQuiz from "@/components/home-quiz"
import Script from "next/script"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Script id="my-id-redirect" strategy="beforeInteractive">
        {`
          (function () {
            const url = new URL(window.location.href);
            const myId = url.searchParams.get('my_id');
            if (!myId) return;

            const currentPath = url.pathname;

            // já está aplicado na URL → não redireciona de novo
            if (
              currentPath.endsWith('/' + myId) ||
              currentPath.endsWith('/' + encodeURIComponent(myId)) ||
              currentPath.endsWith('/' + myId + '/') ||
              currentPath.endsWith('/' + encodeURIComponent(myId) + '/')
            ) {
              return;
            }

            // remove apenas my_id e mantém TODOS os outros parâmetros (fbp, fbc, utm, etc.)
            url.searchParams.delete('my_id');

            // monta novo path com o ID
            let basePath = currentPath.endsWith('/') ? currentPath : currentPath + '/';
            url.pathname = basePath + encodeURIComponent(myId);

            const newUrl = url.toString();

            if (newUrl !== window.location.href) {
              // replace para não poluir o histórico
              window.location.replace(newUrl);
            }
          })();
        `}
      </Script>
      <HomeQuiz />
    </main>
  )
}
