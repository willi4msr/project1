import { type NextRequest, NextResponse } from "next/server"
import { sendMetaCAPI } from "@/lib/meta-capi-service"
import { isPurchaseSent, markPurchaseAsSent } from "@/lib/tracking-store-v2"

export async function POST(request: NextRequest) {
  console.log("[TRACK-PURCHASE] Received Purchase event request")

  try {
    const body = await request.json()

    const orderId = body.orderId || body.custom_data?.order_id
    const email = body.email || body.user_data?.em
    const phone = body.phone || body.user_data?.ph
    const name = body.name
    const fbp = body.fbp || body.user_data?.fbp
    const fbc = body.fbc || body.user_data?.fbc
    const value = body.value || body.custom_data?.value || 0
    const eventSourceUrl = body.eventSourceUrl || body.event_source_url || "https://protocolo30dias.com"
    const userAgent =
      body.userAgent || body.user_data?.client_user_agent || request.headers.get("user-agent") || "Unknown"
    const eventId = body.event_id || `purchase_${orderId}`

    console.log("[TRACK-PURCHASE] Parsed data:", { orderId, email: !!email, phone: !!phone, value, eventId })

    // Validações
    if (!orderId) {
      console.error("[TRACK-PURCHASE] Missing orderId in body:", body)
      return NextResponse.json({ error: "Missing orderId" }, { status: 400 })
    }

    if (!email || !phone) {
      console.error("[TRACK-PURCHASE] Missing email or phone:", { email: !!email, phone: !!phone })
      return NextResponse.json({ error: "Missing email or phone" }, { status: 400 })
    }

    // PROTEÇÃO CONTRA DUPLICAÇÃO
    if (isPurchaseSent(orderId)) {
      console.log(`[TRACK-PURCHASE] ⚠️ Purchase already sent for order: ${orderId}, aborting...`)
      return NextResponse.json({
        success: true,
        message: "Purchase already processed",
        duplicate: true,
      })
    }

    // Marca como enviado ANTES de enviar (proteção contra race conditions)
    markPurchaseAsSent(orderId)

    // Envia para Meta CAPI
    await sendMetaCAPI({
      eventName: "Purchase",
      eventId,
      eventSourceUrl,
      userAgent,
      userData: {
        email,
        phone,
        name,
        fbp,
        fbc,
        clientIp: request.headers.get("x-forwarded-for")?.split(",")[0] || request.ip,
      },
      customData: {
        value: Number(value) || 0,
        currency: "BRL",
        content_ids: ["protocolo-30-dias"],
        content_name: "Protocolo 30 Dias — Inova Mulher",
        content_type: "product",
        contents: [
          {
            id: "protocolo-30-dias",
            quantity: 1,
            item_price: Number(value) || 0,
          },
        ],
      },
    })

    console.log(`[TRACK-PURCHASE] ✅ Purchase sent successfully for order: ${orderId}`)

    return NextResponse.json({
      success: true,
      message: "Purchase event sent",
      eventId,
    })
  } catch (error) {
    console.error("[TRACK-PURCHASE] Error:", error)
    return NextResponse.json(
      {
        error: "Failed to send Purchase event",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
