import { type NextRequest, NextResponse } from "next/server"
import { sendMetaEvent, hashUserData } from "@/lib/tracking-service"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { event_id, user_data, custom_data, event_source_url } = body

    console.log("[TRACK LEAD] Received:", {
      event_id,
      has_user_data: !!user_data,
      has_custom_data: !!custom_data,
    })

    let hashedEmail: string | undefined
    let hashedPhone: string | undefined

    if (user_data?.email && user_data?.phone) {
      const hashed = hashUserData(user_data.email, user_data.phone)
      hashedEmail = hashed.em
      hashedPhone = hashed.ph
    }

    // Send to Meta CAPI
    await sendMetaEvent({
      eventName: "Lead",
      eventId: event_id || `lead_${Date.now()}`,
      eventSourceUrl: event_source_url || "https://protocolo30dias.com",
      userData: {
        em: hashedEmail,
        ph: hashedPhone,
        fbp: user_data?.fbp,
        fbc: user_data?.fbc,
        client_user_agent: user_data?.client_user_agent || request.headers.get("user-agent") || undefined,
        client_ip_address: request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || undefined,
      },
      customData: custom_data,
    })

    return NextResponse.json({
      success: true,
      eventId: event_id,
    })
  } catch (error) {
    console.error("[TRACK LEAD] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
