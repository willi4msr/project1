import { type NextRequest, NextResponse } from "next/server"
import { isOrderPaid } from "@/lib/payment-status-store"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const orderId = searchParams.get("order_id")

    if (!orderId) {
      return NextResponse.json({ error: "Missing order_id" }, { status: 400 })
    }

    const isPaid = isOrderPaid(orderId)

    console.log(`[ORDER-STATUS] Checking order ${orderId}: ${isPaid ? "PAID" : "PENDING"}`)

    return NextResponse.json({
      orderId,
      isPaid,
      status: isPaid ? "paid" : "pending",
    })
  } catch (error) {
    console.error("[ORDER-STATUS] Error:", error)
    return NextResponse.json({ error: "Failed to check order status" }, { status: 500 })
  }
}
