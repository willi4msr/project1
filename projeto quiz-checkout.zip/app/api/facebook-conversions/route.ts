import { type NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

// Hash function for PII data (required by Facebook)
function hashData(data: string): string {
  return crypto.createHash("sha256").update(data.toLowerCase().trim()).digest("hex")
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      eventName,
      eventSourceUrl,
      eventId,
      orderId,
      email,
      phone,
      firstName,
      lastName,
      gender,
      dateOfBirth,
      city,
      state,
      country = "BR",
      zipCode,
      value,
      currency = "BRL",
      contentName,
      contentIds,
      contentCategory,
      numItems,
      fbp,
      fbc,
      fbclid,
      clientIpAddress: providedIp,
      clientUserAgent: providedUa,
    } = body

    const pixelId = process.env.FACEBOOK_PIXEL_ID
    const accessToken = process.env.FACEBOOK_CONVERSION_API_TOKEN
    const testEventCode = process.env.FACEBOOK_TEST_EVENT_CODE

    if (!pixelId || !accessToken) {
      return NextResponse.json({ error: "Facebook Pixel ID or Access Token not configured" }, { status: 500 })
    }

    const clientIpAddress =
      providedIp ||
      request.headers.get("x-forwarded-for")?.split(",")[0] ||
      request.headers.get("x-real-ip") ||
      "unknown"
    const clientUserAgent = providedUa || request.headers.get("user-agent") || "unknown"

    const userData: any = {
      client_ip_address: clientIpAddress,
      client_user_agent: clientUserAgent,
    }

    if (firstName) userData.fn = hashData(firstName)
    if (lastName) userData.ln = hashData(lastName)
    if (gender) userData.ge = hashData(gender) // 'm' or 'f'
    if (dateOfBirth) userData.db = hashData(dateOfBirth) // YYYYMMDD format
    if (city) userData.ct = hashData(city)
    if (state) userData.st = hashData(state)
    if (country) userData.country = hashData(country)
    if (zipCode) userData.zp = hashData(zipCode)

    if (email) userData.em = hashData(email)
    if (phone) userData.ph = hashData(phone.replace(/\D/g, ""))

    if (fbp) {
      userData.fbp = fbp
      console.log("[v0] Using _fbp for matching:", fbp)
    }
    if (fbc) {
      userData.fbc = fbc
      console.log("[v0] Using _fbc for matching:", fbc)
    }

    if (orderId) {
      userData.external_id = String(orderId)
      console.log("[v0] Using external_id (order_id) for matching:", orderId)
    }

    console.log("[v0] Facebook Conversions API event:", {
      eventName,
      orderId,
      hasFbp: !!fbp,
      hasFbc: !!fbc,
      hasFbclid: !!fbclid,
      hasFirstName: !!firstName,
      hasLastName: !!lastName,
      hasGender: !!gender,
      hasDateOfBirth: !!dateOfBirth,
      hasCity: !!city,
      hasState: !!state,
      hasZipCode: !!zipCode,
      hasCountry: !!country,
      hasExternalId: !!orderId,
      clientIp: clientIpAddress !== "unknown",
      userAgent: clientUserAgent !== "unknown",
    })

    // Build custom data
    const customData: any = {
      currency,
    }
    if (value) customData.value = value
    if (contentName) customData.content_name = contentName
    if (contentIds) customData.content_ids = contentIds
    if (contentCategory) customData.content_category = contentCategory
    if (numItems) customData.num_items = numItems
    if (orderId) customData.order_id = orderId

    const eventData = {
      data: [
        {
          event_name: eventName,
          event_time: Math.floor(Date.now() / 1000),
          event_id: eventId,
          action_source: "website",
          event_source_url: eventSourceUrl,
          user_data: userData,
          custom_data: customData,
          opt_out: false, // Ensure event is used for optimization
        },
      ],
      ...(testEventCode && { test_event_code: testEventCode }),
    }

    console.log("[v0] Sending to Facebook with matching params:", {
      has_fbp: !!userData.fbp,
      has_fbc: !!userData.fbc,
      has_external_id: !!userData.external_id,
      has_firstName: !!userData.fn,
      has_lastName: !!userData.ln,
      has_gender: !!userData.ge,
      has_dateOfBirth: !!userData.db,
      has_city: !!userData.ct,
      has_state: !!userData.st,
      has_zipCode: !!userData.zp,
      has_country: !!userData.country,
      has_ip: userData.client_ip_address !== "unknown",
      has_ua: userData.client_user_agent !== "unknown",
    })

    // Send to Facebook Conversions API
    const response = await fetch(`https://graph.facebook.com/v18.0/${pixelId}/events?access_token=${accessToken}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(eventData),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error("[v0] Facebook Conversions API Error:", result)
      return NextResponse.json(
        { error: "Failed to send event to Facebook", details: result },
        { status: response.status },
      )
    }

    console.log("[v0] Facebook Conversions API Success:", {
      eventName,
      orderId,
      eventsReceived: result.events_received,
      fbtrace_id: result.fbtrace_id,
    })

    return NextResponse.json({ success: true, result })
  } catch (error) {
    console.error("[v0] Facebook Conversions API Error:", error)
    return NextResponse.json({ error: "Internal server error", details: error }, { status: 500 })
  }
}
