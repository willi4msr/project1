import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const pixelId = process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID
    const accessToken = process.env.FACEBOOK_CONVERSION_API_TOKEN

    if (!pixelId || !accessToken) {
      console.error("[CAPI] Missing FACEBOOK_PIXEL_ID or FACEBOOK_CONVERSION_API_TOKEN")
      return NextResponse.json({ error: "Missing Facebook credentials" }, { status: 500 })
    }

    const userData = body.user_data || {}

    // Get client IP from request headers
    const clientIp =
      request.headers.get("x-forwarded-for")?.split(",")[0] || request.headers.get("x-real-ip") || request.ip || ""

    if (clientIp) userData.client_ip_address = clientIp

    const eventPayload: any = {
      event_name: body.eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_source_url: body.eventSourceUrl,
      action_source: "website",
      user_data: userData,
    }

    if (body.eventId) eventPayload.event_id = body.eventId

    if (body.customData) {
      // Clone custom_data to avoid mutating the original
      const customData = { ...body.customData }

      if (body.eventName === "Purchase") {
        // Ensure value is numeric
        if (customData.value !== undefined) {
          customData.value = Number(customData.value)
        }
        // Always set currency for Purchase events
        customData.currency = "BRL"

        // Ensure contents array exists with proper structure
        if (!customData.contents || !Array.isArray(customData.contents)) {
          customData.contents = [
            {
              id: customData.content_ids?.[0] || "protocolo-30-dias",
              quantity: 1,
              item_price: customData.value,
            },
          ]
        }

        // Set content_type if not present
        if (!customData.content_type) {
          customData.content_type = "product"
        }

        console.log("[CAPI] Purchase event payload before sending:")
        console.log(
          JSON.stringify(
            {
              event_name: body.eventName,
              event_id: body.eventId,
              custom_data: {
                value: customData.value,
                currency: customData.currency,
                contents: customData.contents,
                content_type: customData.content_type,
              },
            },
            null,
            2,
          ),
        )
      }

      eventPayload.custom_data = customData
    }

    console.log("[CAPI] Sending event to Facebook:", body.eventName)
    console.log("[CAPI] user_data keys:", Object.keys(userData))
    console.log("[CAPI] user_data structure:", {
      em: userData.em ? "present (hashed)" : "missing",
      ph: userData.ph ? "present (hashed)" : "missing",
      fn: userData.fn ? "present (hashed)" : "missing",
      ln: userData.ln ? "present (hashed)" : "missing",
      country: userData.country ? "present (hashed)" : "missing",
      fbp: userData.fbp ? "present (unhashed)" : "missing",
      fbc: userData.fbc ? "present (unhashed)" : "missing",
    })

    const response = await fetch(`https://graph.facebook.com/v21.0/${pixelId}/events`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        data: [eventPayload],
        access_token: accessToken,
        test_event_code: process.env.FACEBOOK_TEST_EVENT_CODE || undefined,
      }),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error("[CAPI] Facebook API rejected event:", body.eventName)
      console.error("[CAPI] HTTP Status:", response.status)
      if (body.eventName === "Purchase") {
        console.error("[CAPI] Purchase event failed with payload:", JSON.stringify(eventPayload, null, 2))
      }
      console.error("[CAPI] Full error response:", JSON.stringify(result, null, 2))

      if (result.error) {
        console.error("[CAPI] Error message:", result.error.message)
        console.error("[CAPI] Error type:", result.error.type)
        console.error("[CAPI] Error code:", result.error.code)
        if (result.error.error_subcode) {
          console.error("[CAPI] Error subcode:", result.error.error_subcode)
        }
        if (result.error.error_user_msg) {
          console.error("[CAPI] User-facing error:", result.error.error_user_msg)
        }
      }

      return NextResponse.json({ error: "Facebook API error", details: result }, { status: response.status })
    }

    console.log(`[CAPI] Event ${body.eventName} sent successfully`)
    return NextResponse.json({ success: true, result })
  } catch (error) {
    console.error("[CAPI] Error:", error)
    return NextResponse.json({ error: "Internal server error", details: String(error) }, { status: 500 })
  }
}
