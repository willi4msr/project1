import { type NextRequest, NextResponse } from "next/server"

function normalizeAppmaxUrl(url: string): string {
  if (!url) return ""

  // Remove trailing slash
  url = url.replace(/\/$/, "")

  // If URL doesn't contain /api/v3, add it
  if (!url.includes("/api/v3")) {
    url = `${url}/api/v3`
  }

  return url
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { order_id } = body

    if (!order_id) {
      return NextResponse.json({ success: false, error: "order_id is required" }, { status: 400 })
    }

    const appmaxUrl = normalizeAppmaxUrl(process.env.APPMAX_API_URL || "")
    const appmaxToken = process.env.APPMAX_ACCESS_TOKEN

    if (!appmaxUrl || !appmaxToken) {
      return NextResponse.json({ success: false, error: "Missing Appmax configuration" }, { status: 500 })
    }

    const response = await fetch(`${appmaxUrl}/order/${order_id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${appmaxToken}`,
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
        Referer: "https://appmax.com.br/",
        Origin: "https://appmax.com.br",
      },
    })

    const contentType = response.headers.get("content-type")
    if (contentType?.includes("text/html")) {
      console.error("[v0] Cloudflare challenge detected - status:", response.status)
      return NextResponse.json(
        {
          success: false,
          error: "Cloudflare protection blocking request",
          status: "pending", // Assume pending if we can't check
        },
        { status: 200 }, // Return 200 to prevent error on client
      )
    }

    const data = await response.json()

    return NextResponse.json({
      success: true,
      data: data,
    })
  } catch (error) {
    console.error("[v0] Error checking order status:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        status: "pending", // Assume pending on error
      },
      { status: 200 }, // Return 200 to prevent error on client
    )
  }
}
