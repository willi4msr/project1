import { type NextRequest, NextResponse } from "next/server"

const APPMAX_API_URL = process.env.APPMAX_API_URL || "https://homolog.sandboxappmax.com.br"
const APPMAX_ACCESS_TOKEN = process.env.APPMAX_ACCESS_TOKEN || ""

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const customerData = {
      "access-token": APPMAX_ACCESS_TOKEN,
      firstname: body.firstname,
      lastname: body.lastname,
      email: body.email,
      telephone: body.telephone,
      ip: request.headers.get("x-forwarded-for") || "127.0.0.1",
    }

    const response = await fetch(`${APPMAX_API_URL}/api/v3/customer`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        Referer: "https://protocolo30dias.com/",
        Origin: "https://protocolo30dias.com",
      },
      body: JSON.stringify(customerData),
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || "Erro ao criar cliente")
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("[CUSTOMER_ERROR]", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
