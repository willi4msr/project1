import { type NextRequest, NextResponse } from "next/server"
import { isOrderPaid } from "@/lib/payment-status-store"

export async function GET(request: NextRequest) {
  console.log("[v0] GET /api/checkout/check-payment called")

  try {
    const searchParams = request.nextUrl.searchParams
    const order_id = searchParams.get("order_id")

    console.log("[v0] Received order_id:", order_id)

    if (!order_id) {
      return NextResponse.json({ success: false, error: "Missing order_id" }, { status: 400 })
    }

    const isPaid = isOrderPaid(String(order_id))

    console.log("[v0] Checking payment status for order:", order_id, "- Paid:", isPaid)

    return NextResponse.json(
      {
        success: true,
        order_id,
        status: isPaid ? "paid" : "pending",
        isPaid,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-store",
        },
      },
    )
  } catch (error) {
    console.error("[v0] Error in GET check-payment:", error)
    return NextResponse.json({ success: false, error: "Failed to check payment status" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  console.log("[v0] POST /api/checkout/check-payment called")

  try {
    const { order_id } = await request.json()

    console.log("[v0] Received order_id:", order_id)

    if (!order_id) {
      return NextResponse.json({ success: false, error: "Missing order_id" }, { status: 400 })
    }

    const isPaid = isOrderPaid(String(order_id))

    console.log("[v0] Checking payment status for order:", order_id, "- Paid:", isPaid)

    return NextResponse.json({
      success: true,
      order_id,
      status: isPaid ? "paid" : "pending",
      isPaid,
    })
  } catch (error) {
    console.error("[v0] Error in POST check-payment:", error)
    return NextResponse.json({ success: false, error: "Failed to check payment status" }, { status: 500 })
  }
}
