function normalizeAppmaxUrl(url: string): string {
  url = url.replace(/\/$/, "")

  if (url === "https://appmax.com.br" || url === "http://appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://admin.appmax.com.br" || url === "http://admin.appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://homolog.sandboxappmax.com.br" || url === "http://homolog.sandboxappmax.com.br") {
    return "https://homolog.sandboxappmax.com.br/api/v3"
  }

  if (!url.includes("/api/v3")) {
    return `${url}/api/v3`
  }

  return url
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const payload = {
      "access-token": process.env.APPMAX_ACCESS_TOKEN || "",
      firstname: body.firstname,
      lastname: body.lastname,
      email: body.email,
      telephone: body.telephone,
      document_number: body.document_number,
      origin_url: body.origin_url || "https://protocolo30dias.com/",
    }

    const appmaxUrl = normalizeAppmaxUrl(process.env.APPMAX_API_URL || "https://admin.appmax.com.br/api/v3")

    if (!appmaxUrl) {
      return Response.json({ error: "Configuração da API não encontrada" }, { status: 500 })
    }

    console.log("[v0] ========== CUSTOMER CREATION REQUEST ==========")
    console.log("[v0] Payload:", JSON.stringify(payload, null, 2))
    console.log("[v0] URL:", `${appmaxUrl}/customer`)

    const response = await fetch(`${appmaxUrl}/customer`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Referer: "https://protocolo30dias.com/",
        Origin: "https://protocolo30dias.com",
      },
      body: JSON.stringify(payload),
    })

    const data = await response.json()

    console.log("[v0] Customer response status:", response.status)
    console.log("[v0] ========== CUSTOMER CREATION RESPONSE ==========")
    console.log("[v0] Full response data:", JSON.stringify(data, null, 2))
    console.log("[v0] data.id:", data.id)
    console.log("[v0] data.data?.id:", data.data?.id)
    console.log("[v0] data.customer_id:", data.customer_id)
    console.log("[v0] ==================================================")

    if (!response.ok) {
      console.error("[CUSTOMER_SIMPLE_ERROR]", data)
      return Response.json({ error: data.message || "Erro ao criar cliente" }, { status: response.status })
    }

    const customerId = data.id || data.data?.id || data.customer_id || data.data?.customer_id

    return Response.json({
      data,
      customer_id: customerId,
      // Also include it at root level for easier access
      id: customerId,
    })
  } catch (error) {
    console.error("[CUSTOMER_SIMPLE_ERROR]", error)
    return Response.json(
      { error: error instanceof Error ? error.message : "Erro interno do servidor" },
      { status: 500 },
    )
  }
}
