import { type NextRequest, NextResponse } from "next/server"
import { getAppmaxHeaders } from "@/lib/appmax-headers"

function normalizeAppmaxUrl(url: string): string {
  url = url.replace(/\/$/, "")

  if (url === "https://appmax.com.br" || url === "http://appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://admin.appmax.com.br" || url === "http://admin.appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://homolog.sandboxappmax.com.br" || url === "http://homolog.sandboxappmax.com.br") {
    return "https://homolog.sandboxappmax.com.br/api/v3"
  }

  if (!url.includes("/api/v3")) {
    return `${url}/api/v3`
  }

  return url
}

const APPMAX_API_URL = normalizeAppmaxUrl(process.env.APPMAX_API_URL || "https://admin.appmax.com.br/api/v3")
const APPMAX_ACCESS_TOKEN = process.env.APPMAX_ACCESS_TOKEN || ""

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const paymentData = {
      "access-token": APPMAX_ACCESS_TOKEN,
      cart: body.cart,
      customer: body.customer,
      payment: {
        creditcard: {
          number: body.payment.creditcard.number,
          name: body.payment.creditcard.name,
          cvv: body.payment.creditcard.cvv,
          month: body.payment.creditcard.month,
          year: body.payment.creditcard.year,
          installments: body.payment.creditcard.installments,
          document_number: body.payment.creditcard.document_number,
        },
      },
    }

    const response = await fetch(`${APPMAX_API_URL}/payment/creditcard`, {
      method: "POST",
      headers: getAppmaxHeaders(),
      body: JSON.stringify(paymentData),
    })

    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      throw new Error("A API Appmax está bloqueando as requisições. Entre em contato com o suporte da Appmax.")
    }

    const data = await response.json()

    if (!data.success) {
      const errorMessage = data.text || data.message || "Erro ao processar pagamento"
      throw new Error(errorMessage)
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("[PAYMENT_CREDITCARD_ERROR]", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
