import { type NextRequest, NextResponse } from "next/server"
import { getAppmaxHeaders } from "@/lib/appmax-headers"
import { obfuscateEmail, obfuscatePhone } from "@/lib/data-obfuscation"

function normalizeAppmaxUrl(url: string): string {
  url = url.replace(/\/$/, "")

  if (url === "https://appmax.com.br" || url === "http://appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://admin.appmax.com.br" || url === "http://admin.appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://homolog.sandboxappmax.com.br" || url === "http://homolog.sandboxappmax.com.br") {
    return "https://homolog.sandboxappmax.com.br/api/v3"
  }

  if (!url.includes("/api/v3")) {
    return `${url}/api/v3`
  }

  return url
}

function getStateAbbreviation(stateName: string): string {
  const stateMap: Record<string, string> = {
    Acre: "AC",
    Alagoas: "AL",
    Amapá: "AP",
    Amazonas: "AM",
    Bahia: "BA",
    Ceará: "CE",
    "Distrito Federal": "DF",
    "Espírito Santo": "ES",
    Goiás: "GO",
    Maranhão: "MA",
    "Mato Grosso": "MT",
    "Mato Grosso do Sul": "MS",
    "Minas Gerais": "MG",
    Pará: "PA",
    Paraíba: "PB",
    Paraná: "PR",
    Pernambuco: "PE",
    Piauí: "PI",
    "Rio de Janeiro": "RJ",
    "Rio Grande do Norte": "RN",
    "Rio Grande do Sul": "RS",
    Rondônia: "RO",
    Roraima: "RR",
    "Santa Catarina": "SC",
    "São Paulo": "SP",
    Sergipe: "SE",
    Tocantins: "TO",
  }

  if (stateName.length === 2) return stateName.toUpperCase()
  return stateMap[stateName] || stateName
}

const APPMAX_API_URL = normalizeAppmaxUrl(process.env.APPMAX_API_URL || "https://admin.appmax.com.br/api/v3")
const APPMAX_ACCESS_TOKEN = process.env.APPMAX_ACCESS_TOKEN || ""

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] PIX Payment Request Body:", body)

    const nameParts = (body.name || "").trim().split(" ")
    const firstname = nameParts[0] || ""
    const lastname = nameParts.slice(1).join(" ") || nameParts[0] || ""

    const obfuscatedEmail = obfuscateEmail(body.email, firstname, lastname)
    const obfuscatedPhone = obfuscatePhone(body.phone)
    const stateAbbr = getStateAbbreviation(body.state)

    console.log("[v0] Obfuscated data:", { email: obfuscatedEmail, phone: obfuscatedPhone })

    const customerPayload = {
      "access-token": APPMAX_ACCESS_TOKEN,
      firstname,
      lastname,
      email: obfuscatedEmail,
      telephone: obfuscatedPhone,
      ip: request.headers.get("x-forwarded-for") || "127.0.0.1",
    }

    console.log("[v0] Creating customer with payload:", JSON.stringify(customerPayload, null, 2))

    const customerResponse = await fetch(`${APPMAX_API_URL}/customer`, {
      method: "POST",
      headers: getAppmaxHeaders(),
      body: JSON.stringify(customerPayload),
    })

    const customerData = await customerResponse.json()
    console.log("[v0] Customer response:", customerData)

    if (!customerData.success || !customerData.data?.id) {
      throw new Error(customerData.text || "Erro ao criar cliente")
    }

    const customer_id = customerData.data.id

    const orderPayload = {
      "access-token": APPMAX_ACCESS_TOKEN,
      products: [
        {
          sku: "PROTOCOLO-30-DIAS",
          name: "Protocolo 30 Dias — Inova Mulher",
          qty: 1,
          price: body.totalAmount,
          digital_product: 1, // Mark as digital product
        },
      ],
      shipping: 0, // No shipping for digital products
      customer_id,
      discount: 0,
    }

    console.log("[v0] Creating order with payload:", JSON.stringify(orderPayload, null, 2))

    const orderResponse = await fetch(`${APPMAX_API_URL}/order`, {
      method: "POST",
      headers: getAppmaxHeaders(),
      body: JSON.stringify(orderPayload),
    })

    const orderData = await orderResponse.json()
    console.log("[v0] Order response:", orderData)

    if (!orderData.success || !orderData.data?.id) {
      throw new Error(orderData.text || "Erro ao criar pedido")
    }

    const order_id = orderData.data.id

    const pixPayload = {
      "access-token": APPMAX_ACCESS_TOKEN,
      cart: {
        order_id,
      },
      customer: {
        customer_id,
      },
      payment: {
        pix: {
          document_number: body.cpf?.replace(/\D/g, "") || "",
        },
      },
    }

    console.log("[v0] Creating PIX payment with payload:", JSON.stringify(pixPayload, null, 2))

    const pixResponse = await fetch(`${APPMAX_API_URL}/payment/pix`, {
      method: "POST",
      headers: getAppmaxHeaders(),
      body: JSON.stringify(pixPayload),
    })

    const pixData = await pixResponse.json()
    console.log("[v0] PIX response:", pixData)

    if (!pixData.success) {
      throw new Error(pixData.text || "Erro ao processar pagamento PIX")
    }

    const trackingParams = {
      fbp: body.fbp || "",
      fbc: body.fbc || "",
      fbclid: body.fbclid || "",
      sessionId: body.sessionId || "",
    }

    const { saveOrderData } = await import("@/lib/order-data-store")
    saveOrderData(String(order_id), {
      totalAmount: body.totalAmount,
      currency: "BRL",
      userData: {
        email: body.originalEmail || body.email, // Use original email if available
        phone: body.originalPhone || body.phone, // Use original phone if available
        name: body.name,
      },
      trackingParams,
      userAgent: request.headers.get("user-agent") || "",
      sourceUrl: request.headers.get("referer") || "",
    })
    console.log("[v0] Order data saved for webhook processing:", order_id)

    return NextResponse.json({
      success: true,
      data: {
        order_id,
        customer_id,
        pay_reference: pixData.data?.pay_reference,
        pix_qrcode: pixData.data?.pix_qrcode,
        pix_emv: pixData.data?.pix_emv,
        pix_code: pixData.data?.pix_emv, // EMV code for copy-paste
        qr_code_image: pixData.data?.pix_qrcode, // QR code image
      },
    })
  } catch (error: any) {
    console.error("[PAYMENT_PIX_ERROR]", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
