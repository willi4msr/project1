import { type NextRequest, NextResponse } from "next/server"
import { getAppmaxHeaders } from "@/lib/appmax-headers"

function normalizeAppmaxUrl(url: string): string {
  url = url.replace(/\/$/, "")

  if (url === "https://appmax.com.br" || url === "http://appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://admin.appmax.com.br" || url === "http://admin.appmax.com.br") {
    return "https://admin.appmax.com.br/api/v3"
  }

  if (url === "https://homolog.sandboxappmax.com.br" || url === "http://homolog.sandboxappmax.com.br") {
    return "https://homolog.sandboxappmax.com.br/api/v3"
  }

  if (!url.includes("/api/v3")) {
    return `${url}/api/v3`
  }

  return url
}

const APPMAX_API_URL = normalizeAppmaxUrl(process.env.APPMAX_API_URL || "https://admin.appmax.com.br/api/v3")
const APPMAX_ACCESS_TOKEN = process.env.APPMAX_ACCESS_TOKEN || ""

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] ========== CREATING ORDER ==========")
    console.log("[v0] API URL normalizada:", APPMAX_API_URL)
    console.log("[v0] Body recebido:", JSON.stringify(body, null, 2))

    const orderData = {
      "access-token": APPMAX_ACCESS_TOKEN,
      customer_id: body.customer_id,
      products: body.products.map((product: any) => ({
        sku: product.sku,
        name: product.name,
        qty: product.qty,
        price: product.price,
        digital_product: 1, // Mark each product as digital
      })),
      total: body.total,
    }

    console.log("[v0] ========== ORDER PAYLOAD TO APPMAX ==========")
    console.log(JSON.stringify(orderData, null, 2))
    console.log("[v0] ================================================")
    console.log("[v0] Enviando requisição para:", `${APPMAX_API_URL}/order`)

    const response = await fetch(`${APPMAX_API_URL}/order`, {
      method: "POST",
      headers: getAppmaxHeaders(),
      body: JSON.stringify(orderData),
    })

    console.log("[v0] Status da resposta:", response.status)

    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      console.error("[ORDER_ERROR] Cloudflare bloqueou a requisição")
      throw new Error("A API Appmax está bloqueando as requisições. Entre em contato com o suporte da Appmax.")
    }

    const data = await response.json()
    console.log("[v0] ========== ORDER RESPONSE FROM APPMAX ==========")
    console.log(JSON.stringify(data, null, 2))
    console.log("[v0] ===================================================")

    if (!data.success) {
      const errorMessage = data.text || data.message || "Erro ao criar pedido"
      console.error("[ORDER_ERROR]", errorMessage)
      throw new Error(errorMessage)
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("[ORDER_ERROR]", error.message)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
