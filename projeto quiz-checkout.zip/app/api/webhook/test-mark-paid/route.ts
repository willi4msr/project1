import { type NextRequest, NextResponse } from "next/server"
import { markOrderAsPaid } from "@/lib/payment-status-store"

export async function POST(request: NextRequest) {
  try {
    const { orderId } = await request.json()

    if (!orderId) {
      return NextResponse.json({ success: false, error: "Order ID is required" }, { status: 400 })
    }

    console.log("[v0] Manual test - marking order as paid:", orderId)
    markOrderAsPaid(String(orderId))

    return NextResponse.json({
      success: true,
      message: `Order ${orderId} marked as paid`,
      orderId,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 })
  }
}
