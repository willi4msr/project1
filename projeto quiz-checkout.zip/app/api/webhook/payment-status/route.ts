import type { NextRequest } from "next/server"

const paymentUpdates = new Map<string, string>()
const activeStreams = new Map<string, Set<ReadableStreamDefaultController>>()

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const orderId = searchParams.get("order_id")

  if (!orderId) {
    return new Response("Missing order_id", { status: 400 })
  }

  console.log("[v0] Client connecting to payment stream for order:", orderId)

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    start(controller) {
      try {
        if (!activeStreams.has(orderId)) {
          activeStreams.set(orderId, new Set())
        }
        activeStreams.get(orderId)!.add(controller)

        console.log("[v0] Stream registered for order:", orderId, "Active streams:", activeStreams.get(orderId)!.size)

        // Send connection confirmation
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "connected", orderId })}\n\n`))

        // Check if payment was already confirmed
        const existingStatus = paymentUpdates.get(orderId)
        if (existingStatus === "paid") {
          console.log("[v0] Payment already confirmed for order:", orderId)
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: "paid", orderId })}\n\n`))
          controller.close()
          return
        }

        // Send heartbeat every 15 seconds
        const heartbeat = setInterval(() => {
          try {
            controller.enqueue(encoder.encode(`: heartbeat\n\n`))
          } catch (error) {
            console.error("[v0] Error sending heartbeat:", error)
            clearInterval(heartbeat)
          }
        }, 15000)

        // Timeout after 30 minutes
        const timeout = setTimeout(
          () => {
            console.log("[v0] Stream timeout for order:", orderId)
            clearInterval(heartbeat)
            const streams = activeStreams.get(orderId)
            if (streams) {
              streams.delete(controller)
              if (streams.size === 0) {
                activeStreams.delete(orderId)
              }
            }
            try {
              controller.close()
            } catch (error) {
              console.error("[v0] Error closing stream:", error)
            }
          },
          30 * 60 * 1000,
        )
        ;(controller as any)._cleanup = () => {
          clearInterval(heartbeat)
          clearTimeout(timeout)
        }
      } catch (error) {
        console.error("[v0] Error in stream start:", error)
        try {
          controller.error(error)
        } catch (e) {
          console.error("[v0] Error sending error to controller:", e)
        }
      }
    },
    cancel() {
      const streams = activeStreams.get(orderId)
      if (streams) {
        streams.forEach((ctrl) => {
          if ((ctrl as any)._cleanup) {
            ;(ctrl as any)._cleanup()
          }
        })
        activeStreams.delete(orderId)
      }
      console.log("[v0] Stream cancelled for order:", orderId)
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}

export function notifyPaymentUpdate(orderId: string, status: string) {
  console.log("[v0] Notifying payment update for order:", orderId, "status:", status)

  paymentUpdates.set(orderId, status)

  const streams = activeStreams.get(orderId)
  if (streams && streams.size > 0) {
    const encoder = new TextEncoder()
    const message = JSON.stringify({ type: status, orderId })

    console.log("[v0] Sending to", streams.size, "active stream(s):", message)

    streams.forEach((controller) => {
      try {
        controller.enqueue(encoder.encode(`data: ${message}\n\n`))
        if (status === "paid") {
          if ((controller as any)._cleanup) {
            ;(controller as any)._cleanup()
          }
          controller.close()
        }
      } catch (error) {
        console.error("[v0] Error sending to stream:", error)
      }
    })

    if (status === "paid") {
      activeStreams.delete(orderId)
    }
  } else {
    console.log("[v0] No active streams for order:", orderId)
  }
}
