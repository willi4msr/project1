import { type NextRequest, NextResponse } from "next/server"
import { markOrderAsPaid } from "@/lib/payment-status-store"

// GET endpoint to test if webhook URL is accessible
export async function GET(request: NextRequest) {
  console.log("[v0] Appmax webhook GET request received - URL is accessible")
  return NextResponse.json({
    success: true,
    message: "Appmax webhook endpoint is accessible",
    timestamp: new Date().toISOString(),
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] ===== APPMAX WEBHOOK RECEIVED =====")
    console.log("[v0] Full webhook payload:", JSON.stringify(body, null, 2))
    console.log("[v0] Request headers:", Object.fromEntries(request.headers.entries()))

    // Try multiple ways to extract order ID from different webhook structures
    const orderId =
      body.order_id ||
      body.id ||
      body.pedido_id ||
      body.data?.order_id ||
      body.data?.id ||
      body.order?.id ||
      body.transaction?.order_id

    // Try multiple ways to extract status
    const status =
      body.status || body.payment_status || body.data?.status || body.order?.status || body.transaction?.status

    console.log("[v0] Extracted - Order ID:", orderId, "| Status:", status)

    // Check if payment is confirmed (multiple variations)
    const isPaid = ["paid", "approved", "pago", "aprovado", "concluido", "success", "completed"].some((s) =>
      status?.toLowerCase().includes(s),
    )

    console.log("[v0] Payment status check - isPaid:", isPaid)

    if (orderId) {
      if (isPaid) {
        console.log("[v0] ✓ PAYMENT CONFIRMED for order:", orderId, "- Marking as paid")
        markOrderAsPaid(String(orderId))
        console.log("[v0] Order", orderId, "marked as paid in store")

        try {
          const { sendBackendPurchase } = await import("@/lib/backend-purchase-tracking")
          const result = await sendBackendPurchase(String(orderId))

          if (result.success) {
            console.log("[v0] ✓ Backend Purchase tracking successful:", result.message)
          } else {
            console.warn("[v0] ⚠ Backend Purchase tracking failed:", result.message)
          }
        } catch (purchaseError) {
          console.error("[v0] Error in backend Purchase tracking:", purchaseError)
          // Don't fail the webhook if Purchase tracking fails
        }
      } else {
        console.log("[v0] ✗ Payment not yet confirmed for order:", orderId, "- Status:", status)
      }
    } else {
      console.log("[v0] ✗ ERROR: Could not extract order ID from webhook payload")
    }

    console.log("[v0] ===== END WEBHOOK PROCESSING =====")

    return NextResponse.json({
      success: true,
      message: "Webhook received and processed",
      orderId,
      status,
      processed: isPaid,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] ===== WEBHOOK ERROR =====")
    console.error("[v0] Error processing Appmax webhook:", error)
    console.error("[v0] Error stack:", error instanceof Error ? error.stack : String(error))

    return NextResponse.json(
      {
        success: false,
        error: "Failed to process webhook",
        message: String(error),
        timestamp: new Date().toISOString(),
      },
      { status: 200 },
    )
  }
}
