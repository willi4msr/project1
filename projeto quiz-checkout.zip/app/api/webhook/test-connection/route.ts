import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    status: "online",
    message: "Webhook endpoint está acessível e funcionando",
    timestamp: new Date().toISOString(),
    url: "https://protocolo30dias.com/api/webhook/appmax",
  })
}

export async function POST() {
  return NextResponse.json({
    status: "online",
    message: "POST está funcionando - Appmax deveria conseguir enviar webhooks",
    timestamp: new Date().toISOString(),
  })
}
