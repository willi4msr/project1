import { type NextRequest, NextResponse } from "next/server"
import { sendMetaEvent } from "@/lib/tracking-service"
import { getTrackingData } from "@/lib/tracking-store"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { orderId, sessionId, value, currency = "BRL", contents } = body

    console.log("[WEBHOOK PAYMENT] Received:", { orderId, sessionId, value })

    if (!orderId || !sessionId) {
      return NextResponse.json({ error: "Missing orderId or sessionId" }, { status: 400 })
    }

    // Recuperar dados reais do store
    const trackingData = getTrackingData(sessionId)

    if (!trackingData) {
      console.error("[WEBHOOK PAYMENT] No tracking data found for session:", sessionId)
      return NextResponse.json({ error: "Tracking data not found" }, { status: 404 })
    }

    // Gerar event_id único para Purchase (importante para deduplicação)
    const eventId = `purchase_${orderId}`

    console.log("[WEBHOOK PAYMENT] Sending Purchase to Meta CAPI", {
      orderId,
      externalId: trackingData.externalId,
      value,
      currency,
    })

    // Enviar Purchase para Meta CAPI com dados REAIS
    await sendMetaEvent({
      eventName: "Purchase",
      eventId,
      eventSourceUrl: "https://protocolo30dias.com/obrigado",
      userData: {
        em: require("crypto").createHash("sha256").update(trackingData.email).digest("hex"),
        ph: require("crypto").createHash("sha256").update(trackingData.phone).digest("hex"),
        external_id: trackingData.externalId,
        fbp: trackingData.fbp,
        fbc: trackingData.fbc,
        client_ip_address: trackingData.clientIp,
        client_user_agent: trackingData.clientUserAgent,
      },
      customData: {
        currency,
        value: Number.parseFloat(value),
        content_type: "product",
        contents: contents || [],
      },
    })

    return NextResponse.json({
      success: true,
      eventId,
    })
  } catch (error) {
    console.error("[WEBHOOK PAYMENT] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
