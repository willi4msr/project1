import { NextResponse } from "next/server"
import { markOrderAsPaid } from "@/lib/payment-status-store"

export async function POST(request: Request) {
  try {
    const { orderId } = await request.json()

    if (!orderId) {
      return NextResponse.json(
        {
          success: false,
          error: "orderId é obrigatório",
        },
        { status: 400 },
      )
    }

    console.log("[v0] Manual payment simulation for order:", orderId)
    markOrderAsPaid(String(orderId))
    console.log("[v0] Order marked as paid:", orderId)

    return NextResponse.json({
      success: true,
      message: `Pedido ${orderId} marcado como pago manualmente`,
      orderId: orderId,
    })
  } catch (error) {
    console.error("[v0] Error simulating payment:", error)
    return NextResponse.json(
      {
        success: false,
        error: String(error),
      },
      { status: 500 },
    )
  }
}
